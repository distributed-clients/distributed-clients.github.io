if (!window.maakimaLoaded) {
  window.maakimaLoaded = true;

  // Random per page load so a page cannot probe for the extension by a fixed id;
  // the tuned dot style (formerly content.css) is applied inline by getDisplay.
  const PAGE_ID = "m" + Math.random().toString(36).slice(2);
  const BOX_STYLE = {
    position: "fixed", display: "none", width: "fit-content", "min-width": "0",
    "text-shadow": "none", border: "none", "z-index": "2147483647", "max-width": "90vw",
    "font-family": '"Monaco", "Menlo", "Ubuntu Mono", "Courier New", monospace',
    "font-weight": "900", "line-height": "1", "white-space": "nowrap",
    "overflow-wrap": "normal", "box-sizing": "border-box",
    transition: "opacity 0.15s ease-in-out", "pointer-events": "auto",
  };
  const TEXT_STYLE = { display: "block", "line-height": "0.5", transform: "translateY(-0.2em)" };
  const setStyles = (el, styles) => {
    for (const [k, v] of Object.entries(styles)) el.style.setProperty(k, v, "important");
  };
  let displayEl = null;
  let displayTextEl = null;
  let currentSettings = { ...MaakimaSettings.DEFAULTS };
  let animationToken = 0;
  let currentRunId = null; // runId of the last loading message; stale results are dropped
  let debugInterval = null;

  function storageGet(keys) {
    return new Promise((resolve, reject) => {
      chrome.storage.local.get(keys, (result) => {
        if (chrome.runtime && chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(result);
      });
    });
  }

  let logBatch = [];
  let logTimer = null;

  function logText(args) {
    return args
      .map((a) => {
        if (typeof a === "string") return a;
        if (a instanceof Error) return `${a.name}: ${a.message}`;
        try {
          const j = JSON.stringify(a);
          return j === undefined ? String(a) : j;
        } catch (e) {
          return "[unserializable]";
        }
      })
      .join(" ");
  }

  function flushLogs() {
    clearTimeout(logTimer);
    logTimer = null;
    if (!logBatch.length) return;
    const lines = logBatch;
    logBatch = [];
    try {
      chrome.runtime.sendMessage({ action: "log_lines", lines }, () => {
        void chrome.runtime.lastError;
      });
    } catch (e) {
      // Extension context gone (page outlived an update); nowhere to log to.
    }
  }

  window.addEventListener("pagehide", () => flushLogs());

  function pushLog(level, args) {
    logBatch.push({ level, text: logText(args) });
    if (level === "error") flushLogs();
    else if (!logTimer) logTimer = setTimeout(flushLogs, 500);
  }

  function log(...args) {
    if (currentSettings.enableDetailedLogging) pushLog("info", args);
  }

  function logError(...args) {
    pushLog("error", args);
  }

  function logWarn(...args) {
    pushLog("warn", args);
  }

  function logGroup(...args) {
    if (currentSettings.enableDetailedLogging) pushLog("info", ["▶", ...args]);
  }

  function logGroupEnd() {}

  function applyPositionSettings(el) {
    const position = MaakimaSettings.position(currentSettings.displayPosition);
    el.style.setProperty("bottom", "10px", "important");
    if (position === "left") {
      el.style.setProperty("left", "10px", "important");
      el.style.setProperty("right", "auto", "important");
      el.style.setProperty("transform", "none", "important");
      return;
    }
    if (position === "right") {
      el.style.setProperty("left", "auto", "important");
      el.style.setProperty("right", "10px", "important");
      el.style.setProperty("transform", "none", "important");
      return;
    }
    el.style.setProperty("left", "50%", "important");
    el.style.setProperty("right", "auto", "important");
    el.style.setProperty("transform", "translateX(-50%)", "important");
  }

  function applyDisplaySettings(el) {
    applyPositionSettings(el);
    el.style.setProperty(
      "font-size",
      `${currentSettings.displayFontSize}px`,
      "important",
    );
    el.style.setProperty(
      "color",
      currentSettings.displayFontColor,
      "important",
    );
    if (currentSettings.displayWhiteBackground) {
      el.style.setProperty(
        "background-color",
        "rgba(255, 255, 255, 0.95)",
        "important",
      );
      el.style.setProperty("padding", "0 0.04em", "important");
      el.style.setProperty("border-radius", "0.08em", "important");
      el.style.setProperty("box-shadow", "none", "important");
    } else {
      el.style.setProperty("background-color", "transparent", "important");
      el.style.setProperty("padding", "0px", "important");
      el.style.setProperty("border-radius", "0px", "important");
      el.style.setProperty("box-shadow", "none", "important");
    }

    if (displayTextEl) {
      displayTextEl.style.setProperty(
        "font-size",
        `${currentSettings.displayFontSize}px`,
        "important",
      );
      displayTextEl.style.setProperty(
        "color",
        currentSettings.displayFontColor,
        "important",
      );
    }
  }

  function showDisplay(el) {
    el.style.setProperty("display", "inline-flex", "important");
    el.style.setProperty("opacity", "1", "important");
  }

  function hideDisplay(el) {
    el.style.setProperty("display", "none", "important");
    el.style.setProperty("opacity", "0", "important");
  }

  function applyDebugPreviewState() {
    if (!currentSettings.displayDebugPersistentBox) {
      if (debugInterval) {
        clearInterval(debugInterval);
        debugInterval = null;
      }
      if (displayEl) {
        hideDisplay(displayEl);
        if (displayTextEl) {
          displayTextEl.textContent = "";
        }
      }
      return;
    }

    const el = getDisplay();
    // Apply all user settings (position, background, etc.) for debug preview
    applyDisplaySettings(el);
    displayTextEl.style.setProperty("letter-spacing", `${currentSettings.displayDotSpacing}px`, "important");
    
    if (!debugInterval) {
      let debugCount = 1;
      renderDots(displayTextEl, debugCount);
      debugInterval = setInterval(() => {
        debugCount = (debugCount % 6) + 1;
        renderDots(displayTextEl, debugCount);
      }, 1200);
    } else {
      // Re-apply if settings change while interval is running
      const currentCount = (displayTextEl.textContent.match(/\./g) || []).length || 4;
      renderDots(displayTextEl, currentCount);
    }
    
    showDisplay(el);
  }

  function getDisplay() {
    if (!displayEl) {
      displayEl = document.createElement("div");
      displayEl.id = PAGE_ID;
      setStyles(displayEl, BOX_STYLE);
      displayTextEl = document.createElement("div");
      displayTextEl.id = PAGE_ID + "-t";
      setStyles(displayTextEl, TEXT_STYLE);
      displayEl.appendChild(displayTextEl);
      document.body.appendChild(displayEl);
      applyDisplaySettings(displayEl);
      log("[Maakima][Content] Display element created.");
    }
    return displayEl;
  }

  async function loadSettingsFromStorage() {
    try {
      const raw = await storageGet([
        "displayFontSize",
        "displayFontColor",
        "displayPosition",
        "displayWhiteBackground",
        "displayDotSpacing",
        "displayDebugPersistentBox",
        "enableDetailedLogging",
      ]);
      currentSettings = MaakimaSettings.sanitizeDisplay({ ...MaakimaSettings.DEFAULTS, ...raw });
      if (displayEl) {
        applyDisplaySettings(displayEl);
      }
      applyDebugPreviewState();
      log("[Maakima][Content] Settings loaded:", currentSettings);
    } catch (error) {
      logError("[Maakima][Content] Failed to load settings:", error);
    }
  }

  function parseOptionNumbers(resultText) {
    if (!resultText) {
      return null;
    }

    const matches = resultText.match(/[1-6]/g);
    if (!matches || matches.length === 0) {
      return null;
    }

    return [...new Set(matches.map(Number))].sort((a, b) => a - b);
  }

  function wait(ms, token) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (token === animationToken) {
          resolve(true);
          return;
        }
        resolve(false);
      }, ms);
    });
  }

  function renderDots(el, count) {
    el.textContent = "";
    if (count < 4 || count > 6) {
      el.textContent = ".".repeat(Math.max(1, count));
      return;
    }
    
    const firstPart = document.createTextNode(count === 4 ? ".." : "...");
    const span = document.createElement("span");
    span.style.letterSpacing = "normal";
    span.textContent = "\u2002"; // En Space
    const secondPart = document.createTextNode(count === 6 ? "..." : "..");
    
    el.appendChild(firstPart);
    el.appendChild(span);
    el.appendChild(secondPart);
  }

  async function showMultipleAnswers(el, answerArray) {
    animationToken += 1;
    const token = animationToken;
    applyDisplaySettings(el);

    for (let i = 0; i < answerArray.length; i += 1) {
      const answer = answerArray[i];
      displayTextEl.style.setProperty("letter-spacing", `${currentSettings.displayDotSpacing}px`, "important");
      renderDots(displayTextEl, answer);
      showDisplay(el);

      if (!(await wait(1000, token))) {
        return;
      }

      el.style.setProperty("opacity", "0", "important");
      if (!(await wait(150, token))) {
        return;
      }
      hideDisplay(el);

      if (i < answerArray.length - 1) {
        if (!(await wait(500, token))) {
          return;
        }
      }
    }
  }

  async function showTextMessage(el, text, durationMs) {
    animationToken += 1;
    const token = animationToken;

    displayTextEl.style.setProperty("letter-spacing", "0px", "important");
    displayTextEl.style.setProperty(
      "font-size",
      `${Math.max(12, currentSettings.displayFontSize - 8)}px`,
      "important",
    );
    displayTextEl.textContent = text;
    showDisplay(el);

    if (!(await wait(durationMs, token))) {
      return;
    }

    el.style.setProperty("opacity", "0", "important");
    if (!(await wait(160, token))) {
      return;
    }

    hideDisplay(el);
    if (!currentSettings.displayDebugPersistentBox) {
      displayTextEl.textContent = "";
    }
    applyDisplaySettings(el);
  }

  async function showUnderscore(el, durationMs = 1200) {
    animationToken += 1;
    const token = animationToken;

    applyDisplaySettings(el);
    displayTextEl.style.setProperty("letter-spacing", `${currentSettings.displayDotSpacing}px`, "important");
    displayTextEl.textContent = "_";
    showDisplay(el);

    if (!(await wait(durationMs, token))) {
      return;
    }

    el.style.setProperty("opacity", "0", "important");
    if (!(await wait(160, token))) {
      return;
    }

    hideDisplay(el);
    if (!currentSettings.displayDebugPersistentBox) {
      displayTextEl.textContent = "";
    }
  }

  window.addEventListener("auxclick", (e) => {
    try {
    if (e.isTrusted && e.button === 1) {
      e.preventDefault();
      log("[Maakima][Content] Middle click detected. Toggling analysis.");
      try {
        chrome.runtime.sendMessage({ action: "toggle_analysis" }, () => {
          void chrome.runtime.lastError;
        });
      } catch (error) {
        if (
          error.message &&
          error.message.includes("Extension context invalidated")
        ) {
          alert("Maakima was updated. Please refresh this page.");
        } else {
          logError("[Maakima][Content] Runtime messaging error:", error);
        }
      }
    }
    } catch (error) {
      logError("[Maakima][Content] auxclick handler failed:", error);
    }
  });

  chrome.runtime.onMessage.addListener((request) => {
    try {
      handleMessage(request);
    } catch (error) {
      logError("[Maakima][Content] message handler failed:", error);
    }
  });

  function handleMessage(request) {
    if (request.action === "show_gemini_loading") {
      currentRunId = request.runId ?? null;
    } else if (
      request.action === "show_gemini_result" &&
      (currentRunId === null || request.runId !== currentRunId)
    ) {
      log("[Maakima][Content] Ignoring result for stale runId", request.runId);
      return;
    }
    if (request.action === "hide_floating_key_box") {
      removeKeyBox();
      return;
    }
    const el = getDisplay();

    // Unified preview and actual: when popup sends preview, treat as real settings
    if (
      request.action === "debug_preview_settings" &&
      request.displaySettings
    ) {
      currentSettings = MaakimaSettings.fromMessage(
        request.displaySettings,
        currentSettings,
      );
      applyDisplaySettings(el);
      applyDebugPreviewState();
      return;
    }

    if (request.displaySettings) {
      currentSettings = MaakimaSettings.fromMessage(
        request.displaySettings,
        currentSettings,
      );
      applyDisplaySettings(el);
      applyDebugPreviewState();
    }

    if (
      currentSettings.displayDebugPersistentBox &&
      (request.action === "show_gemini_loading" ||
        request.action === "show_gemini_result" ||
        request.action === "hide_ui")
    ) {
      // In debug preview mode, keep a static dummy box for visual tuning.
      applyDebugPreviewState();
      return;
    }

    if (request.action === "show_gemini_loading") {
      logGroup("[Maakima][Content] Request Started");
      log("Timestamp:", new Date().toISOString());
      log("Loading UI...");
      logGroupEnd();
      log("[Maakima][Content] Loading signal received.");
      animationToken += 1;
      hideDisplay(el);
      displayTextEl.textContent = "";
      return;
    }

    if (request.action === "show_gemini_result") {
      logGroup("[Maakima][Content] Result Received");

      if (request.error) {
        logError("Analysis Error:", request.errorMessage);
        log("Full Request Object:", request);
        logGroupEnd();
        showUnderscore(el, 1200);
        return;
      }

      log("Provider Source:", request.providerSource);
      log("Provider:", request.provider);
      log("Raw AI Output:", request.rawOutput);
      log("Parsed Answer Array:", request.parsedAnswers);
      log("No Answer Status:", request.noAnswer);
      log("No Answer Reason:", request.noAnswerReason);
      log("Full Request Object:", request);

      if (request.noAnswer) {
        const reason = request.noAnswerReason || "No visible solvable question";
        logWarn("Model replied but no solvable answer found:", reason);
        logGroupEnd();
        showUnderscore(el, 1200);
        return;
      }

      const answerNumbers =
        Array.isArray(request.parsedAnswers) && request.parsedAnswers.length > 0
          ? request.parsedAnswers
          : parseOptionNumbers(request.result);

      log("Final Answer Numbers:", answerNumbers);
      logGroupEnd();

      if (answerNumbers && answerNumbers.length > 0) {
        showMultipleAnswers(el, answerNumbers);
      } else {
        showUnderscore(el, 1200);
      }
      return;
    }

    if (request.action === "hide_ui") {
      animationToken += 1;
      hideDisplay(el);
      displayTextEl.textContent = "";
      log("[Maakima][Content] Hide UI signal received.");
    }

  }

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") {
      return;
    }

    let shouldApply = false;

    if (changes.displayFontSize) {
      currentSettings.displayFontSize = MaakimaSettings.fontSize(
        changes.displayFontSize.newValue,
      );
      shouldApply = true;
    }

    if (changes.displayFontColor) {
      currentSettings.displayFontColor = MaakimaSettings.color(
        changes.displayFontColor.newValue,
      );
      shouldApply = true;
    }

    if (changes.enableDetailedLogging) {
      currentSettings.enableDetailedLogging =
        typeof changes.enableDetailedLogging.newValue === "boolean"
          ? changes.enableDetailedLogging.newValue
          : MaakimaSettings.DEFAULTS.enableDetailedLogging;
    }

    if (changes.displayWhiteBackground) {
      currentSettings.displayWhiteBackground = MaakimaSettings.bool(
        changes.displayWhiteBackground.newValue,
        MaakimaSettings.DEFAULTS.displayWhiteBackground,
      );
      shouldApply = true;
    }

    if (changes.displayPosition) {
      currentSettings.displayPosition = MaakimaSettings.position(
        changes.displayPosition.newValue,
      );
      shouldApply = true;
    }

    if (changes.displayDebugPersistentBox) {
      currentSettings.displayDebugPersistentBox = MaakimaSettings.bool(
        changes.displayDebugPersistentBox.newValue,
        MaakimaSettings.DEFAULTS.displayDebugPersistentBox,
      );
      shouldApply = true;
    }

    if (changes.displayDotSpacing) {
      currentSettings.displayDotSpacing = MaakimaSettings.dotSpacing(
        changes.displayDotSpacing.newValue,
      );
      shouldApply = true;
    }

    if (shouldApply && displayEl) {
      applyDisplaySettings(displayEl);
    }

    if (changes.displayDebugPersistentBox) {
      applyDebugPreviewState();
    }

    if (
      typeof (changes.disableFloatingKeyBox && changes.disableFloatingKeyBox.newValue) !== "undefined" ||
      changes.userGeminiApiKeys ||
      changes.remoteUserKey
    ) {
      checkAndShowKeyImport().catch((error) =>
        logError("[Maakima][Content] key box check failed:", error));
    }
  });

  function removeKeyBox() {
    const box = document.getElementById("maakima-floating-key-box");
    if (box) box.remove();
  }

  // Invisible bottom-left box (opacity 0 until hover) for importing a user key
  // before any Gemini key exists; hidden once keys exist or the popup disables it.
  async function checkAndShowKeyImport() {
    const keys = await storageGet(["userGeminiApiKeys", "disableFloatingKeyBox"]);
    const hasAnyApiKeys = Boolean(
      keys.userGeminiApiKeys && keys.userGeminiApiKeys.length > 0,
    );
    if (hasAnyApiKeys || keys.disableFloatingKeyBox) {
      removeKeyBox();
      return;
    }
    if (document.getElementById("maakima-floating-key-box")) return;

    const box = document.createElement("div");
    box.id = "maakima-floating-key-box";
    box.style.cssText = `
      position: fixed !important;
      bottom: 0 !important;
      left: 0 !important;
      z-index: 2147483647 !important;
      background: transparent !important;
      border: none !important;
      padding: 0 !important;
      display: flex !important;
      align-items: center !important;
      font-family: 'Inter', sans-serif !important;
      opacity: 0 !important;
      transition: opacity 0.2s, background 0.2s !important;
    `;

    const input = document.createElement("input");
    input.type = "text";
    // no browser history dropdown or spellcheck underline: nothing typed may show
    input.autocomplete = "off";
    input.spellcheck = false;
    input.style.cssText = `
      border: none !important;
      outline: none !important;
      font-size: 7px !important;
      color: transparent !important;
      caret-color: transparent !important;
      background: transparent !important;
      width: 12px !important;
      padding: 0 !important;
      text-align: center !important;
      position: relative !important;
      z-index: 1 !important;
    `;

    const show = () => {
      box.style.opacity = "1";
      box.style.background = "#fff";
      box.style.border = "1px solid #ddd";
    };
    const hide = () => {
      box.style.opacity = "0";
      box.style.background = "transparent";
      box.style.border = "none";
    };
    box.onmouseenter = show;
    box.onmouseleave = () => {
      if (document.activeElement !== input) hide();
    };
    input.onfocus = show;
    input.onblur = () => {
      input.value = "";
      hide();
    };

    box.appendChild(input);
    document.body.appendChild(box);

    input.addEventListener("keydown", (e) => {
      if (e.key !== "Enter") return;
      const userKey = input.value.trim();
      if (!userKey || !userKey.includes(":")) {
        logWarn("[Maakima][Content] key box: entry ignored, expected user:password");
        input.value = "";
        return;
      }
      input.disabled = true;
      input.value = "";
      chrome.runtime.sendMessage(
        { action: "import_remote_user_key", userKey },
        (response) => {
          const runtimeError = chrome.runtime.lastError;
          if (response && response.success) {
            box.remove();
            loadSettingsFromStorage().catch((error) =>
              logError("[Maakima][Content] reload after import failed:", error));
          } else {
            input.disabled = false;
            input.value = "";
            logError(
              "[Maakima][Content] Import failed:",
              response ? response.error : runtimeError ? runtimeError.message : "No response",
            );
          }
        },
      );
    });
  }

  loadSettingsFromStorage()
    .then(() => checkAndShowKeyImport())
    .catch((error) => logError("[Maakima][Content] startup failed:", error));

  if (typeof module === "object" && module.exports) {
    module.exports = {
      log, logError, logWarn, logGroup, logGroupEnd,
      setDetailedLogging(v) { currentSettings.enableDetailedLogging = v; },
    };
  }
}
