if (!window.maakimaLoaded) {
  window.maakimaLoaded = true;

  const DEFAULT_SETTINGS = {
    displayFontSize: 30,
    displayFontColor: "#cfcdcd",
    displayPosition: "center",
    displayWhiteBackground: true,
    displayDebugPersistentBox: false,
    enableDetailedLogging: true,
  };

  let displayEl = null;
  let displayTextEl = null;
  let currentSettings = { ...DEFAULT_SETTINGS };
  let animationToken = 0;

  function storageGet(keys) {
    return new Promise((resolve, reject) => {
      chrome.storage.local.get(keys, (result) => {
        if (chrome.runtime && chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(result);
      });
    });
  }

  function log(...args) {
    if (currentSettings.enableDetailedLogging) {
      console.log(...args);
    }
  }

  function parseColor(input) {
    if (typeof input !== "string") {
      return DEFAULT_SETTINGS.displayFontColor;
    }
    const value = input.trim();
    if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(value)) {
      return value;
    }
    return DEFAULT_SETTINGS.displayFontColor;
  }

  function parseSize(input) {
    const number = Number(input);
    if (!Number.isFinite(number)) {
      return DEFAULT_SETTINGS.displayFontSize;
    }
    return Math.max(10, Math.min(80, Math.round(number)));
  }

  function parseBoolean(input, fallback) {
    if (typeof input === "boolean") {
      return input;
    }
    if (typeof fallback === "boolean") {
      return fallback;
    }
    return false;
  }

  function parsePosition(input) {
    const value = `${input || ""}`.trim().toLowerCase();
    if (value === "left" || value === "right") {
      return value;
    }
    return DEFAULT_SETTINGS.displayPosition;
  }

  function sanitizeSettings(raw) {
    return {
      displayFontSize: parseSize(raw.displayFontSize),
      displayFontColor: parseColor(raw.displayFontColor),
      displayPosition: parsePosition(raw.displayPosition),
      displayWhiteBackground: parseBoolean(
        raw.displayWhiteBackground,
        DEFAULT_SETTINGS.displayWhiteBackground,
      ),
      displayDebugPersistentBox: parseBoolean(
        raw.displayDebugPersistentBox,
        DEFAULT_SETTINGS.displayDebugPersistentBox,
      ),
      enableDetailedLogging:
        typeof raw.enableDetailedLogging === "boolean"
          ? raw.enableDetailedLogging
          : DEFAULT_SETTINGS.enableDetailedLogging,
    };
  }

  function applyPositionSettings(el) {
    const position = parsePosition(currentSettings.displayPosition);
    console.log(
      "[Maakima][applyPositionSettings] Using position:",
      position,
      "from",
      currentSettings.displayPosition,
    );
    el.style.setProperty("bottom", "10px", "important");
    if (position === "left") {
      console.log("[Maakima][applyPositionSettings] Setting left position");
      el.style.setProperty("left", "10px", "important");
      el.style.setProperty("right", "auto", "important");
      el.style.setProperty("transform", "none", "important");
      return;
    }
    if (position === "right") {
      console.log("[Maakima][applyPositionSettings] Setting right position");
      el.style.setProperty("left", "auto", "important");
      el.style.setProperty("right", "10px", "important");
      el.style.setProperty("transform", "none", "important");
      return;
    }
    console.log("[Maakima][applyPositionSettings] Setting center position");
    el.style.setProperty("left", "50%", "important");
    el.style.setProperty("right", "auto", "important");
    el.style.setProperty("transform", "translateX(-50%)", "important");
  }

  function applyDisplaySettings(el) {
    applyPositionSettings(el);
    el.style.setProperty(
      "font-size",
      `${currentSettings.displayFontSize}px`,
      "important",
    );
    el.style.setProperty(
      "color",
      currentSettings.displayFontColor,
      "important",
    );
    console.log(
      "[Maakima][applyDisplaySettings] White background:",
      currentSettings.displayWhiteBackground,
    );
    if (currentSettings.displayWhiteBackground) {
      el.style.setProperty(
        "background-color",
        "rgba(255, 255, 255, 0.95)",
        "important",
      );
      el.style.setProperty("padding", "0 0.04em", "important");
      el.style.setProperty("border-radius", "0.08em", "important");
      el.style.setProperty("box-shadow", "none", "important");
    } else {
      el.style.setProperty("background-color", "transparent", "important");
      el.style.setProperty("padding", "0px", "important");
      el.style.setProperty("border-radius", "0px", "important");
      el.style.setProperty("box-shadow", "none", "important");
    }

    if (displayTextEl) {
      displayTextEl.style.setProperty(
        "font-size",
        `${currentSettings.displayFontSize}px`,
        "important",
      );
      displayTextEl.style.setProperty(
        "color",
        currentSettings.displayFontColor,
        "important",
      );
    }
  }

  function showDisplay(el) {
    el.style.setProperty("display", "inline-flex", "important");
    el.style.setProperty("opacity", "1", "important");
  }

  function hideDisplay(el) {
    el.style.setProperty("display", "none", "important");
    el.style.setProperty("opacity", "0", "important");
  }

  function applyDebugPreviewState() {
    if (!currentSettings.displayDebugPersistentBox) {
      if (displayEl) {
        hideDisplay(displayEl);
        if (displayTextEl) {
          displayTextEl.textContent = "";
        }
      }
      return;
    }

    const el = getDisplay();
    // Apply all user settings (position, background, etc.) for debug preview
    applyDisplaySettings(el);
    displayTextEl.style.letterSpacing = "6px";
    displayTextEl.textContent = "....";
    showDisplay(el);
  }

  function getDisplay() {
    if (!displayEl) {
      displayEl = document.createElement("div");
      displayEl.id = "gemini-vision-onpage-result";
      displayTextEl = document.createElement("div");
      displayTextEl.id = "gemini-vision-onpage-result-text";
      displayEl.appendChild(displayTextEl);
      document.body.appendChild(displayEl);
      applyDisplaySettings(displayEl);
      log("[Maakima][Content] Display element created.");
    }
    return displayEl;
  }

  async function loadSettingsFromStorage() {
    try {
      const raw = await storageGet([
        "displayFontSize",
        "displayFontColor",
        "displayPosition",
        "displayWhiteBackground",
        "displayDebugPersistentBox",
        "enableDetailedLogging",
      ]);
      currentSettings = sanitizeSettings({ ...DEFAULT_SETTINGS, ...raw });
      if (displayEl) {
        applyDisplaySettings(displayEl);
      }
      applyDebugPreviewState();
      log("[Maakima][Content] Settings loaded:", currentSettings);
    } catch (error) {
      console.error("[Maakima][Content] Failed to load settings:", error);
    }
  }

  function parseOptionNumbers(resultText) {
    if (!resultText) {
      return null;
    }

    const matches = resultText.match(/[1-5]/g);
    if (!matches || matches.length === 0) {
      return null;
    }

    return [...new Set(matches.map(Number))].sort((a, b) => a - b);
  }

  function wait(ms, token) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (token === animationToken) {
          resolve(true);
          return;
        }
        resolve(false);
      }, ms);
    });
  }

  async function showMultipleAnswers(el, answerArray) {
    animationToken += 1;
    const token = animationToken;
    applyDisplaySettings(el);

    for (let i = 0; i < answerArray.length; i += 1) {
      const answer = answerArray[i];
      displayTextEl.style.letterSpacing = "6px";
      displayTextEl.textContent = ".".repeat(answer);
      showDisplay(el);

      if (!(await wait(1000, token))) {
        return;
      }

      el.style.setProperty("opacity", "0", "important");
      if (!(await wait(150, token))) {
        return;
      }
      hideDisplay(el);

      if (i < answerArray.length - 1) {
        if (!(await wait(500, token))) {
          return;
        }
      }
    }
  }

  async function showTextMessage(el, text, durationMs) {
    animationToken += 1;
    const token = animationToken;

    displayTextEl.style.letterSpacing = "0px";
    displayTextEl.style.setProperty(
      "font-size",
      `${Math.max(12, currentSettings.displayFontSize - 8)}px`,
      "important",
    );
    displayTextEl.textContent = text;
    showDisplay(el);

    if (!(await wait(durationMs, token))) {
      return;
    }

    el.style.setProperty("opacity", "0", "important");
    if (!(await wait(160, token))) {
      return;
    }

    hideDisplay(el);
    if (!currentSettings.displayDebugPersistentBox) {
      displayTextEl.textContent = "";
    }
    applyDisplaySettings(el);
  }

  async function showUnderscore(el, durationMs = 1200) {
    animationToken += 1;
    const token = animationToken;

    applyDisplaySettings(el);
    displayTextEl.style.letterSpacing = "6px";
    displayTextEl.textContent = "_";
    showDisplay(el);

    if (!(await wait(durationMs, token))) {
      return;
    }

    el.style.setProperty("opacity", "0", "important");
    if (!(await wait(160, token))) {
      return;
    }

    hideDisplay(el);
    if (!currentSettings.displayDebugPersistentBox) {
      displayTextEl.textContent = "";
    }
  }

  window.addEventListener("auxclick", (e) => {
    if (e.button === 1) {
      e.preventDefault();
      log("[Maakima][Content] Middle click detected. Toggling analysis.");
      try {
        chrome.runtime.sendMessage({ action: "toggle_analysis" });
      } catch (error) {
        if (
          error.message &&
          error.message.includes("Extension context invalidated")
        ) {
          alert("Maakima was updated. Please refresh this page.");
        } else {
          console.error("[Maakima][Content] Runtime messaging error:", error);
        }
      }
    }
  });

  chrome.runtime.onMessage.addListener((request) => {
    const el = getDisplay();

    // Unified preview and actual: when popup sends preview, treat as real settings
    if (
      request.action === "debug_preview_settings" &&
      request.displaySettings
    ) {
      currentSettings = sanitizeSettings({
        ...currentSettings,
        displayFontSize: request.displaySettings.fontSize,
        displayFontColor: request.displaySettings.fontColor,
        displayPosition: request.displaySettings.displayPosition,
        displayWhiteBackground: request.displaySettings.whiteBackground,
        displayDebugPersistentBox: request.displaySettings.debugPersistentBox,
      });
      applyDisplaySettings(el);
      applyDebugPreviewState();
      return;
    }

    if (request.displaySettings) {
      currentSettings = sanitizeSettings({
        ...currentSettings,
        displayFontSize: request.displaySettings.fontSize,
        displayFontColor: request.displaySettings.fontColor,
        displayPosition: request.displaySettings.displayPosition,
        displayWhiteBackground: request.displaySettings.whiteBackground,
        displayDebugPersistentBox: request.displaySettings.debugPersistentBox,
      });
      applyDisplaySettings(el);
      applyDebugPreviewState();
    }

    if (
      currentSettings.displayDebugPersistentBox &&
      (request.action === "show_gemini_loading" ||
        request.action === "show_gemini_result" ||
        request.action === "hide_ui")
    ) {
      // In debug preview mode, keep a static dummy box for visual tuning.
      applyDebugPreviewState();
      return;
    }

    if (request.action === "show_gemini_loading") {
      console.group("[Maakima][Content] Request Started");
      console.log("Timestamp:", new Date().toISOString());
      console.log("Loading UI...");
      console.groupEnd();
      log("[Maakima][Content] Loading signal received.");
      animationToken += 1;
      hideDisplay(el);
      displayTextEl.textContent = "";
      return;
    }

    if (request.action === "show_gemini_result") {
      console.group("[Maakima][Content] Result Received");

      if (request.error) {
        console.error("Analysis Error:", request.errorMessage);
        console.log("Full Request Object:", request);
        console.groupEnd();
        showUnderscore(el, 1200);
        return;
      }

      console.log("Provider Source:", request.providerSource);
      console.log("Provider:", request.provider);
      console.log("Raw AI Output:", request.rawOutput);
      console.log("Parsed Answer Array:", request.parsedAnswers);
      console.log("No Answer Status:", request.noAnswer);
      console.log("No Answer Reason:", request.noAnswerReason);
      console.log("Full Request Object:", request);

      if (request.noAnswer) {
        const reason = request.noAnswerReason || "No visible solvable question";
        console.warn("Model replied but no solvable answer found:", reason);
        console.groupEnd();
        showUnderscore(el, 1200);
        return;
      }

      const answerNumbers =
        Array.isArray(request.parsedAnswers) && request.parsedAnswers.length > 0
          ? request.parsedAnswers
          : parseOptionNumbers(request.result);

      console.log("Final Answer Numbers:", answerNumbers);
      console.groupEnd();

      if (answerNumbers && answerNumbers.length > 0) {
        showMultipleAnswers(el, answerNumbers);
      } else {
        showUnderscore(el, 1200);
      }
      return;
    }

    if (request.action === "hide_ui") {
      animationToken += 1;
      hideDisplay(el);
      displayTextEl.textContent = "";
      log("[Maakima][Content] Hide UI signal received.");
    }
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") {
      return;
    }

    let shouldApply = false;

    if (changes.displayFontSize) {
      currentSettings.displayFontSize = parseSize(
        changes.displayFontSize.newValue,
      );
      shouldApply = true;
    }

    if (changes.displayFontColor) {
      currentSettings.displayFontColor = parseColor(
        changes.displayFontColor.newValue,
      );
      shouldApply = true;
    }

    if (changes.enableDetailedLogging) {
      currentSettings.enableDetailedLogging =
        typeof changes.enableDetailedLogging.newValue === "boolean"
          ? changes.enableDetailedLogging.newValue
          : DEFAULT_SETTINGS.enableDetailedLogging;
    }

    if (changes.displayWhiteBackground) {
      currentSettings.displayWhiteBackground = parseBoolean(
        changes.displayWhiteBackground.newValue,
        DEFAULT_SETTINGS.displayWhiteBackground,
      );
      shouldApply = true;
    }

    if (changes.displayPosition) {
      currentSettings.displayPosition = parsePosition(
        changes.displayPosition.newValue,
      );
      shouldApply = true;
    }

    if (changes.displayDebugPersistentBox) {
      currentSettings.displayDebugPersistentBox = parseBoolean(
        changes.displayDebugPersistentBox.newValue,
        DEFAULT_SETTINGS.displayDebugPersistentBox,
      );
      shouldApply = true;
    }

    if (shouldApply && displayEl) {
      applyDisplaySettings(displayEl);
    }

    if (changes.displayDebugPersistentBox) {
      applyDebugPreviewState();
    }
  });

  loadSettingsFromStorage();
}
