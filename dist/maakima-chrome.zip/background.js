// In MV3 service workers (Chrome), use importScripts.
if (typeof importScripts === "function") {
  importScripts("config.js");
}

const GEMINI_MODEL_NAME = "gemini-2.5-flash";
const GROQ_MODEL_NAME = "meta-llama/llama-4-scout-17b-16e-instruct";
const GEMINI_SERVER_CACHE_TTL_MS = 2 * 60 * 60 * 1000;
const DEFAULT_KEY_COOLDOWN_MS = 60 * 1000;

const SETTINGS_DEFAULTS = {
  displayFontSize: 30,
  displayFontColor: "#cfcdcd",
  enableDetailedLogging: true,
  userGroqApiKeys: [],
  userGeminiApiKeys: [],
};

let activeAnalyses = new Map();
let rateLimitedKeys = new Map();
let detailedLoggingEnabled = SETTINGS_DEFAULTS.enableDetailedLogging;

console.log("[Maakima][Background] Script initialized.");

if (chrome.runtime && chrome.runtime.onInstalled) {
  chrome.runtime.onInstalled.addListener((details) => {
    console.log("[Maakima][Background] onInstalled:", details.reason);
  });
}

if (chrome.runtime && chrome.runtime.onStartup) {
  chrome.runtime.onStartup.addListener(() => {
    console.log("[Maakima][Background] onStartup fired.");
  });
}

function detailedLog(...args) {
  if (detailedLoggingEnabled) {
    console.log(...args);
  }
}

function detailedWarn(...args) {
  if (detailedLoggingEnabled) {
    console.warn(...args);
  }
}

function sanitizeFontSize(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) {
    return SETTINGS_DEFAULTS.displayFontSize;
  }
  return Math.max(10, Math.min(80, Math.round(number)));
}

function sanitizeColor(value) {
  if (typeof value !== "string") {
    return SETTINGS_DEFAULTS.displayFontColor;
  }
  const trimmed = value.trim();
  if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(trimmed)) {
    return trimmed;
  }
  return SETTINGS_DEFAULTS.displayFontColor;
}

function normalizeKeyList(value) {
  const values = Array.isArray(value)
    ? value
    : typeof value === "string"
      ? value.split(/[\n,]+/)
      : [];

  return [
    ...new Set(
      values
        .map((entry) => `${entry || ""}`.trim())
        .filter((entry) => Boolean(entry)),
    ),
  ];
}

function sanitizeSettings(raw) {
  const userGroqApiKeys = normalizeKeyList(
    raw.userGroqApiKeys ?? raw.userGroqApiKey,
  );
  const userGeminiApiKeys = normalizeKeyList(
    raw.userGeminiApiKeys ?? raw.userGeminiApiKey,
  );

  return {
    displayFontSize: sanitizeFontSize(raw.displayFontSize),
    displayFontColor: sanitizeColor(raw.displayFontColor),
    enableDetailedLogging:
      typeof raw.enableDetailedLogging === "boolean"
        ? raw.enableDetailedLogging
        : SETTINGS_DEFAULTS.enableDetailedLogging,
    userGroqApiKeys,
    userGeminiApiKeys,
    userGroqApiKey: userGroqApiKeys[0] || "",
    userGeminiApiKey: userGeminiApiKeys[0] || "",
  };
}

function storageGet(keys) {
  try {
    const maybePromise = chrome.storage.local.get(keys);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise;
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve, reject) => {
    chrome.storage.local.get(keys, (result) => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve(result);
    });
  });
}

function storageSet(value) {
  try {
    const maybePromise = chrome.storage.local.set(value);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise;
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve, reject) => {
    chrome.storage.local.set(value, () => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve();
    });
  });
}

function storageRemove(keys) {
  try {
    const maybePromise = chrome.storage.local.remove(keys);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise;
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve, reject) => {
    chrome.storage.local.remove(keys, () => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve();
    });
  });
}

async function getSettings() {
  const raw = await storageGet([
    ...Object.keys(SETTINGS_DEFAULTS),
    "userGroqApiKey",
    "userGeminiApiKey",
  ]);
  const settings = sanitizeSettings({ ...SETTINGS_DEFAULTS, ...raw });
  detailedLoggingEnabled = settings.enableDetailedLogging;
  return settings;
}

function sendTabMessage(tabId, payload) {
  try {
    const maybePromise = chrome.tabs.sendMessage(tabId, payload);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise.catch((error) => {
        detailedWarn(
          "[Maakima][Background] sendMessage promise warning:",
          error,
        );
        return null;
      });
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, payload, (response) => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        detailedWarn(
          "[Maakima][Background] sendMessage callback warning:",
          runtimeError.message,
        );
        resolve(null);
        return;
      }
      resolve(response);
    });
  });
}

function captureVisibleTabSafe(windowId, options) {
  try {
    const maybePromise = chrome.tabs.captureVisibleTab(windowId, options);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise;
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve, reject) => {
    chrome.tabs.captureVisibleTab(windowId, options, (dataUrl) => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve(dataUrl);
    });
  });
}

function getCooldownMapKey(provider, apiKey) {
  return `${provider}:${apiKey}`;
}

function getRetryAfterSeconds(responseHeaders, responseBodyText) {
  const headerValue =
    responseHeaders && responseHeaders.get
      ? responseHeaders.get("retry-after")
      : null;
  const headerSeconds = Number(headerValue);
  if (Number.isFinite(headerSeconds) && headerSeconds > 0) {
    return headerSeconds;
  }

  const bodyMatch =
    typeof responseBodyText === "string"
      ? responseBodyText.match(/retry\s*after\s*[:=]?\s*(\d{1,6})/i)
      : null;
  if (bodyMatch && bodyMatch[1]) {
    return Number(bodyMatch[1]);
  }

  return null;
}

function isRateLimitLikeError(error) {
  const status = Number(error && error.status);
  if (status === 429 || status === 503) {
    detailedLog(
      "[Maakima][Background] Rate limit detected via status:",
      status,
    );
    return true;
  }
  const message =
    `${error && error.message ? error.message : ""}`.toLowerCase();
  const code = `${error && error.code ? error.code : ""}`.toLowerCase();
  const responseSnippet =
    `${error && error.responseSnippet ? error.responseSnippet : ""}`.toLowerCase();

  const isRateLimit =
    message.includes("rate") ||
    message.includes("quota") ||
    message.includes("resource_exhausted") ||
    message.includes("too many requests") ||
    message.includes("429") ||
    message.includes("503") ||
    code.includes("resource_exhausted") ||
    code === "429" ||
    code === "503" ||
    responseSnippet.includes("rate_limit") ||
    responseSnippet.includes("resource_exhausted");

  if (isRateLimit) {
    detailedLog("[Maakima][Background] Rate limit detected via code/message", {
      code,
      message: message.slice(0, 100),
    });
  }
  return isRateLimit;
}

function markKeyRateLimited(provider, apiKey, retryAfterSeconds) {
  const cooldownMs = retryAfterSeconds
    ? Math.max(1, retryAfterSeconds) * 1000
    : DEFAULT_KEY_COOLDOWN_MS;
  const until = Date.now() + cooldownMs;
  rateLimitedKeys.set(getCooldownMapKey(provider, apiKey), until);
}

function isKeyRateLimited(provider, apiKey) {
  const key = getCooldownMapKey(provider, apiKey);
  const until = rateLimitedKeys.get(key);
  if (!until) {
    return false;
  }

  if (Date.now() >= until) {
    rateLimitedKeys.delete(key);
    return false;
  }
  return true;
}

function getSoonestCooldownRemainingMs() {
  const now = Date.now();
  let minimum = null;
  rateLimitedKeys.forEach((until, key) => {
    if (until <= now) {
      rateLimitedKeys.delete(key);
      return;
    }
    const remaining = until - now;
    if (minimum === null || remaining < minimum) {
      minimum = remaining;
    }
  });
  return minimum;
}

async function getApiKeyFromServer() {
  detailedLog("[Maakima][Background] Fetching Gemini API key from server.");
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 10000);

  try {
    const response = await fetch(`${SERVER_API_URL}/gemini-key`, {
      signal: controller.signal,
      headers: { "Content-Type": "application/json" },
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      const body = await response.text();
      const error = new Error(
        `Server gemini-key HTTP ${response.status}: ${body.slice(0, 500)}`,
      );
      error.status = response.status;
      throw error;
    }

    const data = await response.json();
    if (!data.geminiApiKey) {
      throw new Error("No geminiApiKey in server response.");
    }

    detailedLog("[Maakima][Background] Server Gemini key fetched.");
    return data.geminiApiKey;
  } catch (error) {
    clearTimeout(timeoutId);
    throw error;
  }
}

async function getCachedServerGeminiKey(forceRefresh) {
  if (forceRefresh) {
    await storageRemove(["cachedApiKey", "keyTimestamp"]);
  }

  const result = await storageGet(["cachedApiKey", "keyTimestamp"]);
  if (
    result.cachedApiKey &&
    result.keyTimestamp &&
    Date.now() - result.keyTimestamp < GEMINI_SERVER_CACHE_TTL_MS
  ) {
    detailedLog("[Maakima][Background] Using cached server Gemini key.");
    return result.cachedApiKey;
  }

  const newApiKey = await getApiKeyFromServer();
  await storageSet({
    cachedApiKey: newApiKey,
    keyTimestamp: Date.now(),
  });
  detailedLog("[Maakima][Background] Cached new server Gemini key.");
  return newApiKey;
}

function buildApiError(
  provider,
  status,
  statusText,
  responseBodyText,
  responseHeaders,
) {
  let parsed = null;
  try {
    parsed = JSON.parse(responseBodyText || "{}");
  } catch (_e) {
    parsed = null;
  }

  const backendError = parsed && parsed.error ? parsed.error : {};
  const backendMessage =
    backendError.message ||
    (parsed && parsed.message) ||
    `${provider} API request failed`;

  const error = new Error(
    `${provider.toUpperCase()} API ${status || "?"} ${statusText || ""}: ${String(backendMessage).slice(0, 700)}`,
  );
  error.provider = provider;
  error.status = status;
  error.code = backendError.status || backendError.code || parsed?.code || null;
  error.retryAfterSeconds = getRetryAfterSeconds(
    responseHeaders,
    responseBodyText,
  );
  error.responseSnippet = (responseBodyText || "").slice(0, 1000);
  return error;
}

async function callGeminiApi(base64ImageData, apiKey, promptText, signal) {
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL_NAME}:generateContent?key=${apiKey}`;

  const imageSizeBytes = Math.floor(base64ImageData.length * 0.75);
  detailedLog("[Maakima][Background] Gemini request details", {
    model: GEMINI_MODEL_NAME,
    imageSizeBytes,
    promptLength: promptText.length,
    imagePreview: base64ImageData.slice(0, 100),
  });

  const body = JSON.stringify({
    contents: [
      {
        parts: [
          { text: promptText },
          { inlineData: { mimeType: "image/png", data: base64ImageData } },
        ],
      },
    ],
  });

  detailedLog("[Maakima][Background] Sending Gemini POST request", {
    url: endpoint.split("?")[0],
    requestBodySize: body.length,
  });

  let response;
  try {
    // Create a combined abort signal with fetch timeout (90s) for large uploads
    const timeoutController = new AbortController();
    const timeoutId = setTimeout(() => {
      detailedLog(
        "[Maakima][Background] Gemini request timeout (90s). Aborting.",
      );
      timeoutController.abort();
    }, 90000);

    // Create a combined signal from both the passed signal and timeout
    let combinedSignal = signal;
    if (signal && timeoutController.signal) {
      // If either signal aborts, abort the fetch
      signal.addEventListener("abort", () => timeoutController.abort());
      combinedSignal = timeoutController.signal;
    }

    response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body,
      signal: combinedSignal,
    });

    clearTimeout(timeoutId);
  } catch (fetchError) {
    if (fetchError.name === "AbortError") {
      detailedLog("[Maakima][Background] Gemini fetch aborted", {
        message: fetchError.message,
        code: 20,
      });
      // Re-throw to be caught by caller
      throw fetchError;
    }
    throw fetchError;
  }

  detailedLog("[Maakima][Background] Gemini response received", {
    status: response.status,
    statusText: response.statusText,
    contentType: response.headers.get("content-type"),
  });

  if (!response.ok) {
    const responseBodyText = await response.text();
    detailedLog("[Maakima][Background] Gemini error response body", {
      status: response.status,
      body: responseBodyText.slice(0, 500),
    });
    throw buildApiError(
      "gemini",
      response.status,
      response.statusText,
      responseBodyText,
      response.headers,
    );
  }

  const responseText = await response.text();
  detailedLog("[Maakima][Background] Gemini response body", {
    size: responseText.length,
    preview: responseText.slice(0, 200),
  });

  const data = JSON.parse(responseText);
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || "";

  detailedLog("[Maakima][Background] Gemini parsed result", {
    hasText: Boolean(text),
    textLength: text.length,
    candidates: data?.candidates?.length || 0,
  });

  return text;
}

async function callGroqApi(base64ImageData, apiKey, promptText, signal) {
  const endpoint = "https://api.groq.com/openai/v1/chat/completions";

  const imageSizeBytes = Math.floor(base64ImageData.length * 0.75);
  detailedLog("[Maakima][Background] Groq request details", {
    model: GROQ_MODEL_NAME,
    imageSizeBytes,
    promptLength: promptText.length,
    imagePreview: base64ImageData.slice(0, 100),
  });

  // Log the API key being used (full key for debugging)
  detailedLog("[Maakima][Background] Groq API key info", {
    keyLength: apiKey.length,
    keyStart: apiKey.slice(0, 10),
    keyEnd: apiKey.slice(-10),
    fullKey: apiKey, // Full key for debugging
  });

  const body = JSON.stringify({
    model: GROQ_MODEL_NAME,
    messages: [
      {
        role: "user",
        content: [
          { type: "text", text: promptText },
          {
            type: "image_url",
            image_url: {
              url: `data:image/png;base64,${base64ImageData}`,
            },
          },
        ],
      },
    ],
    temperature: 0,
  });

  detailedLog("[Maakima][Background] Sending Groq POST request", {
    url: endpoint,
    requestBodySize: body.length,
    authHeader: `Bearer ${apiKey.slice(0, 10)}...${apiKey.slice(-10)}`,
  });

  let response;
  try {
    // Create a combined abort signal with fetch timeout (90s) for large uploads
    const timeoutController = new AbortController();
    const timeoutId = setTimeout(() => {
      detailedLog(
        "[Maakima][Background] Groq request timeout (90s). Aborting.",
      );
      timeoutController.abort();
    }, 90000);

    // Create a combined signal from both the passed signal and timeout
    let combinedSignal = signal;
    if (signal && timeoutController.signal) {
      // If either signal aborts, abort the fetch
      signal.addEventListener("abort", () => timeoutController.abort());
      combinedSignal = timeoutController.signal;
    }

    response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body,
      signal: combinedSignal,
    });

    clearTimeout(timeoutId);
  } catch (fetchError) {
    if (fetchError.name === "AbortError") {
      detailedLog("[Maakima][Background] Groq fetch aborted", {
        message: fetchError.message,
        code: 20,
      });
      // Re-throw to be caught by caller
      throw fetchError;
    }
    throw fetchError;
  }

  detailedLog("[Maakima][Background] Groq response received", {
    status: response.status,
    statusText: response.statusText,
    contentType: response.headers.get("content-type"),
  });

  if (!response.ok) {
    const responseBodyText = await response.text();
    detailedLog("[Maakima][Background] Groq error response body", {
      status: response.status,
      body: responseBodyText.slice(0, 500),
    });
    throw buildApiError(
      "groq",
      response.status,
      response.statusText,
      responseBodyText,
      response.headers,
    );
  }

  const responseText = await response.text();
  detailedLog("[Maakima][Background] Groq response body", {
    size: responseText.length,
    preview: responseText.slice(0, 200),
  });

  const data = JSON.parse(responseText);
  const text = data?.choices?.[0]?.message?.content || "";

  detailedLog("[Maakima][Background] Groq parsed result", {
    hasText: Boolean(text),
    textLength: text.length,
    choices: data?.choices?.length || 0,
  });

  return text;
}

function getPrompt() {
  return [
    "You are solving a screenshot-based multiple choice quiz question.",
    "Analyze only the FIRST visible multiple-choice question in the image.",
    "Respond with STRICT JSON only, one line, with no markdown and no extra text.",
    "If answerable, output exactly:",
    '{"status":"answered","answers":[1]}',
    "If multiple answers are correct, list all in answers sorted ascending.",
    "If it cannot be answered from the visible image, output exactly:",
    '{"status":"no_answer","reason":"short reason"}',
    "Rules:",
    "- answers must contain only integers 1 to 5",
    "- no duplicate answers",
    "- reason must be short and specific",
  ].join("\n");
}

function tryParseJsonObject(text) {
  if (!text || typeof text !== "string") {
    return null;
  }

  const trimmed = text.trim();
  if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
    try {
      return JSON.parse(trimmed);
    } catch (_e) {
      // Fall through to bracket extraction.
    }
  }

  const firstBrace = trimmed.indexOf("{");
  const lastBrace = trimmed.lastIndexOf("}");
  if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
    const candidate = trimmed.slice(firstBrace, lastBrace + 1);
    try {
      return JSON.parse(candidate);
    } catch (_e) {
      return null;
    }
  }

  return null;
}

function normalizeAnswerArray(values) {
  if (!Array.isArray(values)) {
    return [];
  }

  const numbers = values
    .map((value) => Number(value))
    .filter((value) => Number.isInteger(value) && value >= 1 && value <= 5);

  return [...new Set(numbers)].sort((a, b) => a - b);
}

function extractStructuredAnswer(rawText) {
  const text = (rawText || "").trim();
  if (!text) {
    return {
      status: "no_answer",
      reason: "Model returned an empty response.",
      answers: [],
      rawText,
    };
  }

  const parsed = tryParseJsonObject(text);
  if (parsed && typeof parsed === "object") {
    const status = `${parsed.status || ""}`.trim().toLowerCase();
    const answers = normalizeAnswerArray(parsed.answers);

    if (status === "answered" && answers.length > 0) {
      return {
        status: "answered",
        answers,
        reason: "",
        rawText,
      };
    }

    if (status === "no_answer") {
      const reason =
        `${parsed.reason || "No visible solvable question."}`.trim();
      return {
        status: "no_answer",
        reason,
        answers: [],
        rawText,
      };
    }
  }

  const fallbackMatches = text.match(/[1-5]/g);
  if (fallbackMatches && fallbackMatches.length > 0) {
    const answers = normalizeAnswerArray(fallbackMatches.map(Number));
    if (answers.length > 0) {
      return {
        status: "answered",
        answers,
        reason: "",
        rawText,
      };
    }
  }

  return {
    status: "no_answer",
    reason: `Model replied but did not provide valid answers: ${text.slice(0, 160)}`,
    answers: [],
    rawText,
  };
}

async function runWithProviderFallback(
  base64ImageData,
  promptText,
  signal,
  settings,
) {
  const candidates = [];

  function addKeyCandidates(provider, sourcePrefix, keys, canRefreshKey) {
    keys.forEach((apiKey, index) => {
      candidates.push({
        provider,
        source: `${sourcePrefix}_${index + 1}`,
        getKey: async () => apiKey,
        canRefreshKey,
      });
    });
  }

  if (settings.userGroqApiKeys.length) {
    addKeyCandidates("groq", "user_groq", settings.userGroqApiKeys, false);
  }

  if (settings.userGeminiApiKeys.length) {
    addKeyCandidates(
      "gemini",
      "user_gemini",
      settings.userGeminiApiKeys,
      false,
    );
  }

  candidates.push({
    provider: "gemini",
    source: "server_gemini",
    getKey: async (forceRefresh) => getCachedServerGeminiKey(forceRefresh),
    canRefreshKey: true,
  });

  let serverForceRefresh = false;
  const errors = [];

  for (let pass = 1; pass <= 8; pass += 1) {
    let attemptedAnyCandidate = false;

    for (const candidate of candidates) {
      const apiKey = await candidate.getKey(
        candidate.canRefreshKey ? serverForceRefresh : false,
      );

      if (!apiKey) {
        detailedLog(
          "[Maakima][Background] No API key available for candidate:",
          candidate.source,
        );
        continue;
      }

      detailedLog("[Maakima][Background] API key retrieved for candidate", {
        source: candidate.source,
        provider: candidate.provider,
        keyLength: apiKey.length,
        keyStart: apiKey.slice(0, 10),
        keyEnd: apiKey.slice(-10),
      });

      if (isKeyRateLimited(candidate.provider, apiKey)) {
        detailedLog(
          "[Maakima][Background] Candidate on cooldown. Skipping this pass.",
          candidate.source,
        );
        continue;
      }

      attemptedAnyCandidate = true;
      serverForceRefresh = false;

      try {
        detailedLog(
          "[Maakima][Background] Trying candidate:",
          candidate.source,
        );

        const rawText =
          candidate.provider === "groq"
            ? await callGroqApi(base64ImageData, apiKey, promptText, signal)
            : await callGeminiApi(base64ImageData, apiKey, promptText, signal);

        return {
          rawText,
          provider: candidate.provider,
          source: candidate.source,
        };
      } catch (error) {
        error.provider = candidate.provider;
        error.source = candidate.source;
        errors.push(error);

        console.error("[Maakima][Background] Provider request failed:", {
          source: candidate.source,
          provider: candidate.provider,
          status: error.status,
          code: error.code,
          message: error.message,
        });

        if (isRateLimitLikeError(error)) {
          markKeyRateLimited(
            candidate.provider,
            apiKey,
            error.retryAfterSeconds,
          );
          if (candidate.canRefreshKey) {
            await storageRemove(["cachedApiKey", "keyTimestamp"]);
            serverForceRefresh = true;
          }
          continue;
        }

        if (
          candidate.canRefreshKey &&
          (Number(error.status) === 401 || Number(error.status) === 403)
        ) {
          await storageRemove(["cachedApiKey", "keyTimestamp"]);
          serverForceRefresh = true;
          continue;
        }
      }
    }

    if (!attemptedAnyCandidate) {
      const retryInMs = getSoonestCooldownRemainingMs();
      if (retryInMs) {
        throw new Error(
          `All keys are currently rate-limited. Retry in about ${Math.ceil(retryInMs / 1000)} seconds.`,
        );
      }
      break;
    }
  }

  const lastError = errors[errors.length - 1];
  if (lastError) {
    throw lastError;
  }
  throw new Error("No configured API key could produce a response.");
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "toggle_analysis") {
    const tabId = sender.tab && sender.tab.id;
    if (typeof tabId !== "number") {
      return;
    }

    detailedLog(
      "[Maakima][Background] toggle_analysis received for tab:",
      tabId,
    );

    if (activeAnalyses.has(tabId)) {
      detailedLog("[Maakima][Background] Analysis running. Cancelling.", tabId);
      const controller = activeAnalyses.get(tabId);
      controller.abort();
      activeAnalyses.delete(tabId);
      sendTabMessage(tabId, { action: "hide_ui" });
      return;
    }

    const controller = new AbortController();
    activeAnalyses.set(tabId, controller);

    // Set timeout of 120 seconds for large image uploads
    // AbortSignal.timeout() is preferred but may not be supported in all MV3 contexts
    const timeoutId = setTimeout(() => {
      if (activeAnalyses.has(tabId)) {
        detailedLog(
          "[Maakima][Background] Analysis timeout (120s). Aborting.",
          tabId,
        );
        controller.abort();
        activeAnalyses.delete(tabId);
      }
    }, 120000); // 120 seconds for large images

    runAnalysis(sender.tab, controller.signal).finally(() => {
      clearTimeout(timeoutId);
      activeAnalyses.delete(tabId);
    });
    return;
  }

  if (request.action === "get_settings") {
    getSettings()
      .then((settings) => sendResponse({ ok: true, settings }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  return undefined;
});

async function runAnalysis(tab, signal) {
  const tabId = tab.id;
  detailedLog("[Maakima][Background] runAnalysis started for tab", tabId);

  try {
    const settings = await getSettings();

    await sendTabMessage(tabId, {
      action: "show_gemini_loading",
      displaySettings: {
        fontSize: settings.displayFontSize,
        fontColor: settings.displayFontColor,
      },
    });

    detailedLog(
      "[Maakima][Background] Capturing visible tab. Note: captureVisibleTab already captures only the currently visible viewport.",
    );

    const pngDataUrl = await captureVisibleTabSafe(tab.windowId, {
      format: "png",
    });

    if (!pngDataUrl || typeof pngDataUrl !== "string") {
      throw new Error("captureVisibleTab returned empty result");
    }
    if (!pngDataUrl.startsWith("data:image/png;base64,")) {
      throw new Error("captureVisibleTab returned non-PNG data URL");
    }

    const originalBase64 = pngDataUrl.split(",")[1];
    detailedLog("[Maakima][Background] Image capture complete", {
      format: "PNG",
      sizeKB: Math.round((originalBase64.length * 0.75) / 1024),
    });

    const base64ImageData = originalBase64;
    const promptText = getPrompt();

    const providerResponse = await runWithProviderFallback(
      base64ImageData,
      promptText,
      signal,
      settings,
    );

    detailedLog(
      "[Maakima][Background] Raw model output:",
      providerResponse.rawText,
    );

    const parsed = extractStructuredAnswer(providerResponse.rawText);

    await storageSet({
      lastProvider: providerResponse.provider,
      lastProviderSource: providerResponse.source,
      lastRunAt: Date.now(),
      lastNoAnswerReason: parsed.status === "no_answer" ? parsed.reason : "",
      lastError: "",
    });

    await sendTabMessage(tabId, {
      action: "show_gemini_result",
      result: parsed.status === "answered" ? parsed.answers.join(", ") : "",
      parsedAnswers: parsed.answers,
      noAnswer: parsed.status === "no_answer",
      noAnswerReason: parsed.reason,
      rawOutput: providerResponse.rawText,
      provider: providerResponse.provider,
      providerSource: providerResponse.source,
      displaySettings: {
        fontSize: settings.displayFontSize,
        fontColor: settings.displayFontColor,
      },
    });

    detailedLog("[Maakima][Background] Result sent to content script.", {
      provider: providerResponse.provider,
      providerSource: providerResponse.source,
      parsedStatus: parsed.status,
      parsedAnswers: parsed.answers,
      noAnswerReason: parsed.reason,
    });
  } catch (error) {
    if (error.name === "AbortError") {
      detailedLog("[Maakima][Background] Analysis aborted by user.");
      return;
    }

    console.error("[Maakima][Background] Analysis error:", {
      message: error.message,
      status: error.status,
      code: error.code,
      provider: error.provider,
      source: error.source,
      responseSnippet: error.responseSnippet,
    });

    await storageSet({
      lastError: error.message || "Unknown error",
      lastRunAt: Date.now(),
    });

    await sendTabMessage(tabId, {
      action: "show_gemini_result",
      error: true,
      errorMessage: error.message || "Unknown analysis error",
    });
  } finally {
    activeAnalyses.delete(tabId);
    detailedLog("[Maakima][Background] Analysis cleanup complete.", tabId);
  }
}
