// Background wiring. Chrome MV3 loads the libs through importScripts; Firefox MV2
// lists them in manifest background.scripts (same global scope, same order).
if (typeof importScripts === "function") {
  importScripts(
    "settings.js",
    "log.js",
    "answer.js",
    "gemini.js",
    "keypool.js",
    "import.js",
  );
}

// A click keeps going until an answer, a new click/cancel, or no key can ever serve again
// (user, 2026-10-21). This cap only stops a stuck run: the first pass, the strict-JSON
// retry, backoffs and waits all share it, and each request's timeout is what is left of it.
const CLICK_BUDGET_MS = 10 * 60 * 1000;
const KEEPALIVE_INTERVAL_MS = 20 * 1000;
// Model list and retry timing (F13): fetched on install/update and browser startup only.
const REMOTE_CONFIG_URL = "https://distributed-clients.github.io/config/models.json";
const REMOTE_CONFIG_TIMEOUT_MS = 10 * 1000;
// Old provider storage fields, kept only so the update can clean old storage.
const OLD_PROVIDER_FIELDS = {
  groq: ["userGroqApiKeys", "userGroqApiKey"],
  mistral: ["userMistralApiKeys", "userMistralApiKey"],
  ollama: ["userOllamaApiKeys", "userOllamaApiKey"],
};
const OBSOLETE_STORAGE_KEYS = [
  ...Object.values(OLD_PROVIDER_FIELDS).flat(),
  "geminiConcurrency",
  "keyUsageHistory",
  "geminiRpmPerKey",
  "geminiRpdPerKey",
  "serverGeminiKeyPool",
  "lastProviderSource",
];

const SETTINGS_DEFAULTS = { ...MaakimaSettings.DEFAULTS, userGeminiApiKeys: [], sharedGeminiApiKeys: [] };

// One image at a time across all tabs: the single current run {tabId, controller}.
let currentRun = null;
let keepaliveTimer = null;
let runSeq = 0;

if (typeof self === "object" && self && typeof self.addEventListener === "function") {
  self.addEventListener("error", (event) => {
    MaakimaLog.error("Uncaught error:", event.error || event.message);
    event.preventDefault();
  });
  self.addEventListener("unhandledrejection", (event) => {
    MaakimaLog.error("Unhandled rejection:", event.reason);
    event.preventDefault();
  });
}

MaakimaLog.info("Background script initialized.");

// --- chrome.* helpers: callback style works in Chrome MV3 and Firefox MV2 alike ---

function chromeCall(api, method, ...args) {
  return new Promise((resolve, reject) => {
    api[method](...args, (result) => {
      const runtimeError = chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(`${method}: ${runtimeError.message}`));
        return;
      }
      resolve(result);
    });
  });
}

const storageGet = (keys) => chromeCall(chrome.storage.local, "get", keys);
const storageSet = (value) => chromeCall(chrome.storage.local, "set", value);
const storageRemove = (keys) => chromeCall(chrome.storage.local, "remove", keys);
// keypool keeps one in-memory state per storage object; a new object forces a reload.
let poolStorage = { get: storageGet, set: storageSet };

function sendTabMessage(tabId, payload) {
  return chromeCall(chrome.tabs, "sendMessage", tabId, payload).catch(
    (error) => {
      // content.js never answers, so Chrome reports "message port closed" on every send.
      MaakimaLog.debug(`sendMessage ${payload.action} to tab ${tabId}:`, error);
      return null;
    },
  );
}

function captureVisibleTabSafe(windowId, options) {
  return chromeCall(chrome.tabs, "captureVisibleTab", windowId, options);
}

// AbortSignal.any + AbortSignal.timeout stand-in (Firefox 124/100; the floor is 72).
// The link aborts when any input does or timeoutMs passes; done() (call it in a finally)
// drops the input listeners and the timer. timedOut() tells a timeout from a cancel where
// abort(reason) is ignored (Firefox < 97) and fetch rejects with a plain AbortError.
function linkSignals(signals, timeoutMs) {
  const controller = new AbortController();
  const inputs = signals.filter(Boolean);
  let timer = null;
  let timedOut = false;
  const done = () => {
    clearTimeout(timer);
    for (const s of inputs) s.removeEventListener("abort", onAbort);
  };
  const abort = (reason) => {
    done();
    controller.abort(reason);
  };
  function onAbort(event) {
    abort(event.target.reason);
  }
  const first = inputs.find((s) => s.aborted);
  if (first) {
    controller.abort(first.reason);
  } else {
    for (const s of inputs) s.addEventListener("abort", onAbort);
    if (timeoutMs != null) {
      timer = setTimeout(() => {
        timedOut = true;
        abort(new DOMException("The operation timed out.", "TimeoutError"));
      }, timeoutMs);
    }
  }
  return { signal: controller.signal, done, timedOut: () => timedOut };
}

// --- Settings ---

function sanitizeSettings(raw) {
  // Only Gemini-shaped keys reach the pool: a stored gsk_ or malformed entry is never sent.
  const userGeminiApiKeys = MaakimaImport.normalizeGeminiKeys({
    gemini: raw.userGeminiApiKeys ?? raw.userGeminiApiKey,
  }).keys;
  // The shared list (remote import, F14) goes through the same filter.
  const sharedGeminiApiKeys = MaakimaImport.normalizeGeminiKeys({
    gemini: raw.sharedGeminiApiKeys,
  }).keys;

  return {
    ...MaakimaSettings.sanitizeDisplay(raw),
    userGeminiApiKeys,
    userGeminiApiKey: userGeminiApiKeys[0] || "",
    sharedGeminiApiKeys,
  };
}

async function getSettings() {
  const raw = await storageGet([
    ...Object.keys(SETTINGS_DEFAULTS),
    "userGeminiApiKey",
  ]);
  const settings = sanitizeSettings({ ...SETTINGS_DEFAULTS, ...raw });
  MaakimaLog.setVerbose(settings.enableDetailedLogging);
  return settings;
}

// Sent with every loading/result message; content.js keeps its logging switch in step.
const displaySettingsOf = MaakimaSettings.toMessage;

// Re-files Gemini-shaped keys from the old provider fields (update only) into the stored
// Gemini list and drops gsk_/malformed entries (import.js's normaliser). Writes only on change.
async function cleanStoredGeminiKeys(oldProviderFields = {}) {
  const stored = await storageGet([
    "userGeminiApiKeys",
    "userGeminiApiKey",
    ...Object.values(oldProviderFields).flat(),
  ]);
  const oldLists = Object.fromEntries(
    Object.entries(oldProviderFields).map(([provider, fields]) => [
      provider,
      fields.flatMap((field) => MaakimaImport.normalizeKeyList(stored[field])),
    ]),
  );
  const n = MaakimaImport.normalizeGeminiKeys({
    // The singular is only a fallback (as in sanitizeSettings): a stale one must not
    // bring back a key the user removed from the list.
    gemini: stored.userGeminiApiKeys ?? stored.userGeminiApiKey,
    ...oldLists,
  });
  const before = MaakimaImport.normalizeKeyList(stored.userGeminiApiKeys);
  const changed =
    JSON.stringify(before) !== JSON.stringify(n.keys) ||
    (stored.userGeminiApiKey || "") !== (n.keys[0] || "");
  if (changed) {
    await storageSet({ userGeminiApiKeys: n.keys, userGeminiApiKey: n.keys[0] || "" });
  }
  MaakimaLog.info(
    `Stored Gemini keys checked: ${n.keys.length} kept, refiled ${n.refiled} from old provider lists, dropped ${n.dropped} malformed/gsk_ entries${changed ? "" : " (no change)"}.`,
  );
  return n;
}

async function migrateOnUpdate() {
  await cleanStoredGeminiKeys(OLD_PROVIDER_FIELDS);
  await storageRemove(OBSOLETE_STORAGE_KEYS);
  MaakimaLog.info(`Removed old storage keys: ${OBSOLETE_STORAGE_KEYS.join(", ")}`);
}

// Stores the key-health summary for the popup (user counts plus `shared` counts).
async function afterRun(models) {
  const state = await MaakimaKeyPool.load(poolStorage);
  await storageSet({ geminiKeySummary: MaakimaKeyPool.summary(state, Date.now(), models) });
}

// --- Remote model config (site/config/models.json; data only, validated by gemini.js) ---

// Fetches and caches the file. On any failure the cache stays as it is; the log says
// whether the cached copy or the built-in defaults are what runs will use.
async function refreshRemoteConfig() {
  const link = linkSignals([], REMOTE_CONFIG_TIMEOUT_MS);
  try {
    const response = await fetch(REMOTE_CONFIG_URL, { cache: "no-store", signal: link.signal });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const config = MaakimaGemini.parseRemoteConfig(await response.json());
    if (!config) throw new Error("file failed validation");
    await storageSet({ remoteModelConfig: config });
    MaakimaLog.info(`Remote model config loaded: ${config.models.map((m) => m.id).join(", ")}.`);
  } catch (error) {
    const cached = await cachedModelConfig();
    MaakimaLog.warn(
      `Remote model config not used (${error.message || error}); using ${cached ? "the cached copy" : "the built-in defaults"}.`,
    );
  } finally {
    link.done();
  }
}

// The cache is re-validated: one written by another build must not bypass the checks.
async function cachedModelConfig() {
  const { remoteModelConfig } = await storageGet(["remoteModelConfig"]);
  if (!remoteModelConfig || typeof remoteModelConfig !== "object") return null;
  return MaakimaGemini.parseRemoteConfig({ ...remoteModelConfig, version: 1 });
}

// {models, retry} for one run: the cached remote config, else the built-in defaults.
async function runConfig() {
  const cached = await cachedModelConfig();
  return {
    models: cached ? cached.models : MaakimaGemini.modelList(),
    retry: { ...MaakimaKeyPool.RETRY, ...(cached ? cached.retry : {}) },
  };
}

// --- Keepalive: an extension API call every 20 s resets Chrome's idle timers ---

function updateKeepalive() {
  if (currentRun && keepaliveTimer === null) {
    keepaliveTimer = setInterval(() => {
      chrome.runtime.getPlatformInfo(() => {
        const runtimeError = chrome.runtime.lastError;
        if (runtimeError) {
          MaakimaLog.warn("Keepalive getPlatformInfo failed:", runtimeError.message);
        }
      });
    }, KEEPALIVE_INTERVAL_MS);
  } else if (!currentRun && keepaliveTimer !== null) {
    clearInterval(keepaliveTimer);
    keepaliveTimer = null;
  }
}

// --- Analysis ---

// A plain object, not a function: keypool calls a function log at one level only.
const poolLog = {
  debug: (...args) => MaakimaLog.debug("[pool]", ...args),
  info: (...args) => MaakimaLog.info("[pool]", ...args),
  warn: (...args) => MaakimaLog.warn("[pool]", ...args),
  error: (...args) => MaakimaLog.error("[pool]", ...args),
};

function exhaustedMessage(error) {
  const s = error.summary || {};
  // Top-level counts are the user's keys; `shared` holds the shared list's counts.
  const sh = s.shared || {};
  const cooling = (s.cooling || 0) + (sh.cooling || 0);
  const day = (s.day || 0) + (sh.day || 0);
  const dead = (s.dead || 0) + (sh.dead || 0);
  const ready = (s.ready || 0) + (sh.ready || 0);
  const total = ready + cooling + day + dead;
  if (total === 0) {
    return "No Gemini keys available. Add a key in the popup.";
  }
  if (ready > 0) {
    // Keys were usable; the click ran out of time, not out of keys.
    return `No answer within ${CLICK_BUDGET_MS / 60000} min: ${error.message}.`;
  }
  if (day === total) {
    const reset = new Date(MaakimaKeyPool.nextPacificMidnightMs(Date.now()));
    const local = reset.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });
    return `All ${total} keys used up until 00:00 Pacific (${local} local).`;
  }
  const parts = [];
  if (cooling) parts.push(`${cooling} cooling`);
  if (day) parts.push(`${day} used up for today`);
  if (dead) {
    const labels = (s.deadLabels || []).join("; ");
    parts.push(`${dead} unusable${labels ? ` (${labels})` : ""}`);
  }
  return `All ${total} keys unavailable: ${parts.join(", ")}.`;
}

function errorMessageOf(error) {
  if (error && error.name === "PoolExhaustedError") {
    return exhaustedMessage(error);
  }
  if (error && error.name === "OverloadedError") {
    return error.message || "Gemini is overloaded, try again shortly.";
  }
  if (error && error.name === "FatalRequestError") {
    const reason = error.verdict && error.verdict.reason;
    return `Gemini rejected the request: ${reason || error.message}`;
  }
  return (error && error.message) || "Unknown analysis error";
}

async function captureScaledJpegBase64(tab) {
  let captureDataUrl = await captureVisibleTabSafe(tab.windowId, {
    format: "jpeg",
    quality: 60,
  });
  if (!captureDataUrl || typeof captureDataUrl !== "string") {
    throw new Error("captureVisibleTab returned empty result");
  }

  try {
    const response = await fetch(captureDataUrl);
    const blob = await response.blob();
    const bitmap = await createImageBitmap(blob);
    let width = bitmap.width;
    let height = bitmap.height;
    if (width > 1200) {
      height = Math.round((height * 1200) / width);
      width = 1200;
      // OffscreenCanvas is Firefox 105; Firefox's MV2 background page has a DOM canvas.
      const canvas = typeof OffscreenCanvas === "function"
        ? new OffscreenCanvas(width, height)
        : Object.assign(document.createElement("canvas"), { width, height });
      const ctx = canvas.getContext("2d");
      ctx.drawImage(bitmap, 0, 0, width, height);
      const scaledBlob = canvas.convertToBlob
        ? await canvas.convertToBlob({ type: "image/jpeg", quality: 0.6 })
        : await new Promise((resolve, reject) =>
          canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("canvas.toBlob gave no blob"))), "image/jpeg", 0.6));
      captureDataUrl = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(scaledBlob);
      });
    }
  } catch (err) {
    MaakimaLog.warn("Image scaling failed, using the original capture:", err);
  }

  const base64 = captureDataUrl.split(",")[1] || "";
  MaakimaLog.debug(
    `Image capture complete: ${Math.round((base64.length * 0.75) / 1024)} KB JPEG.`,
  );
  return base64;
}

// One pool run, inside what is left of the click budget. Keys are read from storage on
// every pick, so concurrent runs (two tabs) sync the shared pool state to the same lists.
// Resolves to the Gemini result (with its model); throws PoolExhaustedError,
// OverloadedError, FatalRequestError or AbortError.
async function askGemini(promptText, base64Jpeg, signal, { models, retry }, deadline) {
  return MaakimaKeyPool.run({
    getUserKeys: async () => (await getSettings()).userGeminiApiKeys,
    getSharedKeys: async () => (await getSettings()).sharedGeminiApiKeys,
    models,
    retry,
    deadline, // absolute ms: both passes of a click share one cap
    signal,
    storage: poolStorage,
    log: poolLog,
    classify: MaakimaGemini.classify,
    attempt: async (apiKey, meta = {}) => {
      const { model, attemptNo } = meta;
      const label = meta.source === "shared" ? `${meta.label} shared` : meta.label;
      const started = Date.now();
      const timeoutMs = Math.max(1, deadline - started);
      const link = linkSignals([signal, meta.signal], timeoutMs);
      try {
        const result = await MaakimaGemini.call({
          apiKey,
          model,
          generationConfig: (models.find((m) => m.id === model) || {}).generationConfig,
          promptText,
          base64Jpeg,
          signal: link.signal,
        });
        MaakimaLog.info(
          `Gemini attempt ${attemptNo} key ${label} (${model}): 200 in ${Date.now() - started} ms, finishReason ${result.finishReason}, blockReason ${result.blockReason}, promptTokens ${result.promptTokenCount}.`,
        );
        return { ...result, model };
      } catch (caught) {
        const error = link.timedOut() && caught && caught.name === "AbortError"
          ? new DOMException("The operation timed out.", "TimeoutError")
          : caught;
        MaakimaLog.warn(
          `Gemini attempt ${attemptNo} key ${label} (${model}): ${error.status || error.name} after ${Date.now() - started} ms (timeout ${timeoutMs} ms):`,
          error.bodyText || error.message,
        );
        throw error;
      } finally {
        link.done();
      }
    },
  });
}

// The page only ever gets loading dots, the answer, or "_": no reason text, no model
// output. Reasons go to lastError / lastNoAnswerReason (popup) and the log.
async function runAnalysis(tab, controller, runId = ++runSeq) {
  const tabId = tab.id;
  const signal = controller.signal;
  const deadline = Date.now() + CLICK_BUDGET_MS;
  MaakimaLog.debug(`runAnalysis started for tab ${tabId}.`);
  let config = { models: MaakimaGemini.modelList() };

  try {
    const settings = await getSettings();
    config = await runConfig();
    await sendTabMessage(tabId, {
      action: "show_gemini_loading",
      runId,
      displaySettings: displaySettingsOf(settings),
    });

    const base64 = await captureScaledJpegBase64(tab);

    let response = await askGemini(
      MaakimaAnswer.getPrompt(),
      base64,
      signal,
      config,
      deadline,
    );
    if (!MaakimaAnswer.tryParseJsonObject(response.text)) {
      const leftMs = deadline - Date.now();
      if (leftMs > 0) {
        MaakimaLog.warn(`No parsable JSON in the first answer; retrying with the strict JSON prompt in the remaining ${leftMs} ms.`);
        response = await askGemini(
          MaakimaAnswer.getSimpleStrictJsonPrompt(),
          base64,
          signal,
          config,
          deadline,
        );
      } else {
        MaakimaLog.warn("No parsable JSON in the first answer and no time left for the strict retry.");
      }
    }

    if (signal.aborted) {
      MaakimaLog.info(`Analysis on tab ${tabId} was replaced; dropping its late answer.`);
      return;
    }

    const rawText = (response && response.text) || "";
    MaakimaLog.debug("Raw model output:", rawText);
    const parsed = MaakimaAnswer.extractStructuredAnswer(rawText);

    await storageSet({
      lastProvider: response.model,
      lastRunAt: Date.now(),
      lastNoAnswerReason: parsed.status === "no_answer" ? parsed.reason : "",
      lastError: "",
    });

    await sendTabMessage(tabId, {
      action: "show_gemini_result",
      runId,
      result: parsed.status === "answered" ? parsed.answers.join(", ") : "",
      parsedAnswers: parsed.answers,
      noAnswer: parsed.status === "no_answer",
      displaySettings: displaySettingsOf(settings),
    });

    MaakimaLog.info(
      `Result sent to tab ${tabId}: ${parsed.status} ${JSON.stringify(parsed.answers || [])} ${parsed.reason || ""}`,
    );
  } catch (error) {
    if ((error && error.name === "AbortError") || signal.aborted) {
      MaakimaLog.info(`Analysis on tab ${tabId} cancelled.`, error);
      return;
    }
    const message = errorMessageOf(error);
    MaakimaLog.error(`Analysis on tab ${tabId} failed: ${message}`, error);
    try {
      await storageSet({ lastError: message, lastRunAt: Date.now() });
    } catch (storeError) {
      MaakimaLog.error("Could not store lastError:", storeError);
    }
    await sendTabMessage(tabId, {
      action: "show_gemini_result",
      runId,
      error: true,
    });
  } finally {
    if (currentRun && currentRun.controller === controller) currentRun = null;
    updateKeepalive();
    try {
      await afterRun(config.models);
    } catch (error) {
      MaakimaLog.error("Key summary update failed:", error);
    }
    await MaakimaLog.flush();
  }
}

function startAnalysis(tab) {
  const tabId = tab.id;
  if (currentRun) {
    MaakimaLog.info(`Analysis running on tab ${currentRun.tabId}; cancelling it for a click on tab ${tabId}.`);
    currentRun.controller.abort();
    sendTabMessage(currentRun.tabId, { action: "hide_ui" });
  }
  const controller = new AbortController();
  currentRun = { tabId, controller };
  updateKeepalive();
  return runAnalysis(tab, controller, ++runSeq);
}

// Navigation or closing the tab ends its run: every in-flight attempt shares the signal.
function abortTabRun(tabId, why) {
  if (!currentRun || currentRun.tabId !== tabId) return;
  currentRun.controller.abort();
  currentRun = null;
  updateKeepalive();
  MaakimaLog.info(`Analysis on tab ${tabId} cancelled: ${why}.`);
}

// Saving the key list gives its dead keys a fresh chance. Chrome fires no onChanged for an
// identical value, so the popup also writes geminiKeysSavedAt on every save.
async function reviveSavedKeys() {
  const keys = (await getSettings()).userGeminiApiKeys;
  const state = await MaakimaKeyPool.load(poolStorage);
  let revived = 0;
  for (const apiKey of keys) {
    const entry = state.keys[apiKey];
    if (entry && entry.deadUntil > Date.now()) {
      entry.deadUntil = 0;
      entry.deadReason = null;
      revived += 1;
    }
  }
  if (revived === 0) return;
  // ponytail: a run already in flight saves its older in-memory state and undoes this; the next save of the keys fixes it.
  await MaakimaKeyPool.save(poolStorage, state);
  poolStorage = { get: storageGet, set: storageSet };
  MaakimaLog.info(`Gemini keys saved: cleared the dead mark on ${revived} keys.`);
}

// --- Listeners ---

chrome.runtime.onInstalled.addListener((details) => {
  try {
    MaakimaLog.info(`onInstalled: ${details.reason}`);
    if (details.reason === "update") {
      migrateOnUpdate().catch((error) =>
        MaakimaLog.error("Update migration failed:", error),
      );
    }
    refreshRemoteConfig().catch((error) =>
      MaakimaLog.error("Remote model config refresh failed:", error),
    );
  } catch (error) {
    MaakimaLog.error("onInstalled handler failed:", error);
  }
});

chrome.runtime.onStartup.addListener(() => {
  try {
    MaakimaLog.info("onStartup");
    refreshRemoteConfig().catch((error) =>
      MaakimaLog.error("Remote model config refresh failed:", error),
    );
  } catch (error) {
    MaakimaLog.error("onStartup handler failed:", error);
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  try {
    abortTabRun(tabId, "tab closed");
  } catch (error) {
    MaakimaLog.error("tabs.onRemoved handler failed:", error);
  }
});

// changeInfo.url needs the "tabs" permission or a host permission: <all_urls> covers it.
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  try {
    if (changeInfo.url || changeInfo.status === "loading") {
      abortTabRun(tabId, changeInfo.url ? "tab navigated" : "tab reloading");
    }
  } catch (error) {
    MaakimaLog.error("tabs.onUpdated handler failed:", error);
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  try {
    if (area !== "local") return;
    if (!changes.userGeminiApiKeys && !changes.geminiKeysSavedAt) return;
    reviveSavedKeys().catch((error) =>
      MaakimaLog.error("Clearing dead keys failed:", error),
    );
  } catch (error) {
    MaakimaLog.error("storage.onChanged handler failed:", error);
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  try {
    if (request.action === "toggle_analysis") {
      const tab = sender.tab;
      if (!tab || typeof tab.id !== "number") return undefined;
      startAnalysis(tab);
      return undefined;
    }

    if (request.action === "log_lines") {
      if (Array.isArray(request.lines)) {
        const tabId = sender.tab ? sender.tab.id : "?";
        MaakimaLog.ingest(request.lines, `content tab ${tabId}`);
      }
      return undefined;
    }

    if (request.action === "import_remote_user_key") {
      MaakimaImport.performRemoteImport(request.userKey, {
        fetchImpl: (...args) => fetch(...args),
        storageGet,
        storageSet,
      })
        .then(async ({ user, ignored, refiled, dropped }) => {
          MaakimaLog.info(
            `Remote import for ${user}: refiled ${refiled || 0} Gemini keys from old provider lists, dropped ${dropped || 0} malformed/gsk_ entries; ignored entries:`,
            ignored,
          );
          // Entries stored by older builds (gsk_, malformed) survive the merge; clean them too.
          await cleanStoredGeminiKeys();
          sendResponse({ success: true, user, ignored, refiled, dropped });
        })
        .catch((error) => {
          MaakimaLog.error("Remote import failed:", error);
          sendResponse({ success: false, error: error.message });
        });
      return true;
    }
  } catch (error) {
    MaakimaLog.error("onMessage handler failed:", error);
  }
  return undefined;
});

var MaakimaBackground = {
  runAnalysis,
  startAnalysis,
  sanitizeSettings,
  linkSignals,
  askGemini,
  getCurrentRun: () => currentRun,
};
if (typeof module === "object" && module.exports) module.exports = MaakimaBackground;
