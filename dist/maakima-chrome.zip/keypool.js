// Gemini key pool over (key, model) pairs: the user's own keys first (least
// recently used), then the shared list at random; the main model first, a fallback model when the main one is full, cooling or was
// overloaded in this run. Each pair is paced by an RPM sliding window and an RPD
// counter that resets at midnight Pacific, using the limit a 429 stated, else the
// model's default. Pure apart from run(); never logs itself except through `log`.
var MaakimaKeyPool = (function () {
  "use strict";

  const STORAGE_KEY = "geminiKeyState";
  const WINDOW_MS = 60000;
  const MAX_SILENT_WAIT_MS = 300000;
  // One safety cap per click (first pass and strict retry share it via `deadline`);
  // a click otherwise runs until an answer, a cancel, or no key can ever serve.
  const MAX_RUN_MS = 600000;
  const HEDGE_MS = 10000;
  const MAX_IN_FLIGHT = 3;
  // Overload backoff: max(min(cap, base * 2^(n-1)) + jitter, Google's hint), held only
  // before the next attempt on the overloaded model; the default is a fixed 2 s ± 0.5 s
  // (B3's fast retry, user 2026-10-21). overloadModelCoolMs: how long an overloaded model
  // ranks last in pick, across clicks (F15).
  const RETRY = { overloadBaseMs: 2000, overloadCapMs: 2000, overloadJitterMs: 500, overloadModelCoolMs: 60000 };
  // The only model v1 state ever paced; v1 counters move under this id on load.
  const V1_MODEL = "gemini-3.5-flash-lite";
  const RPM_MAX = 10000;
  const RPD_MAX = 1000000;
  const DEAD_MS = 24 * 60 * 60 * 1000;
  const TRANSIENT_COOL_MS = 5000;
  const BACKOFF_BASE_MS = 2000;
  const BACKOFF_CAP_MS = 60000;

  let laFormat = null;
  // Pacific wall clock at utcMs, expressed as if it were UTC, minus utcMs.
  function laOffsetMs(utcMs) {
    laFormat = laFormat || new Intl.DateTimeFormat("en-US", {
      timeZone: "America/Los_Angeles", hourCycle: "h23",
      year: "numeric", month: "numeric", day: "numeric",
      hour: "numeric", minute: "numeric", second: "numeric",
    });
    const p = {};
    for (const part of laFormat.formatToParts(utcMs)) p[part.type] = Number(part.value);
    const wall = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second);
    return wall - Math.floor(utcMs / 1000) * 1000;
  }

  function nextPacificMidnightMs(now) {
    const d = new Date(now + laOffsetMs(now)); // Pacific wall clock in UTC fields
    const wall = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + 1);
    let t = wall - laOffsetMs(wall);
    t = wall - laOffsetMs(t); // second pass settles a DST change between the two
    return t;
  }

  function createState() {
    return { version: 2, keys: {}, modelCoolUntil: {} };
  }

  function freshPair(now) {
    return {
      recent: [], dayCount: 0, dayResetAt: nextPacificMidnightMs(now), coolUntil: 0,
      hits: 0, dayOutUntil: 0, lastUsedAt: 0, rpm: null, rpd: null,
    };
  }

  function freshEntry(apiKey, source) {
    return { label: "…" + apiKey.slice(-4), source, deadUntil: 0, deadReason: null, models: {} };
  }

  function cleanList(list) {
    return (Array.isArray(list) ? list : [])
      .filter((k) => typeof k === "string")
      .map((k) => k.trim())
      .filter(Boolean);
  }

  // Rebuilds state.keys in list order (user keys, then shared ones; a key in both
  // lists is a user key), keeping existing entries; each key gets a pair per listed
  // model and loses the pairs of unlisted ones (none given: pairs kept).
  function sync(state, userKeys, now, modelIds, sharedKeys) {
    const old = state.keys || {};
    const next = {};
    const add = (k, source) => {
      if (next[k]) return;
      const e = next[k] = old[k] || freshEntry(k, source);
      e.source = source;
      if (!e.models || typeof e.models !== "object") e.models = {};
      if (Array.isArray(modelIds)) {
        const pairs = {};
        for (const id of modelIds) pairs[id] = e.models[id] || freshPair(now);
        e.models = pairs;
      }
    };
    cleanList(userKeys).forEach((k) => add(k, "user"));
    cleanList(sharedKeys).forEach((k) => add(k, "shared"));
    state.keys = next;
    return state;
  }

  // Drops sends older than the window and resets the day counter when due.
  function refresh(p, now) {
    p.recent = p.recent.filter((t) => t > now - WINDOW_MS);
    if (p.dayResetAt <= now) {
      p.dayCount = 0;
      p.dayResetAt = nextPacificMidnightMs(now);
    }
  }

  // ponytail: a learned limit never expires; a project moved to a paid tier keeps the
  // free-tier pacing until a 429 states the new limit (add an expiry if that happens).
  const limitsOf = (p, m) => ({
    rpm: p.rpm != null ? p.rpm : m ? m.rpm : null,
    rpd: p.rpd != null ? p.rpd : m ? m.rpd : null,
  });
  const isDead = (e, now) => e.deadUntil > now;
  // Set by a "day" verdict, or counter-based (needs rpd). A cooldown that merely
  // crosses midnight is not day-out.
  const isDayOut = (p, now, rpd) =>
    (p.dayOutUntil || 0) > now || (p.dayResetAt > now && rpd != null && p.dayCount >= rpd);
  const isFull = (p, now, rpm) =>
    rpm != null && p.recent.filter((t) => t > now - WINDOW_MS).length >= rpm;

  // Pairs of one key as [pair, model]; models given: listed ones, else every pair present.
  function pairsOf(e, models) {
    return models
      ? models.filter((m) => e.models && e.models[m.id]).map((m) => [e.models[m.id], m])
      : Object.values(e.models || {}).map((p) => [p, null]);
  }

  // Per key: dead; else day if every pair is day-out; else ready if any pair is
  // pickable now; else cooling. Top-level counts and deadLabels are the user's keys;
  // `shared` counts the shared list the same way.
  function summary(state, now, models) {
    const c = { ready: 0, cooling: 0, day: 0, dead: 0, deadLabels: [], at: now,
      shared: { ready: 0, cooling: 0, day: 0, dead: 0 } };
    for (const e of Object.values(state.keys)) {
      const shared = e.source === "shared";
      const into = shared ? c.shared : c;
      if (isDead(e, now)) {
        into.dead++;
        if (!shared) c.deadLabels.push(`${e.label}: ${e.deadReason || "unusable"}`);
        continue;
      }
      const pairs = pairsOf(e, models).map(([p, m]) => [p, limitsOf(p, m)]);
      const live = pairs.filter(([p, l]) => !isDayOut(p, now, l.rpd));
      if (pairs.length && !live.length) into.day++;
      else if (live.some(([p, l]) => p.coolUntil <= now && !isFull(p, now, l.rpm))) into.ready++;
      else into.cooling++;
    }
    return c;
  }

  function reasonText(c, extra) {
    const sh = c.shared;
    const shared = sh.ready + sh.cooling + sh.day + sh.dead
      ? `, shared dead=${sh.dead} day=${sh.day} cooling=${sh.cooling}` : "";
    return `no usable key (dead=${c.dead} day=${c.day} cooling=${c.cooling}${shared})` + (extra ? `; ${extra}` : "");
  }

  // models: [{id, rpm, rpd}] in preference order. opts.exclude: keys never to pick (in
  // flight in this run); opts.avoid: "apiKey|model" pairs overloaded earlier in this run;
  // opts.modelOverloads: overloads per model in this run. Ready pairs are ordered by
  // model not in cooldown (state.modelCoolUntil), fewest overloads of their model in
  // this run, model order, not avoided, oldest use, key order. A cooled model is still
  // picked when no other model has a ready pair, so a cooldown never adds a wait.
  // Shared keys are picked only when no user pair is ready: among the shared pairs
  // that tie on the first three, one at random (opts.rand, default Math.random), since
  // their quota is spent by other users too and can't be predicted.
  function pick(state, now, models, opts) {
    const exclude = (opts && opts.exclude) || new Set();
    const avoid = (opts && opts.avoid) || new Set();
    const overloads = (opts && opts.modelOverloads) || new Map();
    const rand = (opts && opts.rand) || Math.random;
    const entries = Object.entries(state.keys);
    const live = [];
    for (const [k, e] of entries) {
      if (exclude.has(k) || isDead(e, now)) continue;
      models.forEach((m, mi) => {
        const p = e.models && e.models[m.id];
        if (!p) return;
        refresh(p, now);
        const l = limitsOf(p, m);
        if (!isDayOut(p, now, l.rpd)) live.push({ k, e, p, m, mi, rpm: l.rpm });
      });
    }
    const ready = live.filter((c) => c.p.coolUntil <= now && !(c.rpm != null && c.p.recent.length >= c.rpm));
    const cool = state.modelCoolUntil || {};
    const cooled = (c) => (cool[c.m.id] > now ? 1 : 0);
    const rank = (a, b) => (cooled(a) - cooled(b)) ||
      ((overloads.get(a.m.id) || 0) - (overloads.get(b.m.id) || 0)) || (a.mi - b.mi) ||
      (avoid.has(a.k + "|" + a.m.id) - avoid.has(b.k + "|" + b.m.id));
    const chosen = (c) => ({ apiKey: c.k, label: c.e.label, model: c.m.id, source: c.e.source === "shared" ? "shared" : "user" });
    const user = ready.filter((c) => c.e.source !== "shared");
    if (user.length) {
      // Stable sort keeps key order on ties.
      user.sort((a, b) => rank(a, b) || (a.p.lastUsedAt - b.p.lastUsedAt));
      return chosen(user[0]);
    }
    if (ready.length) {
      ready.sort(rank);
      const best = ready.filter((c) => rank(c, ready[0]) === 0);
      return chosen(best[Math.min(best.length - 1, Math.floor(rand() * best.length))]);
    }
    if (live.length) {
      const waitMs = Math.min(...live.map(({ p, rpm }) =>
        Math.max(p.coolUntil, rpm != null && p.recent.length >= rpm ? p.recent[p.recent.length - rpm] + WINDOW_MS : 0))) - now;
      if (waitMs <= MAX_SILENT_WAIT_MS) return { waitMs: Math.max(0, waitMs) };
      return { none: true, reason: reasonText(summary(state, now, models), `next key frees in ${Math.round(waitMs / 1000)} s`) };
    }
    return { none: true, reason: entries.length ? reasonText(summary(state, now, models)) : "no keys configured" };
  }

  const pairOf = (state, apiKey, model) => {
    const e = state.keys[apiKey];
    return e && e.models ? e.models[model] : undefined;
  };

  function markSent(state, apiKey, model, now) {
    const p = pairOf(state, apiKey, model);
    if (!p) return;
    refresh(p, now);
    p.recent.push(now);
    p.dayCount++;
    p.lastUsedAt = now;
  }

  // A stated limit, as an integer clamped to 1..max, or null.
  const learned = (v, max) => (Number.isFinite(v) && v >= 1 ? Math.min(max, Math.floor(v)) : null);

  // sentAt: when this attempt was sent (markSent's now); a bare-429 overload uncounts it.
  function markResult(state, apiKey, model, verdict, now, models, sentAt) {
    const e = state.keys[apiKey];
    if (!e) return;
    if (verdict.kind === "dead") { // key-wide: 401/403/API_KEY_INVALID
      e.deadUntil = now + DEAD_MS;
      e.deadReason = verdict.reason || "unusable";
      return;
    }
    const p = pairOf(state, apiKey, model);
    if (!p) return;
    const perMinute = /PerMinute/.test(verdict.quotaId || "");
    switch (verdict.kind) {
      case "ok":
        p.hits = 0;
        break;
      case "cooldown": {
        p.hits++;
        const rpm = perMinute ? learned(verdict.limit, RPM_MAX) : null;
        if (rpm != null) p.rpm = rpm;
        // No delay given: a per-minute quota frees with the 60 s window, else back off.
        p.coolUntil = verdict.untilMs != null ? verdict.untilMs
          : perMinute ? now + WINDOW_MS
          : now + Math.min(BACKOFF_CAP_MS, BACKOFF_BASE_MS * 2 ** (p.hits - 1));
        break;
      }
      case "day": {
        const rpd = learned(verdict.limit, RPD_MAX);
        if (rpd != null) p.rpd = rpd;
        const m = (models || []).find((x) => x.id === model);
        p.dayResetAt = nextPacificMidnightMs(now);
        p.dayOutUntil = p.dayResetAt;
        p.coolUntil = p.dayResetAt;
        p.dayCount = Math.max(p.dayCount, limitsOf(p, m).rpd || 0);
        break;
      }
      case "transient":
        p.coolUntil = Math.max(p.coolUntil, now + TRANSIENT_COOL_MS);
        break;
      case "overloaded":
        // A bare 429 is not counted by Google (3,173 of them, 0 quota errors), so it must
        // not fill the RPM window or the day count; a 503 may count, so it stays counted.
        if (verdict.status === 429) {
          const i = sentAt != null ? p.recent.lastIndexOf(sentAt) : p.recent.length - 1;
          if (i >= 0) p.recent.splice(i, 1);
          p.dayCount = Math.max(0, p.dayCount - 1);
        }
        break;
      default: // fatal, cancelled: the pair is fine
        break;
    }
  }

  // v1 kept one flat entry per key, paced for V1_MODEL only; server-pool entries
  // (source "server", pool removed) and non-objects are dropped.
  function migrateV1(s) {
    const out = createState();
    for (const [k, e] of Object.entries(s.keys)) {
      if (!e || typeof e !== "object" || e.source === "server") continue;
      const n = (v) => (Number.isFinite(v) ? v : 0);
      out.keys[k] = {
        label: typeof e.label === "string" ? e.label : "…" + k.slice(-4), source: "user",
        deadUntil: n(e.deadUntil), deadReason: e.deadReason || null,
        models: {
          [V1_MODEL]: {
            recent: Array.isArray(e.recent) ? e.recent.filter(Number.isFinite) : [],
            dayCount: n(e.dayCount), dayResetAt: n(e.dayResetAt), coolUntil: n(e.coolUntil),
            hits: n(e.hits), dayOutUntil: n(e.dayOutUntil), lastUsedAt: n(e.lastUsedAt),
            rpm: null, rpd: null,
          },
        },
      };
    }
    return out;
  }

  async function load(storage) {
    const got = await storage.get([STORAGE_KEY]);
    const s = got && got[STORAGE_KEY];
    if (!s || !s.keys || typeof s.keys !== "object") return createState();
    if (s.version === 2) {
      if (!s.modelCoolUntil || typeof s.modelCoolUntil !== "object") s.modelCoolUntil = {};
      return s;
    }
    if (s.version === 1) return migrateV1(s);
    return createState();
  }

  function save(storage, state) {
    return storage.set({ [STORAGE_KEY]: state });
  }

  // Concurrent runs in one worker share one in-memory state per storage object, so
  // pacing holds across clicks. Pass the same storage object to every run.
  const shared = new WeakMap();
  function sharedState(storage) {
    if (!shared.has(storage)) {
      const p = load(storage);
      shared.set(storage, p);
      p.catch(() => shared.delete(storage)); // run() rejects with the load error; retry next run
    }
    return shared.get(storage);
  }

  function abortError(signal) {
    const r = signal && signal.reason;
    return r && r.name === "AbortError" ? r : new DOMException("The operation was aborted.", "AbortError");
  }

  function defaultSleep(ms, signal) {
    return new Promise((resolve, reject) => {
      if (signal && signal.aborted) return reject(abortError(signal));
      const onAbort = () => { clearTimeout(timer); reject(abortError(signal)); };
      const timer = setTimeout(() => {
        if (signal) signal.removeEventListener("abort", onAbort);
        resolve();
      }, ms);
      if (signal) signal.addEventListener("abort", onAbort, { once: true });
    });
  }

  function named(name, message, props) {
    return Object.assign(new Error(message), { name }, props);
  }

  // Hedged run: one attempt, then another on the next pick every HEDGE_MS while none
  // has answered (at most MAX_IN_FLIGHT, one per key). The first answer wins and the
  // rest are aborted. Overload cools that model across clicks and holds new attempts on
  // it only (RETRY); the next pick prefers another model. Ends on an answer, a cancel, no pair able to serve, or `deadline`.
  async function run({
    getUserKeys, getSharedKeys, models, signal, attempt, classify, storage, log,
    now = Date.now, sleep = defaultSleep, deadline, retry = RETRY, random = Math.random,
  }) {
    const say = (level, msg) => {
      if (log && typeof log[level] === "function") log[level](msg);
      else if (typeof log === "function") log(msg);
    };
    const ids = models.map((m) => m.id);
    const start = now();
    const end = deadline != null ? deadline : start + MAX_RUN_MS;
    const state = await sharedState(storage);
    const flights = new Map(); // apiKey -> { label, model, no, t0, ctrl, done }
    const avoid = new Set();
    const modelOverloads = new Map();
    // A model that answered 404 (modelGone) is skipped for the rest of this run on every
    // key; its pairs stay in state untouched, so the next run tries it again.
    let usable = models;
    let attemptNo = 0;
    let overloadHits = 0;
    const backoffUntil = new Map(); // model -> no new attempt on it before this time
    let lastStart = -Infinity;
    let lastVerdict = null;

    const stopAll = () => {
      for (const f of flights.values()) f.ctrl.abort();
      flights.clear();
    };
    const fail = (err) => { stopAll(); return err; };
    const exhausted = (t, reason) => {
      say("warn", `keypool: exhausted after ${attemptNo} attempts: ${reason}`);
      return fail(named("PoolExhaustedError", reason, { reason, summary: summary(state, t, models) }));
    };
    const overloaded = (t, v) => {
      say("warn", `keypool: gave up after ${attemptNo} attempts, Gemini overloaded`);
      return fail(named("OverloadedError", "Gemini is overloaded, try again shortly.",
        { verdict: v, summary: summary(state, t, models) }));
    };
    const outOfTime = (t) => (lastVerdict && lastVerdict.kind === "overloaded")
      ? overloaded(t, lastVerdict)
      : exhausted(t, `no answer within ${Math.round((end - start) / 1000)} s`);
    const safeSave = async () => {
      try {
        await save(storage, state);
      } catch (e) {
        say("warn", `keypool: state save failed: ${(e && e.message) || e}`);
      }
    };
    const checkAbort = () => {
      if (signal && signal.aborted) throw fail(abortError(signal));
    };

    const modelCoolMs = Number.isFinite(retry.overloadModelCoolMs) ? retry.overloadModelCoolMs : RETRY.overloadModelCoolMs;
    if (!state.modelCoolUntil) state.modelCoolUntil = {};

    for (;;) {
      checkAbort();
      let t = now();
      if (t >= end) throw outOfTime(t);
      let nextAt = end;

      const hedgeDue = flights.size === 0 || t >= lastStart + HEDGE_MS;
      if (flights.size < MAX_IN_FLIGHT && hedgeDue) {
        const user = await getUserKeys();
        const sharedKeys = getSharedKeys ? await getSharedKeys() : [];
        checkAbort();
        t = now();
        sync(state, user, t, ids, sharedKeys);
        const p = pick(state, t, usable, { exclude: new Set(flights.keys()), avoid, modelOverloads, rand: random });
        const hold = p.apiKey ? backoffUntil.get(p.model) || 0 : 0;

        if (hold > t) {
          // The best pick is the model that just overloaded: wait out its backoff.
          if (flights.size === 0 && hold >= end) throw overloaded(t, lastVerdict);
          nextAt = Math.min(nextAt, hold);
        } else if (p.apiKey) {
          attemptNo++;
          markSent(state, p.apiKey, p.model, t);
          lastStart = t;
          const tag = p.source === "shared" ? `${p.label} (${p.model}, shared)` : `${p.label} (${p.model})`;
          const f = { label: p.label, tag, model: p.model, no: attemptNo, t0: t, ctrl: new AbortController() };
          const ctx = { label: p.label, model: p.model, source: p.source, attemptNo, remainingMs: end - t, signal: f.ctrl.signal };
          f.done = Promise.resolve()
            .then(() => attempt(p.apiKey, ctx))
            .then((value) => ({ apiKey: p.apiKey, f, ok: true, value }), (err) => ({ apiKey: p.apiKey, f, ok: false, err }));
          flights.set(p.apiKey, f);
          say("debug", `keypool: attempt ${f.no} ${tag} started, ${flights.size} in flight`);
          continue;
        } else if (p.waitMs != null) {
          if (flights.size === 0 && t + p.waitMs >= end) {
            // Overload retries can fill a key's RPM window; then overload is still the cause.
            if (lastVerdict && lastVerdict.kind === "overloaded") throw overloaded(t, lastVerdict);
            throw exhausted(t, `next key frees in ${Math.round(p.waitMs / 1000)} s, after the time cap`);
          }
          if (flights.size === 0) say("debug", `keypool: all keys busy, waiting ${p.waitMs} ms`);
          nextAt = Math.min(nextAt, t + Math.max(1, p.waitMs));
        } else if (flights.size === 0) {
          throw exhausted(t, p.reason);
        }
        // else: nothing pickable now; wait for the attempts in flight.
      }
      if (flights.size && flights.size < MAX_IN_FLIGHT && lastStart + HEDGE_MS > t) {
        nextAt = Math.min(nextAt, lastStart + HEDGE_MS);
      }

      // Wait for the first attempt to settle or the next decision time, whichever is first.
      const wc = new AbortController();
      const onAbort = () => wc.abort();
      if (signal) signal.addEventListener("abort", onAbort, { once: true });
      // The tick is cancelled on purpose when an attempt settles first; a run abort is
      // re-checked at the top of the loop, so both outcomes just mean "look again".
      const tick = sleep(Math.max(0, nextAt - t), wc.signal).then(() => null, () => null);
      const res = await Promise.race([tick, ...[...flights.values()].map((f) => f.done)]);
      wc.abort();
      if (signal) signal.removeEventListener("abort", onAbort);
      if (!res) continue;

      const { f } = res;
      flights.delete(res.apiKey);
      const done = now();
      if (res.ok) {
        markResult(state, res.apiKey, f.model, { kind: "ok" }, done, models);
        delete state.modelCoolUntil[f.model];
        stopAll();
        await safeSave();
        checkAbort();
        say("info", `keypool: attempt ${f.no} ${f.tag} ok in ${done - f.t0} ms`);
        return res.value;
      }

      const v = classify(res.err, done);
      if (v.kind === "cancelled") {
        checkAbort();
        say("info", `keypool: attempt ${f.no} ${f.label} cancelled`);
        throw fail(res.err);
      }
      if (v.kind === "modelGone") {
        usable = usable.filter((m) => m.id !== f.model);
        say("warn", `keypool: attempt ${f.no} ${f.tag} model gone` +
          `${v.reason ? ": " + v.reason : ""}; ${usable.length} model(s) left for this run`);
        if (!usable.length) throw fail(named("FatalRequestError", v.reason || "no model available", { verdict: v, cause: res.err }));
        continue;
      }
      lastVerdict = v;
      markResult(state, res.apiKey, f.model, v, done, models, f.t0);
      if (v.kind === "overloaded" && modelCoolMs > 0) state.modelCoolUntil[f.model] = done + modelCoolMs;
      await safeSave();
      if (v.kind === "overloaded") {
        // Google-side capacity, not this key's quota: no pair cools; the model cools for
        // this and later clicks, and backs off only before its own next attempt, so a
        // switch to another model sends at once. untilMs, when Google gave a delay, is a
        // hint for this model; never wait less than the step.
        overloadHits++;
        avoid.add(res.apiKey + "|" + f.model);
        modelOverloads.set(f.model, (modelOverloads.get(f.model) || 0) + 1);
        const step = Math.min(retry.overloadCapMs, retry.overloadBaseMs * 2 ** (overloadHits - 1)) +
          Math.round(retry.overloadJitterMs * (2 * random() - 1));
        const wait = Math.max(0, step, v.untilMs != null ? v.untilMs - done : 0);
        backoffUntil.set(f.model, done + wait);
        say("debug", `keypool: attempt ${f.no} ${f.tag} overloaded after ${done - f.t0} ms; ${f.model} backs off ${wait} ms`);
        continue;
      }
      const p = pairOf(state, res.apiKey, f.model);
      const coolMs = p ? Math.max(0, p.coolUntil - done) : 0;
      say("warn", `keypool: attempt ${f.no} ${f.tag} ${v.kind}` +
        `${v.reason ? ": " + v.reason : ""} after ${done - f.t0} ms; pair cool ${coolMs} ms`);
      if (v.kind === "fatal") throw fail(named("FatalRequestError", v.reason || "request rejected", { verdict: v, cause: res.err }));
    }
  }

  return {
    MAX_SILENT_WAIT_MS, MAX_RUN_MS, HEDGE_MS, MAX_IN_FLIGHT, RETRY, V1_MODEL,
    createState, sync, pick, markSent, markResult, nextPacificMidnightMs,
    summary, load, save, run,
  };
})();

if (typeof module === "object" && module.exports) module.exports = MaakimaKeyPool;
