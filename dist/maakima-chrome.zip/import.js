var MaakimaImport = (function () {
  const REMOTE_JSON_BASE_URL = "https://distributed-clients.github.io/json/";
  const FONT_SIZE_DEFAULT = 30;
  const FONT_COLOR_DEFAULT = "#cfcdcd";

  function sanitizeFontSize(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) return FONT_SIZE_DEFAULT;
    return Math.max(10, Math.min(80, Math.round(number)));
  }

  function sanitizeColor(value) {
    if (typeof value !== "string") return FONT_COLOR_DEFAULT;
    const trimmed = value.trim();
    return /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(trimmed)
      ? trimmed
      : FONT_COLOR_DEFAULT;
  }

  function normalizeKeyList(value) {
    const values = Array.isArray(value)
      ? value
      : typeof value === "string"
        ? value.split(/[\n,]+/)
        : [];
    return [
      ...new Set(
        values.map((entry) => `${entry || ""}`.trim()).filter(Boolean),
      ),
    ];
  }

  function b64ToBytes(b64) {
    const binary = atob(b64 || "");
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  }

  async function deriveKey(passphrase, saltBytes, iterations) {
    const keyMaterial = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(passphrase),
      "PBKDF2",
      false,
      ["deriveKey"],
    );
    return crypto.subtle.deriveKey(
      { name: "PBKDF2", hash: "SHA-256", salt: saltBytes, iterations },
      keyMaterial,
      { name: "AES-CTR", length: 256 },
      false,
      ["decrypt"],
    );
  }

  async function decryptUserPayload(payload, passphrase) {
    const salt = b64ToBytes(payload.salt);
    const iv = b64ToBytes(payload.iv);
    const data = b64ToBytes(payload.data);
    const key = await deriveKey(passphrase, salt, payload.iterations || 310000);
    const decrypted = await crypto.subtle.decrypt(
      { name: "AES-CTR", counter: iv, length: 64 },
      key,
      data,
    );
    return new Uint8Array(decrypted);
  }

  function extractEmbeddedUsersFromHtml(htmlText) {
    const start = htmlText.match(/const\s+EMBEDDED_USERS\s*=\s*\{/);
    if (!start) throw new Error("Could not find EMBEDDED_USERS in remote page");
    const from = start.index + start[0].length - 1;
    // A user's filename may itself contain "};": try each "};" until the JSON parses.
    for (let end = htmlText.indexOf("};", from); end !== -1; end = htmlText.indexOf("};", end + 1)) {
      try {
        return JSON.parse(htmlText.slice(from, end + 1));
      } catch (_e) {
        // keep scanning
      }
    }
    throw new Error("Could not find EMBEDDED_USERS in remote page");
  }

  function parseBoolean(value) {
    if (typeof value === "boolean") return value;
    return ["1", "true", "yes", "on"].includes(`${value || ""}`.trim().toLowerCase());
  }

  function emptyIgnored() {
    return { groq: 0, mistral: 0, ollama: 0 };
  }

  // AIza + 35 = 39 chars; AQ. + 50 = 53 chars (counted on real keys).
  const GEMINI_SHAPE_RE = /^(?:AIza[0-9A-Za-z_-]{35}|AQ\.[0-9A-Za-z_.-]{50})$/;

  // The one normaliser. Input: lists by provider ({gemini, groq, mistral, ollama}, each
  // an array or string). Gemini-shaped entries from any list become Gemini, de-duplicated;
  // everything else (gsk_, malformed) is dropped from Gemini. Counts only, never keys.
  function normalizeGeminiKeys(lists) {
    const ignored = emptyIgnored();
    let refiled = 0;
    const gemini = normalizeKeyList(lists.gemini);
    for (const provider of Object.keys(ignored)) {
      for (const entry of normalizeKeyList(lists[provider])) {
        if (GEMINI_SHAPE_RE.test(entry)) {
          gemini.push(entry);
          refiled += 1;
        } else {
          ignored[provider] += 1;
        }
      }
    }
    const unique = normalizeKeyList(gemini);
    const keys = unique.filter((k) => GEMINI_SHAPE_RE.test(k));
    return { keys, refiled, dropped: unique.length - keys.length, ignored };
  }

  function finish(result, others) {
    const n = normalizeGeminiKeys({ gemini: result.userGeminiApiKeys, ...others });
    result.userGeminiApiKeys = n.keys;
    result.refiled = n.refiled;
    result.dropped = n.dropped;
    result.ignored = n.ignored;
    return result;
  }

  function parseImportedJson(text) {
    const raw = JSON.parse(text);
    const source = Array.isArray(raw)
      ? { userGeminiApiKeys: raw }
      : raw && typeof raw.settings === "object" && raw.settings !== null
        ? raw.settings
        : raw;
    if (!source || typeof source !== "object") throw new Error("not a settings object");
    const list = (...vals) => normalizeKeyList(vals.flatMap((v) => normalizeKeyList(v)));

    const result = {
      userGeminiApiKeys: list(
        source.userGeminiApiKeys,
        source.userGeminiApiKey,
        source.geminiApiKeys,
        source.geminiApiKey,
        source.gemini,
      ),
      displayDotSpacing: source.displayDotSpacing ?? source.dotSpacing,
      displayFontSize:
        source.displayFontSize ?? source.fontSize ?? source.answerFontSize,
      displayFontColor:
        source.displayFontColor ?? source.fontColor ?? source.answerFontColor,
      displayPosition:
        source.displayPosition ??
        source.position ??
        source.barPosition ??
        source.answerPosition,
      enableDetailedLogging:
        source.enableDetailedLogging ?? source.logging ?? source.detailedLogging,
      displayWhiteBackground:
        source.displayWhiteBackground ??
        source.whiteBackground ??
        source.backgroundWhite,
      displayDebugPersistentBox:
        source.displayDebugPersistentBox ??
        source.debugPersistentBox ??
        source.debugBox,
    };
    for (const k of Object.keys(result)) {
      if (result[k] === undefined) delete result[k];
    }
    // Shared list: kept apart from the user's own keys; only present when the payload has it.
    if (source.sharedGeminiApiKeys !== undefined) {
      result.sharedGeminiApiKeys = normalizeGeminiKeys({ gemini: list(source.sharedGeminiApiKeys) }).keys;
    }
    return finish(result, {
      groq: list(
        source.userGroqApiKeys,
        source.userGroqApiKey,
        source.groqApiKeys,
        source.groqApiKey,
        source.groq,
      ),
      mistral: list(
        source.userMistralApiKeys,
        source.userMistralApiKey,
        source.mistralApiKeys,
        source.mistralApiKey,
        source.mistral,
      ),
      ollama: list(source.userOllamaApiKeys, source.userOllamaApiKey),
    });
  }

  const SECTION_RE =
    /^(groq|mistral|ollama|gemini|settings|config|user(?:groq|mistral|ollama|gemini)apikeys?)\s*[:=]\s*$/i;

  function providerOf(name) {
    const n = name.toLowerCase().replace(/^user/, "").replace(/apikeys?$/, "");
    return ["groq", "mistral", "ollama", "gemini"].includes(n) ? n : "";
  }

  const TEXT_SETTINGS = [
    [["displayfontsize", "fontsize", "answerfontsize"], "displayFontSize", String],
    [["displayfontcolor", "fontcolor", "answerfontcolor"], "displayFontColor", String],
    [["displayposition", "position", "barposition", "answerposition"], "displayPosition", String],
    [["displaydotspacing", "dotspacing"], "displayDotSpacing", String],
    [["enabledetailedlogging", "logging", "detailedlogging"], "enableDetailedLogging", parseBoolean],
    [["displaywhitebackground", "whitebackground", "backgroundwhite"], "displayWhiteBackground", parseBoolean],
    [["displaydebugpersistentbox", "debugpersistentbox", "debugbox"], "displayDebugPersistentBox", parseBoolean],
  ];

  function parseImportedText(text) {
    const result = { userGeminiApiKeys: [] };
    const others = { groq: [], mistral: [], ollama: [] };
    let section = "";

    for (const line of text.split(/\r?\n/)) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#") || trimmed.startsWith("//")) continue;

      const sectionMatch = trimmed.match(SECTION_RE);
      if (sectionMatch) {
        section = providerOf(sectionMatch[1]) || sectionMatch[1].toLowerCase();
        continue;
      }

      const kv = trimmed.match(/^([A-Za-z][\w.-]*)\s*[:=]\s*(.+)$/);
      if (kv) {
        const key = kv[1].trim().toLowerCase();
        const value = kv[2].trim();
        const setting = TEXT_SETTINGS.find(([names]) => names.includes(key));
        if (setting) {
          result[setting[1]] = setting[2](value);
          continue;
        }
        const provider = providerOf(key);
        if (provider === "gemini") {
          result.userGeminiApiKeys.push(...normalizeKeyList(value));
          continue;
        }
        if (provider) {
          others[provider].push(...normalizeKeyList(value));
          continue;
        }
      }

      if (section === "gemini") {
        result.userGeminiApiKeys.push(trimmed);
      } else if (section === "groq" || section === "mistral" || section === "ollama") {
        others[section].push(trimmed);
      } else if (/^gsk_/i.test(trimmed) || /groq/i.test(trimmed)) {
        others.groq.push(trimmed);
      } else if (/^(AIza|AQ\.)/.test(trimmed)) {
        result.userGeminiApiKeys.push(trimmed);
      }
    }
    return finish(result, others);
  }

  function parseImportedConfig(text, _fileName) {
    try {
      return parseImportedJson(text);
    } catch (_jsonError) {
      return parseImportedText(text);
    }
  }

  async function performRemoteImport(userKey, { fetchImpl, storageGet, storageSet }) {
    const delimiterIndex = userKey.indexOf(":");
    const user =
      delimiterIndex === -1 ? "" : userKey.slice(0, delimiterIndex).trim();
    const key = delimiterIndex === -1 ? "" : userKey.slice(delimiterIndex + 1);
    if (!user || !key) throw new Error("Use user:key format");

    const remoteUrl = new URL(REMOTE_JSON_BASE_URL);
    remoteUrl.searchParams.set("user", user);

    const response = await fetchImpl(remoteUrl.toString(), { cache: "no-store" });
    if (!response.ok) throw new Error(`Remote fetch failed (${response.status})`);

    const embeddedUsers = extractEmbeddedUsersFromHtml(await response.text());
    if (!Object.prototype.hasOwnProperty.call(embeddedUsers, user)) throw new Error("User not found in remote payload");
    const encryptedPayload = embeddedUsers[user];

    const decrypted = await decryptUserPayload(encryptedPayload, key);
    const decryptedText = new TextDecoder().decode(decrypted);
    const imported = parseImportedConfig(decryptedText, "remote.json");
    let isJson = true;
    try {
      JSON.parse(decryptedText);
    } catch (_e) {
      isJson = false;
    }
    // AES-CTR has no MAC: a wrong passphrase yields garbage, not an error.
    if (!isJson && imported.userGeminiApiKeys.length === 0 && Object.keys(imported).length <= 4) {
      throw new Error(`Wrong key for ${user}`);
    }

    const current = await storageGet(["userGeminiApiKeys"]);
    const merged = normalizeGeminiKeys({
      gemini: [...(current.userGeminiApiKeys || []), ...imported.userGeminiApiKeys],
    }).keys;
    const payload = {
      userGeminiApiKeys: merged,
      userGeminiApiKey: merged[0] || "",
      remoteUserKey: userKey,
    };
    // Replaces the stored shared list; a payload without the field leaves it alone.
    if (imported.sharedGeminiApiKeys) payload.sharedGeminiApiKeys = imported.sharedGeminiApiKeys;
    if (imported.displayFontSize != null)
      payload.displayFontSize = sanitizeFontSize(imported.displayFontSize);
    if (imported.displayFontColor != null)
      payload.displayFontColor = sanitizeColor(imported.displayFontColor);
    if (imported.displayDotSpacing != null && Number.isFinite(Number(imported.displayDotSpacing)))
      payload.displayDotSpacing = Math.round(Number(imported.displayDotSpacing));
    for (const k of [
      "displayPosition",
      "displayWhiteBackground",
      "displayDebugPersistentBox",
      "enableDetailedLogging",
    ]) {
      if (imported[k] != null) payload[k] = imported[k];
    }

    await storageSet(payload);
    return { user, ignored: imported.ignored, refiled: imported.refiled, dropped: imported.dropped };
  }

  return {
    normalizeKeyList,
    normalizeGeminiKeys,
    parseImportedJson,
    parseImportedText,
    parseImportedConfig,
    decryptUserPayload,
    extractEmbeddedUsersFromHtml,
    performRemoteImport,
  };
})();
if (typeof module === "object" && module.exports) module.exports = MaakimaImport;
