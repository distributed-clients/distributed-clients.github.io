// Persisted, redacted ring log. Never writes to the console.
var MaakimaLog = (function () {
  const STORAGE_KEY = "maakimaLog";
  const ERR_KEY = "maakimaLogError";
  const MAX_LINES = 5000;
  const MAX_LINE = 4000;
  const MAX_CHARS = 2000000; // chars, so even 3-byte UTF-8 stays well under the 10 MB storage.local quota
  const CHUNK_LINES = 200;
  const CHUNK_CHARS = 60000; // a flush rewrites one small chunk, so storage.onChanged never carries the whole ring
  const FLUSH_MS = 1000;
  const LEVELS = ["DEBUG", "INFO", "WARN", "ERROR"];

  // Storage layout: STORAGE_KEY = {head, n:[lines per chunk], c:[chars per chunk]};
  // chunk i lives under STORAGE_KEY + "_" + i. Lines not yet written wait in `pending`.
  // The popup and the background both append, so each flush merges into what is stored.
  // ponytail: two contexts flushing in the same instant can still drop one batch.
  let pending = [];
  let pendingChars = 0;
  let source = "bg";
  let hadError = false;
  let verbose = true;
  let chain = Promise.resolve();
  let timer = null;
  let storage = null;
  const self_ = {};

  function defaultStorage() {
    const area = chrome.storage.local;
    return {
      get(keys) {
        try {
          const p = area.get(keys);
          if (p && typeof p.then === "function") return p;
        } catch (_e) { /* fall back to callback style */ }
        return new Promise((resolve, reject) => {
          area.get(keys, (r) => {
            const err = chrome.runtime && chrome.runtime.lastError;
            if (err) reject(new Error(err.message)); else resolve(r);
          });
        });
      },
      set(value) {
        try {
          const p = area.set(value);
          if (p && typeof p.then === "function") return p;
        } catch (_e) { /* fall back to callback style */ }
        return new Promise((resolve, reject) => {
          area.set(value, () => {
            const err = chrome.runtime && chrome.runtime.lastError;
            if (err) reject(new Error(err.message)); else resolve();
          });
        });
      },
      remove(keys) {
        try {
          const p = area.remove(keys);
          if (p && typeof p.then === "function") return p;
        } catch (_e) { /* fall back to callback style */ }
        return new Promise((resolve, reject) => {
          area.remove(keys, () => {
            const err = chrome.runtime && chrome.runtime.lastError;
            if (err) reject(new Error(err.message)); else resolve();
          });
        });
      },
    };
  }
  const store = () => storage || (storage = defaultStorage());

  function redact(text) {
    return String(text)
      .replace(/AIza[0-9A-Za-z_-]{20,}/g, (m) => "AIza…" + m.slice(-4))
      .replace(/AQ\.[0-9A-Za-z_.-]{20,}/g, (m) => "AQ.…" + m.slice(-4))
      .replace(/gsk_[0-9A-Za-z]{20,}/g, (m) => "gsk_…" + m.slice(-4))
      .replace(/([?&]key=)[^&\s"']+/g, "$1REDACTED")
      .replace(/(Bearer\s+)[A-Za-z0-9._~+\/=-]{8,}/gi, "$1REDACTED")
      .replace(/(\\?"?\b(?:fullKey|apiKey|x-goog-api-key|remoteUserKey|userKey|key)\\?"?\s*[:=]\s*\\?"?)[^"\\\s,}]+/gi, "$1REDACTED");
  }

  const keyLabel = (apiKey) => "…" + String(apiKey).slice(-4);

  function fmt(arg) {
    if (typeof arg === "string") return arg;
    if (arg instanceof Error) {
      const stack = String(arg.stack || "").split("\n").slice(1, 4).join("\n");
      return arg.name + ": " + arg.message + (stack ? "\n" + stack : "");
    }
    try {
      const s = JSON.stringify(arg);
      return s === undefined ? String(arg) : s;
    } catch (_e) {
      return "[unserializable]";
    }
  }

  function push(level, src, text) {
    let t = redact(text);
    if (t.length > MAX_LINE) t = t.slice(0, MAX_LINE) + "…[truncated]";
    const line = new Date().toISOString() + " " + level + " [" + src + "] " + t;
    pending.push(line);
    pendingChars += line.length;
    // Bound what waits in memory (a failing storage must not grow it without limit).
    while (pending.length > MAX_LINES || pendingChars > MAX_CHARS) pendingChars -= pending.shift().length;
    schedule();
  }

  function schedule() {
    if (timer) return;
    timer = setTimeout(() => { timer = null; self_.flush(); }, FLUSH_MS);
    if (timer && typeof timer.unref === "function") timer.unref();
  }

  function log(level, args) {
    if (level === "DEBUG" && !verbose) return;
    push(level, source, args.map(fmt).join(" "));
  }

  const chunkKey = (i) => STORAGE_KEY + "_" + i;
  const sum = (arr) => arr.reduce((a, l) => a + l.length, 0);
  const asLines = (v) => (Array.isArray(v) ? v : []);

  async function readMeta() {
    const m = (await store().get(STORAGE_KEY) || {})[STORAGE_KEY];
    if (Array.isArray(m)) return { meta: { head: 0, n: [], c: [] }, legacy: m }; // old single-array format
    if (m && Number.isInteger(m.head) && Array.isArray(m.n) && Array.isArray(m.c)) return { meta: m, legacy: [] };
    return { meta: { head: 0, n: [], c: [] }, legacy: [] };
  }

  async function readChunk(i) {
    return asLines((await store().get(chunkKey(i)) || {})[chunkKey(i)]);
  }

  async function removeKeys(keys) {
    if (!keys.length) return;
    const s = store();
    if (s.remove) await s.remove(keys);
    else await s.set(Object.fromEntries(keys.map((k) => [k, []])));
  }

  async function readAll() {
    const { meta, legacy } = await readMeta();
    const keys = meta.n.map((_, k) => chunkKey(meta.head + k));
    const r = keys.length ? await store().get(keys) : {};
    return legacy.concat(...keys.map((k) => asLines(r && r[k])));
  }

  async function append(batch) {
    const { meta, legacy } = await readMeta();
    batch = legacy.concat(batch);
    const mod = new Map();
    let cur = null;
    if (meta.n.length) {
      const idx = meta.head + meta.n.length - 1;
      cur = await readChunk(idx);
      mod.set(idx, cur);
    }
    for (const line of batch) {
      if (!cur || cur.length >= CHUNK_LINES || (cur.length && sum(cur) + line.length > CHUNK_CHARS)) {
        meta.n.push(0); meta.c.push(0);
        cur = [];
        mod.set(meta.head + meta.n.length - 1, cur);
      }
      cur.push(line);
    }
    const sync = () => {
      for (const [idx, arr] of mod) {
        const pos = idx - meta.head;
        if (pos >= 0 && pos < meta.n.length) { meta.n[pos] = arr.length; meta.c[pos] = sum(arr); }
      }
    };
    sync();
    let totN = meta.n.reduce((a, b) => a + b, 0);
    let totC = meta.c.reduce((a, b) => a + b, 0);
    const removed = [];
    while ((totN > MAX_LINES || totC > MAX_CHARS) && meta.n.length) {
      const hi = meta.head;
      const hl = mod.get(hi) || await readChunk(hi);
      while (hl.length && (totN > MAX_LINES || totC > MAX_CHARS)) { totC -= hl.shift().length; totN--; }
      if (hl.length) { mod.set(hi, hl); meta.n[0] = hl.length; meta.c[0] = sum(hl); break; }
      meta.n.shift(); meta.c.shift(); meta.head++;
      mod.delete(hi);
      removed.push(chunkKey(hi));
    }
    sync();
    const write = { [STORAGE_KEY]: meta };
    for (const [idx, arr] of mod) write[chunkKey(idx)] = arr;
    await store().set(write);
    try { await removeKeys(removed); } catch (e) { await noteError(e); }
  }

  async function noteError(e) {
    self_.lastFlushError = e;
    hadError = true;
    // Best effort, tiny: lets the popup (another context) show why the log stopped.
    try { await store().set({ [ERR_KEY]: String((e && e.message) || e).slice(0, 300) }); } catch (_e) { /* storage is the thing failing */ }
  }

  function flush() {
    if (timer) { clearTimeout(timer); timer = null; }
    // Serialized: each flush runs after the previous one and appends its batch to the stored ring.
    chain = chain.then(async () => {
      if (!pending.length) return;
      const batch = pending;
      const chars = pendingChars;
      pending = [];
      pendingChars = 0;
      try {
        await append(batch);
      } catch (e) {
        pending = batch.concat(pending); // kept for the next flush
        pendingChars += chars;
        while (pending.length > MAX_LINES || pendingChars > MAX_CHARS) pendingChars -= pending.shift().length;
        throw e;
      }
      if (hadError) { hadError = false; self_.lastFlushError = null; await store().set({ [ERR_KEY]: "" }); }
    }).catch((e) => noteError(e));
    return chain;
  }

  Object.assign(self_, {
    redact,
    keyLabel,
    debug: (...a) => log("DEBUG", a),
    info: (...a) => log("INFO", a),
    warn: (...a) => log("WARN", a),
    error: (...a) => log("ERROR", a),
    ingest(items, src) {
      if (!Array.isArray(items)) return;
      const name = String(src || "content").replace(/[^\w .:-]/g, "").slice(0, 40) || "content";
      for (const it of items.slice(0, 500)) {
        const lv = String((it && it.level) || "info").toUpperCase();
        const level = LEVELS.includes(lv) ? lv : "INFO";
        if (level === "DEBUG" && !verbose) continue;
        push(level, name, String(it && it.text));
      }
    },
    setSource(name) { source = String(name || "bg").replace(/[^\w .:-]/g, "").slice(0, 40) || "bg"; },
    setVerbose(v) { verbose = !!v; },
    flush,
    // Why the last write failed ("" when fine). Reads storage, so the popup sees the background's failure.
    async lastError() {
      const r = (await store().get(ERR_KEY).catch(() => null)) || {};
      return r[ERR_KEY] || (self_.lastFlushError ? String(self_.lastFlushError.message || self_.lastFlushError) : "");
    },
    async text() {
      await flush();
      return (await readAll()).concat(pending).join("\n");
    },
    async clear() {
      await chain;
      pending = [];
      pendingChars = 0;
      const { meta } = await readMeta();
      await store().set({ [STORAGE_KEY]: { head: meta.head + meta.n.length, n: [], c: [] }, [ERR_KEY]: "" });
      await removeKeys(meta.n.map((_, k) => chunkKey(meta.head + k)));
      hadError = false;
      self_.lastFlushError = null;
    },
    async download() {
      if (typeof document === "undefined") return false;
      const d = new Date();
      const p = (n) => String(n).padStart(2, "0");
      const stamp = "" + d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + "-" + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds());
      const body = await self_.text();
      const url = URL.createObjectURL(new Blob([body], { type: "text/plain" }));
      const a = document.createElement("a");
      a.href = url;
      a.download = "maakima-log-" + stamp + ".txt";
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      return true;
    },
    _setStorage(s) {
      storage = s;
      pending = [];
      pendingChars = 0;
      source = "bg";
      hadError = false;
      verbose = true;
      chain = Promise.resolve();
      self_.lastFlushError = null;
    },
  });
  return self_;
})();

// Closing the popup or navigating must not drop the last second of lines.
if (typeof window !== "undefined" && window.addEventListener) window.addEventListener("pagehide", () => MaakimaLog.flush());

if (typeof module === "object" && module.exports) module.exports = MaakimaLog;
