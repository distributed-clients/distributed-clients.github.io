// Gemini generateContent client and error classifier.
// Pure library: no chrome.* calls, no logging. background.js logs the results.
// Error mapping: https://ai.google.dev/gemini-api/docs/troubleshooting and
// google/rpc/error_details.proto (RetryInfo, QuotaFailure, ErrorInfo).
var MaakimaGemini = (() => {
  // Ordered by preference, main model first; the others serve overload and quota retries.
  // gemini-3.6-flash leads on accuracy and consistency (B2 sweep plus public benchmarks).
  const MODELS = ["gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-3-flash-preview"];
  const MODEL = MODELS[0];
  // Free-tier defaults per model (B1, docs/gemini-models.md); rpd null = unpublished.
  // A 429 that states the limit overrides these in keypool.js.
  const LIMITS = {
    "gemini-3.5-flash-lite": { rpm: 15, rpd: 500 },
    "gemini-3.1-flash-lite": { rpm: 15, rpd: null },
    "gemini-3.6-flash": { rpm: 5, rpd: null },
    "gemini-3.8-flash": { rpm: 5, rpd: null },
    "gemini-3-flash-preview": { rpm: 5, rpd: null },
  };
  const UNKNOWN_LIMITS = { rpm: 5, rpd: null }; // lowest free-tier RPM in B1
  // Google's default sampling (troubleshooting doc: keep defaults on Gemini 3.x) plus
  // thinkingLevel "low": 10/12 vs 8/12 for temperature 0.2/topP 0.3/topK 40 (bench 2026-10-21).
  // A model id key overrides the default for that model.
  // B2: gemini-3.6-flash scored best with temperature 0.2 added (17/24).
  const GENERATION_CONFIG = {
    default: { thinkingConfig: { thinkingLevel: "low" } },
    "gemini-3.6-flash": { thinkingConfig: { thinkingLevel: "low" }, temperature: 0.2 },
  };
  const endpoint = (model) =>
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
  // P0 (2026-10-21): RetryInfo.retryDelay is truncated to whole seconds ("12s" while the
  // message says "Please retry in 12.662502924s"), so the wait is
  // ceil(max(retryDelay, message delay)) + 1 s.
  const SLACK_MS = 1000;
  const BODY_CAP = 4000;

  function limitsFor(id) {
    const l = LIMITS[id] || UNKNOWN_LIMITS;
    return { rpm: l.rpm, rpd: l.rpd };
  }

  function modelList() {
    return MODELS.map((id) => ({ id, ...limitsFor(id) }));
  }

  // generationConfig (from a remote model config) overrides GENERATION_CONFIG.
  function buildRequestBody(promptText, base64Jpeg, model = MODEL, generationConfig = null) {
    return {
      contents: [
        {
          parts: [
            { text: promptText },
            { inlineData: { mimeType: "image/jpeg", data: base64Jpeg } },
          ],
        },
      ],
      generationConfig: generationConfig || GENERATION_CONFIG[model] || GENERATION_CONFIG.default,
    };
  }

  function extractText(json) {
    const cand = json && Array.isArray(json.candidates) ? json.candidates[0] : null;
    const parts = (cand && cand.content && cand.content.parts) || [];
    return {
      text: parts
        .filter((p) => p && p.thought !== true && typeof p.text === "string")
        .map((p) => p.text)
        .join(""),
      finishReason: (cand && cand.finishReason) || null,
      blockReason: (json && json.promptFeedback && json.promptFeedback.blockReason) || null,
      promptTokenCount:
        (json && json.usageMetadata && json.usageMetadata.promptTokenCount) ?? null,
    };
  }

  async function call({ apiKey, model = MODEL, generationConfig, promptText, base64Jpeg, signal, fetchImpl }) {
    const doFetch = fetchImpl || fetch;
    const res = await doFetch(endpoint(model), {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
      body: JSON.stringify(buildRequestBody(promptText, base64Jpeg, model, generationConfig)),
      signal,
    });
    if (!res.ok) {
      const bodyText = String(await res.text()).slice(0, BODY_CAP);
      const parsed = parseBody(bodyText);
      const msg = parsed && parsed.message ? String(parsed.message).slice(0, 300) : "";
      const err = new Error(`Gemini HTTP ${res.status}${msg ? `: ${msg}` : ""}`);
      err.name = "GeminiHttpError";
      err.status = res.status;
      err.bodyText = bodyText;
      err.retryAfterHeader = res.headers && res.headers.get ? res.headers.get("retry-after") : null;
      throw err;
    }
    return { ...extractText(await res.json()), model };
  }

  // Returns the google.rpc error object ({code,status,message,details}) or null.
  function parseBody(bodyText) {
    try {
      const j = JSON.parse(bodyText || "");
      return j && typeof j.error === "object" && j.error ? j.error : null;
    } catch (_e) {
      return null; // non-JSON body (HTML gateway page): classified by status alone
    }
  }

  // "37s" / "1.5s" (protobuf Duration JSON) or "500ms" -> ms; else null.
  function durationMs(text) {
    const m = /^\s*(\d+(?:\.\d+)?)\s*(ms|s)\s*$/i.exec(String(text || ""));
    if (!m) return null;
    return Math.round(Number(m[1]) * (m[2].toLowerCase() === "ms" ? 1 : 1000));
  }

  function retryAfterHeaderMs(value, nowMs) {
    if (value == null || value === "") return null;
    const secs = Number(value);
    if (Number.isFinite(secs) && secs >= 0) return Math.round(secs * 1000);
    const at = Date.parse(value); // HTTP-date form
    return Number.isFinite(at) ? Math.max(0, at - nowMs) : null;
  }

  function verdict(kind, reason, untilMs = null, quotaId = null, limit = null) {
    return { kind, untilMs, reason, quotaId, limit };
  }

  // The request limit a 429 states (P0: QuotaFailure quotaValue "15", and the message
  // "metric: …_requests, limit: 15"). Only for a request quota: a token quota's 250000
  // must never become an RPM.
  function requestLimit(violation, message) {
    const id = String(violation.quotaId || "");
    const metric = String(violation.quotaMetric || "");
    if (!id.includes("Requests") && !/requests$/.test(metric)) return null;
    const v = String(violation.quotaValue ?? "").trim();
    if (/^\d+$/.test(v) && Number(v) >= 1) return Number(v);
    const m = /metric:\s*\S*requests,\s*limit:\s*(\d+)/.exec(message);
    return m && Number(m[1]) >= 1 ? Number(m[1]) : null;
  }

  function classify(err, nowMs) {
    const name = err && err.name;
    if (name === "AbortError") return verdict("cancelled", "cancelled");
    if (name === "TimeoutError") return verdict("transient", "timeout");
    if (!err || name !== "GeminiHttpError") {
      // fetch network failure (TypeError) or an unreadable 2xx body
      return verdict("transient", `network: ${String((err && err.message) || err).slice(0, 200)}`);
    }

    const status = Number(err.status) || 0;
    const body = parseBody(err.bodyText);
    const rpcStatus = (body && body.status) || "";
    const message = body && body.message ? String(body.message) : "";
    const details = body && Array.isArray(body.details) ? body.details : [];
    const ofType = (suffix) =>
      details.filter((d) => d && typeof d["@type"] === "string" && d["@type"].endsWith(suffix));
    const reason = `${status}${rpcStatus ? ` ${rpcStatus}` : ""}${message ? ` ${message.slice(0, 200)}` : ""}`;

    // Wait hint: ceil(max(RetryInfo, "retry in Ns")) + 1 s, else Retry-After (F1a).
    const hintMs = () => {
      const retryInfo = ofType("google.rpc.RetryInfo")[0];
      const fromInfo = retryInfo ? durationMs(retryInfo.retryDelay) : null;
      const m = /retry in\s+(\d+(?:\.\d+)?\s*(?:ms|s))\b/i.exec(message);
      const fromMessage = m ? durationMs(m[1]) : null;
      let delay = fromInfo == null && fromMessage == null ? null : Math.max(fromInfo || 0, fromMessage || 0);
      if (delay == null) delay = retryAfterHeaderMs(err.retryAfterHeader, nowMs);
      return delay == null ? null : nowMs + Math.ceil(delay / 1000) * 1000 + SLACK_MS;
    };

    if (status === 429) {
      const violations = ofType("google.rpc.QuotaFailure")
        .flatMap((d) => (Array.isArray(d.violations) ? d.violations : []))
        .filter((v) => v && typeof v.quotaId === "string" && v.quotaId);
      const day = violations.find((v) => v.quotaId.includes("PerDay"));
      if (day) return verdict("day", reason, null, day.quotaId, requestLimit(day, message));
      // B0 (F2): a 429 without QuotaFailure is model-wide overload, not this key's quota;
      // the pool backs off run-wide and leaves the key alone. untilMs is only a hint there.
      // status 429: Google does not count it against the key's quota (brief, Overload analysis).
      if (!ofType("google.rpc.QuotaFailure").length) return { ...verdict("overloaded", reason, hintMs()), status: 429 };
      const first = violations[0];
      return verdict(
        "cooldown",
        reason,
        hintMs(),
        first ? first.quotaId : null,
        first ? requestLimit(first, message) : null,
      );
    }

    // 503 UNAVAILABLE ("The model is overloaded", "high demand") is model-wide too (review H2).
    // status 503: may count against the key's quota, so the pool keeps the send counted.
    if (status === 503 || rpcStatus === "UNAVAILABLE") return { ...verdict("overloaded", reason, hintMs()), status: 503 };
    // 501 UNIMPLEMENTED: "not implemented or supported" by this model (api-errors doc), so
    // retrying the same model only burns the click; another model may serve it.
    if (status === 501 || rpcStatus === "UNIMPLEMENTED") return verdict("modelGone", reason);
    // 409 ABORTED ("retry at a higher level", code.proto) and a 499 from the server side
    // (our own abort never yields a response) are worth another try.
    if (status === 408 || status === 409 || status === 499 || status >= 500) return verdict("transient", reason);
    // The Gemini API always answers in google.rpc JSON; a 401/402/403 page without it comes
    // from a proxy or gateway between us and Google, so no key is to blame (24 h dead).
    if (status === 401 || status === 402 || status === 403) return verdict(body ? "dead" : "fatal", reason);
    if (status === 400) {
      const keyInvalid =
        ofType("google.rpc.ErrorInfo").some((d) => /^API_KEY_/.test(d.reason || "")) ||
        /API key (not valid|expired)/i.test(message);
      if (keyInvalid) return verdict("dead", reason);
      if (rpcStatus === "FAILED_PRECONDITION") {
        // The caller's location is the same for every key: fatal, no key dead (review M3).
        // Any other precondition is the key's project ("disabled billing", api-errors doc).
        return verdict(/location|country|region/i.test(message) ? "fatal" : "dead", reason);
      }
      // A generation setting this model rejects (models.json is per model, e.g. a thinking
      // level or media resolution it lacks): only this model fails, the next may answer.
      if (/generation_?config|thinking/i.test(message)) return verdict("modelGone", reason);
    }
    // B2: a model id Google no longer serves ("no longer available to new users") is 404;
    // only that model is gone, so the pool drops it for the run and tries the next one.
    if (status === 404 || rpcStatus === "NOT_FOUND") return verdict("modelGone", reason);
    // Other 400s, 413 and unknown 4xx are the request's fault; no other key will fix them.
    return verdict("fatal", reason);
  }

  // site/config/models.json (F13). Data only, validated, never executed: an id goes into
  // the fixed googleapis URL path, so it must match ID_RE; numbers are clamped; unknown
  // fields are dropped. Returns {models:[{id, rpm, rpd, generationConfig}], retry} or
  // null (file unusable: the caller keeps its cached copy or the built-in defaults).
  const ID_RE = /^gemini-[a-z0-9.-]+$/;
  const MAX_MODELS = 10;
  const THINKING_LEVELS = ["minimal", "low", "medium", "high"];
  const isObj = (v) => v != null && typeof v === "object" && !Array.isArray(v);
  const num = (v, lo, hi, int) => {
    if (typeof v !== "number" || !Number.isFinite(v)) return undefined;
    const x = Math.min(hi, Math.max(lo, v));
    return int ? Math.round(x) : x;
  };

  function cleanGenerationConfig(raw) {
    if (!isObj(raw)) return null;
    const out = {};
    const t = num(raw.temperature, 0, 2, false);
    const topP = num(raw.topP, 0, 1, false);
    const topK = num(raw.topK, 1, 1000, true);
    if (t !== undefined) out.temperature = t;
    if (topP !== undefined) out.topP = topP;
    if (topK !== undefined) out.topK = topK;
    const level = isObj(raw.thinkingConfig) ? raw.thinkingConfig.thinkingLevel : undefined;
    if (THINKING_LEVELS.includes(level)) out.thinkingConfig = { thinkingLevel: level };
    return out;
  }

  function parseRemoteConfig(json) {
    if (!isObj(json) || json.version !== 1 || !Array.isArray(json.models)) return null;
    const models = [];
    for (const m of json.models.slice(0, MAX_MODELS)) {
      if (!isObj(m) || typeof m.id !== "string" || !ID_RE.test(m.id)) return null;
      if (models.some((x) => x.id === m.id)) return null;
      const d = limitsFor(m.id);
      const rpm = num(m.rpm, 1, 10000, true);
      const rpd = m.rpd === null ? null : num(m.rpd, 1, 1000000, true);
      models.push({
        id: m.id,
        rpm: rpm === undefined ? d.rpm : rpm,
        rpd: rpd === undefined ? d.rpd : rpd,
        generationConfig:
          cleanGenerationConfig(m.generationConfig) ||
          GENERATION_CONFIG[m.id] ||
          GENERATION_CONFIG.default,
      });
    }
    if (!models.length) return null;
    // Only the fields given; the caller merges over MaakimaKeyPool.RETRY.
    const retry = {};
    const r = isObj(json.retry) ? json.retry : {};
    for (const [k, lo, hi] of [
      ["overloadBaseMs", 0, 60000],
      ["overloadCapMs", 0, 60000],
      ["overloadJitterMs", 0, 10000],
      ["overloadModelCoolMs", 0, 600000],
    ]) {
      const v = num(r[k], lo, hi, true);
      if (v !== undefined) retry[k] = v;
    }
    return { models, retry };
  }

  return {
    parseRemoteConfig,
    MODELS,
    MODEL,
    LIMITS,
    GENERATION_CONFIG,
    limitsFor,
    modelList,
    buildRequestBody,
    extractText,
    call,
    classify,
  };
})();

if (typeof module === "object" && module.exports) module.exports = MaakimaGemini;
