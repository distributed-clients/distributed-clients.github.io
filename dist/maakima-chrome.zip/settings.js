// Display settings: the one copy of the defaults and sanitizers, shared by
// background.js, content.js and popup.js. Pure: no chrome.*, no logging, no DOM.
var MaakimaSettings = (() => {
  const DEFAULTS = {
    displayFontSize: 30,
    displayFontColor: "#cfcdcd",
    displayPosition: "left",
    displayWhiteBackground: true,
    displayDotSpacing: -5,
    displayDebugPersistentBox: false,
    enableDetailedLogging: true,
  };
  const KEYS = Object.keys(DEFAULTS);

  const isColor = (v) =>
    typeof v === "string" && /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(v.trim());
  const color = (v) => (isColor(v) ? v.trim() : DEFAULTS.displayFontColor);

  function fontSize(v) {
    const n = Number(v);
    return Number.isFinite(n) ? Math.max(10, Math.min(80, Math.round(n))) : DEFAULTS.displayFontSize;
  }

  function position(v) {
    const p = `${v || ""}`.trim().toLowerCase();
    return p === "left" || p === "right" || p === "center" ? p : DEFAULTS.displayPosition;
  }

  const bool = (v, fallback) => (typeof v === "boolean" ? v : fallback);

  // A missing value gives the default (Number("") would be 0).
  function dotSpacing(v) {
    if (v === undefined || v === null || v === "") return DEFAULTS.displayDotSpacing;
    const n = Number(v);
    return Number.isFinite(n) ? Math.max(-15, Math.min(30, Math.round(n))) : DEFAULTS.displayDotSpacing;
  }

  function sanitizeDisplay(raw = {}) {
    return {
      displayFontSize: fontSize(raw.displayFontSize),
      displayFontColor: color(raw.displayFontColor),
      displayPosition: position(raw.displayPosition),
      displayWhiteBackground: bool(raw.displayWhiteBackground, DEFAULTS.displayWhiteBackground),
      displayDotSpacing: dotSpacing(raw.displayDotSpacing),
      displayDebugPersistentBox: bool(raw.displayDebugPersistentBox, DEFAULTS.displayDebugPersistentBox),
      enableDetailedLogging: bool(raw.enableDetailedLogging, DEFAULTS.enableDetailedLogging),
    };
  }

  // Sent with every loading/result message.
  function toMessage(s) {
    return {
      fontSize: s.displayFontSize,
      fontColor: s.displayFontColor,
      displayPosition: s.displayPosition,
      whiteBackground: s.displayWhiteBackground,
      dotSpacing: s.displayDotSpacing,
      debugPersistentBox: s.displayDebugPersistentBox,
      enableDetailedLogging: s.enableDetailedLogging,
    };
  }

  const MESSAGE_FIELDS = {
    fontSize: "displayFontSize",
    fontColor: "displayFontColor",
    displayPosition: "displayPosition",
    whiteBackground: "displayWhiteBackground",
    dotSpacing: "displayDotSpacing",
    debugPersistentBox: "displayDebugPersistentBox",
    enableDetailedLogging: "enableDetailedLogging",
  };

  // A field the message lacks keeps its current value.
  function fromMessage(ds, current) {
    const merged = { ...current };
    for (const [m, k] of Object.entries(MESSAGE_FIELDS)) {
      if (ds && ds[m] !== undefined) merged[k] = ds[m];
    }
    return sanitizeDisplay(merged);
  }

  return { DEFAULTS, KEYS, isColor, fontSize, color, position, bool, dotSpacing, sanitizeDisplay, toMessage, fromMessage };
})();

if (typeof module === "object" && module.exports) module.exports = MaakimaSettings;
