const logPopupError = (what, err) => {
  try { MaakimaLog.error(`popup ${what}:`, err && err.reason !== undefined ? err.reason : err); } catch (_e) { /* log unavailable; nothing else to do */ }
};
window.addEventListener("error", (e) => { logPopupError("error", e.error || e.message); e.preventDefault(); });
window.addEventListener("unhandledrejection", (e) => { logPopupError("unhandledrejection", e.reason); e.preventDefault(); });

if (MaakimaLog.setSource) MaakimaLog.setSource("popup");
document.addEventListener("DOMContentLoaded", async () => {
  const extApi = typeof browser !== "undefined" ? browser : chrome;
  const REMOTE_JSON_BASE_URL = "https://distributed-clients.github.io/json/";

  const defaults = MaakimaSettings.DEFAULTS;

  const shortcutDisplay = document.getElementById("shortcutDisplay");
  const lastProviderDisplay = document.getElementById("lastProviderDisplay");

  const userGeminiApiKeysInput = document.getElementById("userGeminiApiKeys");
  const keyHealthDisplay = document.getElementById("keyHealthDisplay");
  const fontSizeInput = document.getElementById("fontSizeInput");
  const fontColorInput = document.getElementById("fontColorInput");
  const displayPositionSelect = document.getElementById(
    "displayPositionSelect",
  );
  const whiteBackgroundToggle = document.getElementById(
    "whiteBackgroundToggle",
  );
  const debugPersistentBoxToggle = document.getElementById(
    "debugPersistentBoxToggle",
  );
  const loggingToggle = document.getElementById("loggingToggle");
  const configFileInput = document.getElementById("configFileInput");
  const remoteUserKeyInput = document.getElementById("remoteUserKey");
  const settingsStatus = document.getElementById("settingsStatus");
  const textDecoder = new TextDecoder();
  const textEncoder = new TextEncoder();
  let autoSaveTimer = null;
  let statusHideTimer = null;
  const dotSpacingInput = document.getElementById("dotSpacingInput");

  const setupView = document.getElementById("setup-view");
  const mainView = document.getElementById("main-view");
  const disableFloatingBoxTrigger = document.getElementById("disableFloatingBoxTrigger");

  async function updateViewVisibility() {
    const res = await storageGet([
      "userGeminiApiKeys",
      "disableFloatingKeyBox"
    ]);

    const hasAnyApiKeys =
      (res.userGeminiApiKeys && res.userGeminiApiKeys.length > 0);

    const isDisabled = Boolean(res.disableFloatingKeyBox);

    if (!hasAnyApiKeys && !isDisabled) {
      if (setupView) setupView.classList.remove("hidden");
      if (mainView) mainView.classList.add("hidden");
      document.body.classList.add("setup-mode");
    } else {
      if (setupView) setupView.classList.add("hidden");
      if (mainView) mainView.classList.remove("hidden");
      document.body.classList.remove("setup-mode");
    }
  }

  if (disableFloatingBoxTrigger) {
    disableFloatingBoxTrigger.addEventListener("click", async () => {
      await storageSet({ disableFloatingKeyBox: true });
      updateViewVisibility();
    });
  }

  const clearAllKeysBtn = document.getElementById("clearAllKeysBtn");
  if (clearAllKeysBtn) {
    clearAllKeysBtn.addEventListener("click", async () => {
      const keysToClear = {
        userGeminiApiKeys: [],
        sharedGeminiApiKeys: [],
        remoteUserKey: "",
        disableFloatingKeyBox: false
      };
      await storageSet(keysToClear);
      await loadSettings();
      await updateViewVisibility();
      setStatus("All keys cleared", true);
    });
  }

  await updateViewVisibility();

  function storageGet(keys) {
    try {
      const maybePromise = extApi.storage.local.get(keys);
      if (maybePromise && typeof maybePromise.then === "function") {
        return maybePromise;
      }
    } catch (_e) {
      // Fall through to callback style.
    }

    return new Promise((resolve, reject) => {
      chrome.storage.local.get(keys, (result) => {
        const runtimeError = chrome.runtime && chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }
        resolve(result);
      });
    });
  }

  function storageSet(payload) {
    try {
      const maybePromise = extApi.storage.local.set(payload);
      if (maybePromise && typeof maybePromise.then === "function") {
        return maybePromise;
      }
    } catch (_e) {
      // Fall through to callback style.
    }

    return new Promise((resolve, reject) => {
      chrome.storage.local.set(payload, () => {
        const runtimeError = chrome.runtime && chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }
        resolve();
      });
    });
  }

  function setStatus(message, ok, options = {}) {
    const autoHideMs =
      typeof options.autoHideMs === "number" ? options.autoHideMs : null;

    if (statusHideTimer) {
      clearTimeout(statusHideTimer);
      statusHideTimer = null;
    }
    settingsStatus.classList.remove("hidden", "success", "error");
    settingsStatus.classList.add(ok ? "success" : "error");
    settingsStatus.textContent = message;

    if (autoHideMs && autoHideMs > 0) {
      statusHideTimer = setTimeout(() => {
        settingsStatus.classList.add("hidden");
      }, autoHideMs);
      return;
    }

    if (ok) {
      statusHideTimer = setTimeout(() => {
        settingsStatus.classList.add("hidden");
      }, 3200);
    }
  }

  function normalizeKeyList(value) {
    const values = Array.isArray(value)
      ? value
      : typeof value === "string"
        ? value.split(/[\n,]+/)
        : [];

    return [
      ...new Set(
        values
          .map((entry) => `${entry || ""}`.trim())
          .filter((entry) => Boolean(entry)),
      ),
    ];
  }

  function validateColorInput() {
    const rawColor = ((fontColorInput && fontColorInput.value) || "").trim();

    if (fontColorInput) {
      fontColorInput.setCustomValidity("");
    }

    if (!rawColor) {
      return true;
    }

    if (!MaakimaSettings.isColor(rawColor)) {
      if (fontColorInput) {
        fontColorInput.setCustomValidity("Invalid color. Use #RGB or #RRGGBB");
      }
      return false;
    }

    return true;
  }

  async function loadSettings() {
    try {
      const result = await storageGet([
        "displayFontSize",
        "displayFontColor",
        "displayPosition",
        "displayWhiteBackground",
        "displayDotSpacing",
        "displayDebugPersistentBox",
        "enableDetailedLogging",
        "userGeminiApiKeys",
        "userGeminiApiKey",
        "remoteUserKey",
      ]);

      userGeminiApiKeysInput.value = normalizeKeyList(
        result.userGeminiApiKeys ?? result.userGeminiApiKey,
      ).join("\n");
      fontSizeInput.value = MaakimaSettings.fontSize(result.displayFontSize);
      fontColorInput.value = MaakimaSettings.color(result.displayFontColor);
      if (displayPositionSelect) {
        displayPositionSelect.value = MaakimaSettings.position(
          result.displayPosition,
        );
      }
      whiteBackgroundToggle.checked =
        typeof result.displayWhiteBackground === "boolean"
          ? result.displayWhiteBackground
          : defaults.displayWhiteBackground;
      if (dotSpacingInput) {
        dotSpacingInput.value = MaakimaSettings.dotSpacing(result.displayDotSpacing);
      }
      debugPersistentBoxToggle.checked =
        typeof result.displayDebugPersistentBox === "boolean"
          ? result.displayDebugPersistentBox
          : defaults.displayDebugPersistentBox;
      loggingToggle.checked =
        typeof result.enableDetailedLogging === "boolean"
          ? result.enableDetailedLogging
          : defaults.enableDetailedLogging;
      if (remoteUserKeyInput) {
        remoteUserKeyInput.value = result.remoteUserKey || "";
      }
    } catch (error) {
      setStatus(`Failed loading settings: ${error.message}`, false);
    }
  }

  async function saveSettings() {
    const userGeminiApiKeys = normalizeKeyList(userGeminiApiKeysInput.value);

    const payload = {
      userGeminiApiKeys,
      geminiKeysSavedAt: Date.now(),
      userGeminiApiKey: userGeminiApiKeys[0] || "",
      displayFontSize: MaakimaSettings.fontSize(fontSizeInput.value),
      displayFontColor: MaakimaSettings.color(fontColorInput.value),
      displayPosition: MaakimaSettings.position(displayPositionSelect ? displayPositionSelect.value : undefined),
      displayWhiteBackground: Boolean(whiteBackgroundToggle.checked),
      displayDotSpacing: MaakimaSettings.dotSpacing(dotSpacingInput ? dotSpacingInput.value : undefined),
      displayDebugPersistentBox: Boolean(debugPersistentBoxToggle.checked),
      enableDetailedLogging: Boolean(loggingToggle.checked),
    };

    const remoteKey = ((remoteUserKeyInput && remoteUserKeyInput.value) || "").trim();
    if (remoteKey === "") {
      payload.remoteUserKey = "";
    }

    userGeminiApiKeysInput.value = userGeminiApiKeys.join("\n");

    try {
      await storageSet(payload);
    } catch (error) {
      setStatus(`Failed saving settings: ${error.message}`, false);
    }
  }

  async function saveSettingsNow() {
    if (autoSaveTimer) {
      clearTimeout(autoSaveTimer);
      autoSaveTimer = null;
    }
    await saveSettings();
  }

  function scheduleAutoSave() {
    if (autoSaveTimer) {
      clearTimeout(autoSaveTimer);
    }
    autoSaveTimer = setTimeout(() => {
      saveSettings();
      autoSaveTimer = null;
    }, 250);
  }

  function getCurrentDisplaySettingsPayload() {
    return MaakimaSettings.toMessage({
      displayFontSize: MaakimaSettings.fontSize(fontSizeInput.value),
      displayFontColor: MaakimaSettings.color(fontColorInput.value),
      displayPosition: MaakimaSettings.position(displayPositionSelect ? displayPositionSelect.value : undefined),
      displayWhiteBackground: Boolean(whiteBackgroundToggle.checked),
      displayDotSpacing: MaakimaSettings.dotSpacing(dotSpacingInput ? dotSpacingInput.value : undefined),
      displayDebugPersistentBox: Boolean(debugPersistentBoxToggle.checked),
      enableDetailedLogging: Boolean(loggingToggle.checked),
    });
  }

  async function sendDisplaySettingsPreviewToActiveTab() {
    let tabs;
    try {
      const maybePromise = extApi.tabs.query({
        active: true,
        currentWindow: true,
      });
      tabs =
        maybePromise && typeof maybePromise.then === "function"
          ? await maybePromise
          : await new Promise((resolve) => {
              chrome.tabs.query(
                {
                  active: true,
                  currentWindow: true,
                },
                (result) => resolve(result || []),
              );
            });
    } catch (_error) {
      return;
    }

    const activeTab = Array.isArray(tabs) && tabs.length ? tabs[0] : null;
    const tabId = activeTab && activeTab.id;
    if (typeof tabId !== "number") {
      return;
    }

    const payload = {
      action: "debug_preview_settings",
      displaySettings: getCurrentDisplaySettingsPayload(),
    };

    try {
      const maybePromise = extApi.tabs.sendMessage(tabId, payload);
      if (maybePromise && typeof maybePromise.then === "function") {
        await maybePromise;
      }
    } catch (error) {
      // No content script on this tab (e.g., browser internal pages).
      MaakimaLog.debug(`debug_preview_settings to tab ${tabId}: ${error && error.message}`);
    }
  }

  async function importSettingsFromFile(file) {
    const text = await file.text();
    const imported = MaakimaImport.parseImportedConfig(text, file.name);

    if (imported.userGeminiApiKeys && imported.userGeminiApiKeys.length) {
      userGeminiApiKeysInput.value = imported.userGeminiApiKeys.join("\n");
    }
    if (imported.displayFontSize != null) fontSizeInput.value = MaakimaSettings.fontSize(imported.displayFontSize);
    if (imported.displayFontColor != null) fontColorInput.value = MaakimaSettings.color(imported.displayFontColor);
    if (imported.displayPosition != null && displayPositionSelect) displayPositionSelect.value = MaakimaSettings.position(imported.displayPosition);
    if (imported.displayWhiteBackground != null) whiteBackgroundToggle.checked = Boolean(imported.displayWhiteBackground);
    if (imported.displayDebugPersistentBox != null) debugPersistentBoxToggle.checked = Boolean(imported.displayDebugPersistentBox);
    if (imported.enableDetailedLogging != null) loggingToggle.checked = Boolean(imported.enableDetailedLogging);

    await saveSettings();
    const refiled = Number(imported.refiled) || 0;
    const dropped = Number(imported.dropped) || 0;
    let note = "";
    if (refiled || dropped) {
      MaakimaLog.info(`import ${file.name}: refiled=${refiled} dropped=${dropped}`);
      await MaakimaLog.flush(); // the popup may close before the 1 s debounce
      note = ` (${refiled} refiled, ${dropped} dropped)`;
    }
    setStatus(`Imported ${file.name}${note}`, true);
  }

  async function commitFontSizeAndSave() {
    if (!fontSizeInput) {
      return;
    }
    fontSizeInput.value = MaakimaSettings.fontSize(fontSizeInput.value);
    await saveSettingsNow();
  }

  async function commitColorAndSave() {
    if (!fontColorInput) {
      return;
    }

    const raw = (fontColorInput.value || "").trim();
    const valid = !raw || MaakimaSettings.isColor(raw);
    const sanitized = MaakimaSettings.color(raw);

    fontColorInput.value = sanitized;
    fontColorInput.setCustomValidity("");

    if (!valid) {
      setStatus(`Invalid color. Reset to ${sanitized}`, false, {
        autoHideMs: 2800,
      });
      setTimeout(() => {
        settingsStatus.classList.add("hidden");
      }, 2850);
    }

    await saveSettingsNow();
  }

  async function importSettingsFromRemote() {
    const userKey = ((remoteUserKeyInput && remoteUserKeyInput.value) || "").trim();
    if (!userKey) {
      await storageSet({ remoteUserKey: "" });
      await updateViewVisibility();
      setStatus("Remote key cleared", true);
      return;
    }

    if (!userKey.includes(":")) {
      await storageSet({ remoteUserKey: "" }); // Clear on invalid format too
      if (remoteUserKeyInput) remoteUserKeyInput.value = "";
      await updateViewVisibility();
      throw new Error("Use user:key format");
    }

    setStatus("Importing...", true);

    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { action: "import_remote_user_key", userKey },
        async (response) => {
          const runtimeError = chrome.runtime.lastError;
          if (runtimeError) MaakimaLog.warn("import_remote_user_key:", runtimeError.message);
          if (response && response.success) {
            // Success: reload inputs from the now-updated storage
            loadSettings().then(() => {
              setStatus(`Imported remote settings for ${response.user}`, true);
              resolve();
            });
          } else {
            const errorMsg = response ? response.error : "No response from background";
            setStatus(`Failed: ${errorMsg}`, false);
            if (remoteUserKeyInput) remoteUserKeyInput.value = ""; 
            await storageSet({ remoteUserKey: "" }); // Clear on failure
            await updateViewVisibility();
            reject(new Error(errorMsg));
          }
        }
      );
    });
  }

  async function updateSystemInfo() {
    try {
      const result = await storageGet(["lastProvider", "geminiKeySummary", "sharedGeminiApiKeys"]);
      const k = result.geminiKeySummary;
      const shared = Array.isArray(result.sharedGeminiApiKeys) ? result.sharedGeminiApiKeys.length : 0;
      if (keyHealthDisplay) {
        keyHealthDisplay.textContent = "";
        if (k) {
          keyHealthDisplay.append(`Keys: ${k.ready} ready \u00b7 ${k.cooling} cooling \u00b7 ${k.day} out today \u00b7 ${k.dead} dead${shared ? ` \u00b7 + ${shared} shared` : ""}`);
          for (const l of k.deadLabels || []) {
            keyHealthDisplay.append(document.createElement("br"), l);
          }
        }
      }

      if (result.lastProvider) {
        lastProviderDisplay.textContent = result.lastProvider;
      } else {
        lastProviderDisplay.textContent = "N/A";
      }
    } catch (error) {
      MaakimaLog.warn("Popup system info failed:", error);
      lastProviderDisplay.textContent = "Error";
    }
  }

  await loadSettings();

  // Single dropdown toggle
  const dropdownToggle = document.getElementById("dropdownToggle");
  const settingsDropdown = document.getElementById("settingsDropdown");
  if (dropdownToggle && settingsDropdown) {
    dropdownToggle.addEventListener("click", () => {
      settingsDropdown.classList.toggle("open");
      document.body.classList.toggle("expanded");
    });
  }

  if (fontSizeInput) {
    fontSizeInput.addEventListener("change", commitFontSizeAndSave);
    fontSizeInput.addEventListener("blur", commitFontSizeAndSave);
    fontSizeInput.addEventListener("keydown", (event) => {
      if (event.key !== "Enter") {
        return;
      }
      event.preventDefault();
      commitFontSizeAndSave();
      fontSizeInput.blur();
    });
  }
  if (fontColorInput) {
    fontColorInput.addEventListener("change", commitColorAndSave);
    fontColorInput.addEventListener("blur", commitColorAndSave);
    fontColorInput.addEventListener("keydown", (event) => {
      if (event.key !== "Enter") {
        return;
      }
      event.preventDefault();
      commitColorAndSave();
      fontColorInput.blur();
    });
  }
  if (displayPositionSelect) {
    displayPositionSelect.addEventListener("change", async () => {
      await saveSettingsNow();
      await sendDisplaySettingsPreviewToActiveTab();
    });
  }
  if (loggingToggle) {
    loggingToggle.addEventListener("change", scheduleAutoSave);
  }
  if (whiteBackgroundToggle) {
    whiteBackgroundToggle.addEventListener("change", scheduleAutoSave);
  }
  if (debugPersistentBoxToggle) {
    debugPersistentBoxToggle.addEventListener("change", async () => {
      await saveSettingsNow();
      await sendDisplaySettingsPreviewToActiveTab();
    });
  }
  if (dotSpacingInput) {
    dotSpacingInput.addEventListener("change", async () => {
      dotSpacingInput.value = MaakimaSettings.dotSpacing(dotSpacingInput.value);
      await saveSettingsNow();
      await sendDisplaySettingsPreviewToActiveTab();
    });
    dotSpacingInput.addEventListener("blur", async () => {
      dotSpacingInput.value = MaakimaSettings.dotSpacing(dotSpacingInput.value);
      await saveSettingsNow();
    });
  }
  const downloadLogBtn = document.getElementById("downloadLogBtn");
  if (downloadLogBtn) {
    downloadLogBtn.addEventListener("click", async () => {
      try {
        const logErr = MaakimaLog.lastError && await MaakimaLog.lastError();
        if (logErr) MaakimaLog.warn("log write error:", logErr);
        const ok = await MaakimaLog.download();
        if (!ok && logErr) downloadLogBtn.title = String(logErr);
        setStatus(ok ? "Log downloaded" : "Log download unavailable", true);
      } catch (error) {
        const logErr = MaakimaLog.lastError && await MaakimaLog.lastError();
        if (logErr) downloadLogBtn.title = String(logErr);
        setStatus(`Log download failed: ${error.message}`, false);
      }
    });
  }
  const clearLogBtn = document.getElementById("clearLogBtn");
  if (clearLogBtn) {
    clearLogBtn.addEventListener("click", async () => {
      try {
        await MaakimaLog.clear();
        setStatus("Log cleared", true);
      } catch (error) {
        setStatus(`Log clear failed: ${error.message}`, false);
      }
    });
  }
  if (userGeminiApiKeysInput) {
    userGeminiApiKeysInput.addEventListener("input", scheduleAutoSave);
    userGeminiApiKeysInput.addEventListener("blur", saveSettingsNow);
  }
  if (remoteUserKeyInput) {
    remoteUserKeyInput.addEventListener("input", scheduleAutoSave);
    remoteUserKeyInput.addEventListener("keydown", async (event) => {
      if (event.key !== "Enter") {
        return;
      }
      event.preventDefault();
      remoteUserKeyInput.blur();
      try {
        await importSettingsFromRemote();
      } catch (error) {
        setStatus(`Failed remote import: ${error.message}`, false);
      }
    });
    remoteUserKeyInput.addEventListener("blur", async () => {
      const val = (remoteUserKeyInput.value || "").trim();
      if (val && val.includes(":")) {
        await saveSettingsNow();
        try {
          await importSettingsFromRemote();
        } catch (error) {
          setStatus(`Failed remote import: ${error.message}`, false);
        }
      } else {
        await saveSettingsNow();
      }
    });
  }

  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") {
      saveSettingsNow();
    }
  });

  if (configFileInput) {
    configFileInput.addEventListener("change", async () => {
      const file = configFileInput.files && configFileInput.files[0];
      if (!file) {
        return;
      }

      try {
        await importSettingsFromFile(file);
      } catch (error) {
        setStatus(`Failed importing file: ${error.message}`, false);
      } finally {
        configFileInput.value = "";
      }
    });
  }

  updateSystemInfo();
  setInterval(updateSystemInfo, 30000);
});
