var MaakimaAnswer = (function () {
function getPrompt() {
  return [
    "You are an expert at solving screenshot-based multiple-choice questions.",
    "Analyze only the FIRST visible multiple-choice question in the image.",
    "Think carefully and deeply before answering.",
    "",
    "First, think through the problem step-by-step and write out your full reasoning in plain text.",
    "CRITICAL REASONING STEP: Before solving the problem, explicitly map every visible option to its position number. Write: 'Position 1 is [Option text], Position 2 is [Option text]', etc.",
    "",
    "After reasoning, output the final answer inside <answer>...</answer> tags on a single final line.",
    "No extra text is allowed after the closing </answer> tag.",
    "If answerable, output exactly:",
    '<answer>{"status":"answered","answers":[1]}</answer>',
    "If multiple answers are correct, list all in answers sorted ascending.",
    "If it cannot be answered from the visible image, output exactly:",
    '<answer>{"status":"no_answer","reason":"short reason"}</answer>',
    "Rules:",
    "- 'answers' must contain only integers 1 to 6",
    "- no duplicate answers",
    "- DO NOT put reasoning inside the JSON",
    "- JSON must contain only status plus answers/reason",
    "- If the question is a True/False question with no numbered options, output 1 for True, 2 for False.",
    "- If the answer is a numerical value (an integer) and there are no options, return that number as the answer if it is between 1 and 6 (inclusive). Otherwise output no_answer.",
    "- IMPORTANT: Always return the OPTION's POSITION NUMBER (1 for 1st option, 2 for 2nd, etc.), regardless of how options are labeled. Options may be numbered (1, 2, 3), lettered (A, B, C), or use Roman numerals. For example: if the correct answer is the 2nd option labeled 'B) I and IV', return 2 — NOT 1 and 4.",
    "- Only output a calculated/computed value as the answer if there are NO options visible. If options are present, you MUST pick from them by position number.",
  ].join("\n");
}

function getSimpleStrictJsonPrompt() {
  return [
    "You are solving a screenshot-based multiple choice quiz question.",
    "Analyze only the FIRST visible multiple-choice question in the image.",
    "Think carefully and deeply before answering.",
    "CRITICAL: Before answering, map every visible option to its position number (1st option = 1, 2nd = 2, etc.).",
    "",
    "Respond with one line only, wrapping STRICT JSON in <answer>...</answer>.",
    "If answerable, output exactly:",
    '<answer>{"status":"answered","answers":[1]}</answer>',
    "If multiple answers are correct, list all in answers sorted ascending.",
    "If it cannot be answered from the visible image, output exactly:",
    '<answer>{"status":"no_answer","reason":"short reason"}</answer>',
    "Rules:",
    "- answers must contain only integers 1 to 6",
    "- no duplicate answers",
    "- reason must be short and specific",
    "- If the question is True/False with no numbered options, output 1 for True, 2 for False.",
    "- If the answer is a numerical integer and there are no options, return that number if it is between 1 and 6 (inclusive). Otherwise output no_answer.",
    "- IMPORTANT: Always return the OPTION's POSITION NUMBER (1 for 1st option, 2 for 2nd, etc.), regardless of how options are labeled. Options may be numbered (1, 2, 3), lettered (A, B, C), or use Roman numerals. For example: if the correct answer is the 2nd option labeled 'B) I and IV', return 2 — NOT 1 and 4.",
    "- Only output a calculated/computed value as the answer if there are NO options visible. If options are present, you MUST pick from them by position number.",
  ].join("\n");
}

function tryParseJsonObject(text) {
  if (!text || typeof text !== "string") {
    return null;
  }

  const trimmed = text.trim();

  // Preferred extraction: read payload inside explicit answer tags.
  const taggedMatch = trimmed.match(/<answer>([\s\S]*?)<\/answer>/i);
  if (taggedMatch && taggedMatch[1]) {
    try {
      return JSON.parse(taggedMatch[1].trim());
    } catch (_e) {
      // Continue with defensive parsing below.
    }
  }

  // Quick fallback: if model placed JSON on the final line, parse that line directly.
  const lines = trimmed
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => Boolean(line));
  if (lines.length > 0) {
    const lastLine = lines[lines.length - 1];

    const lastLineTaggedMatch = lastLine.match(/<answer>([\s\S]*?)<\/answer>/i);
    if (lastLineTaggedMatch && lastLineTaggedMatch[1]) {
      try {
        return JSON.parse(lastLineTaggedMatch[1].trim());
      } catch (_e) {
        // Continue with other fallbacks.
      }
    }

    if (lastLine.startsWith("{") && lastLine.endsWith("}")) {
      try {
        return JSON.parse(lastLine);
      } catch (_e) {
        // Continue with other fallbacks.
      }
    }
  }

  if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
    try {
      return JSON.parse(trimmed);
    } catch (_e) {
      // Fall through to bracket extraction.
    }
  }

  const firstBrace = trimmed.indexOf("{");
  const lastBrace = trimmed.lastIndexOf("}");
  if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
    const candidate = trimmed.slice(firstBrace, lastBrace + 1);
    try {
      return JSON.parse(candidate);
    } catch (_e) {
      return null;
    }
  }

  return null;
}

function normalizeAnswerArray(values) {
  if (!Array.isArray(values)) {
    return [];
  }

  const numbers = values
    .map((value) => Number(value))
    .filter((value) => Number.isInteger(value) && value >= 1 && value <= 6);

  return [...new Set(numbers)].sort((a, b) => a - b);
}

function extractStructuredAnswer(rawText) {
  const text = (rawText || "").trim();
  if (!text) {
    return {
      status: "no_answer",
      reason: "Model returned an empty response.",
      answers: [],
      rawText,
    };
  }

  const parsed = tryParseJsonObject(text);
  if (parsed && typeof parsed === "object") {
    const status = `${parsed.status || ""}`.trim().toLowerCase();
    const answers = normalizeAnswerArray(parsed.answers);

    if (status === "answered" && answers.length > 0) {
      return {
        status: "answered",
        answers,
        reason: "",
        rawText,
      };
    }

    if (status === "no_answer") {
      const reason =
        `${parsed.reason || "No visible solvable question."}`.trim();
      return {
        status: "no_answer",
        reason,
        answers: [],
        rawText,
      };
    }
  }

  // No digit-scraping fallback: it scored 0/36 in the 2026-10-21 bench (reasoning text is full of
  // option numbers), so an unparsable reply shows the underscore instead of a guess.
  return {
    status: "no_answer",
    reason: "Model gave no parsable answer.",
    answers: [],
    rawText,
  };
}
  return { getPrompt, getSimpleStrictJsonPrompt, tryParseJsonObject, normalizeAnswerArray, extractStructuredAnswer };
})();
if (typeof module === "object" && module.exports) module.exports = MaakimaAnswer;
