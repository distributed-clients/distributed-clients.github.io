document.addEventListener("DOMContentLoaded", () => {
  const extApi = typeof browser !== "undefined" ? browser : chrome;
  const REMOTE_JSON_BASE_URL = "https://distributed-clients.github.io/json/";

  const defaults = {
    displayFontSize: 30,
    displayFontColor: "#cfcdcd",
    enableDetailedLogging: true,
    userGroqApiKeys: [],
    userGeminiApiKeys: [],
  };

  const shortcutDisplay = document.getElementById("shortcutDisplay");
  const apiKeyDisplay = document.getElementById("apiKeyDisplay");
  const cacheStatusDisplay = document.getElementById("cacheStatusDisplay");
  const timeRemainingDisplay = document.getElementById("timeRemainingDisplay");
  const lastProviderDisplay = document.getElementById("lastProviderDisplay");

  const userGroqApiKeysInput = document.getElementById("userGroqApiKeys");
  const userGeminiApiKeysInput = document.getElementById("userGeminiApiKeys");
  const fontSizeInput = document.getElementById("fontSizeInput");
  const fontColorInput = document.getElementById("fontColorInput");
  const loggingToggle = document.getElementById("loggingToggle");
  const configFileInput = document.getElementById("configFileInput");
  const remoteUserKeyInput = document.getElementById("remoteUserKey");
  const importRemoteButton = document.getElementById("importRemoteButton");
  const settingsStatus = document.getElementById("settingsStatus");
  const textDecoder = new TextDecoder();
  const textEncoder = new TextEncoder();
  let autoSaveTimer = null;
  let statusHideTimer = null;

  function b64ToBytes(b64) {
    const binary = atob(b64 || "");
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  }

  async function deriveKey(passphrase, saltBytes, iterations) {
    const keyMaterial = await crypto.subtle.importKey(
      "raw",
      textEncoder.encode(passphrase),
      "PBKDF2",
      false,
      ["deriveKey"],
    );

    return crypto.subtle.deriveKey(
      {
        name: "PBKDF2",
        hash: "SHA-256",
        salt: saltBytes,
        iterations,
      },
      keyMaterial,
      { name: "AES-CTR", length: 256 },
      false,
      ["decrypt"],
    );
  }

  async function decryptUserPayload(payload, passphrase) {
    const salt = b64ToBytes(payload.salt);
    const iv = b64ToBytes(payload.iv);
    const data = b64ToBytes(payload.data);
    const key = await deriveKey(passphrase, salt, payload.iterations || 310000);

    const decrypted = await crypto.subtle.decrypt(
      {
        name: "AES-CTR",
        counter: iv,
        length: 64,
      },
      key,
      data,
    );

    return new Uint8Array(decrypted);
  }

  function extractEmbeddedUsersFromHtml(htmlText) {
    const match = htmlText.match(
      /const\s+EMBEDDED_USERS\s*=\s*(\{[\s\S]*?\});/,
    );
    if (!match || !match[1]) {
      throw new Error("Could not find EMBEDDED_USERS in remote page");
    }
    return JSON.parse(match[1]);
  }

  function applyImportedToInputs(imported) {
    if (typeof imported.displayFontSize !== "undefined") {
      fontSizeInput.value = sanitizeFontSize(imported.displayFontSize);
    }
    if (typeof imported.displayFontColor !== "undefined") {
      fontColorInput.value = sanitizeColor(imported.displayFontColor);
    }
    if (typeof imported.enableDetailedLogging !== "undefined") {
      loggingToggle.checked = Boolean(imported.enableDetailedLogging);
    }
    if (
      Array.isArray(imported.userGroqApiKeys) &&
      imported.userGroqApiKeys.length
    ) {
      userGroqApiKeysInput.value = normalizeKeyList(
        imported.userGroqApiKeys,
      ).join("\n");
    }
    if (
      Array.isArray(imported.userGeminiApiKeys) &&
      imported.userGeminiApiKeys.length
    ) {
      userGeminiApiKeysInput.value = normalizeKeyList(
        imported.userGeminiApiKeys,
      ).join("\n");
    }
  }

  function normalizeKeyList(value) {
    const values = Array.isArray(value)
      ? value
      : typeof value === "string"
        ? value.split(/[\n,]+/)
        : [];

    return [
      ...new Set(
        values
          .map((entry) => `${entry || ""}`.trim())
          .filter((entry) => Boolean(entry)),
      ),
    ];
  }

  function parseBoolean(value) {
    if (typeof value === "boolean") {
      return value;
    }
    const normalized = `${value || ""}`.trim().toLowerCase();
    return ["1", "true", "yes", "on"].includes(normalized);
  }

  function parseImportedJson(text) {
    const raw = JSON.parse(text);
    const source = raw && typeof raw.settings === "object" ? raw.settings : raw;

    return {
      userGroqApiKeys: normalizeKeyList(
        source.userGroqApiKeys ??
          source.userGroqApiKey ??
          source.groqApiKeys ??
          source.groqApiKey ??
          source.groq,
      ),
      userGeminiApiKeys: normalizeKeyList(
        source.userGeminiApiKeys ??
          source.userGeminiApiKey ??
          source.geminiApiKeys ??
          source.geminiApiKey ??
          source.gemini,
      ),
      displayFontSize:
        source.displayFontSize ?? source.fontSize ?? source.answerFontSize,
      displayFontColor:
        source.displayFontColor ?? source.fontColor ?? source.answerFontColor,
      enableDetailedLogging:
        source.enableDetailedLogging ??
        source.logging ??
        source.detailedLogging,
    };
  }

  function parseImportedText(text) {
    const lines = text.split(/\r?\n/);
    const result = {
      userGroqApiKeys: [],
      userGeminiApiKeys: [],
    };
    let activeSection = "";

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#") || trimmed.startsWith("//")) {
        continue;
      }

      const sectionMatch = trimmed.match(
        /^(groq|gemini|settings|config)\s*[:=]\s*$/i,
      );
      if (sectionMatch) {
        activeSection = sectionMatch[1].toLowerCase();
        continue;
      }

      const keyValueMatch = trimmed.match(/^([A-Za-z][\w.-]*)\s*[:=]\s*(.+)$/);
      if (keyValueMatch) {
        const key = keyValueMatch[1].trim().toLowerCase();
        const value = keyValueMatch[2].trim();

        if (
          key === "displayfontsize" ||
          key === "fontsize" ||
          key === "answerfontsize"
        ) {
          result.displayFontSize = value;
          continue;
        }
        if (
          key === "displayfontcolor" ||
          key === "fontcolor" ||
          key === "answerfontcolor"
        ) {
          result.displayFontColor = value;
          continue;
        }
        if (
          key === "enabledetailedlogging" ||
          key === "logging" ||
          key === "detailedlogging"
        ) {
          result.enableDetailedLogging = parseBoolean(value);
          continue;
        }
        if (
          key === "groq" ||
          key === "groqapikey" ||
          key === "usergroqapikey"
        ) {
          result.userGroqApiKeys.push(value);
          continue;
        }
        if (
          key === "gemini" ||
          key === "geminiapikey" ||
          key === "usergeminiapikey"
        ) {
          result.userGeminiApiKeys.push(value);
          continue;
        }
      }

      if (activeSection === "groq") {
        result.userGroqApiKeys.push(trimmed);
        continue;
      }

      if (activeSection === "gemini") {
        result.userGeminiApiKeys.push(trimmed);
        continue;
      }

      if (/^gsk_/i.test(trimmed) || /groq/i.test(trimmed)) {
        result.userGroqApiKeys.push(trimmed);
        continue;
      }

      if (/^AIza/i.test(trimmed)) {
        result.userGeminiApiKeys.push(trimmed);
      }
    }

    return result;
  }

  function parseImportedConfig(text, fileName) {
    const trimmedName = `${fileName || ""}`.toLowerCase();
    try {
      if (trimmedName.endsWith(".json")) {
        return parseImportedJson(text);
      }

      try {
        return parseImportedJson(text);
      } catch (_jsonError) {
        return parseImportedText(text);
      }
    } catch (_error) {
      return parseImportedText(text);
    }
  }

  function storageGet(keys) {
    try {
      const maybePromise = extApi.storage.local.get(keys);
      if (maybePromise && typeof maybePromise.then === "function") {
        return maybePromise;
      }
    } catch (_e) {
      // Fall through to callback style.
    }

    return new Promise((resolve, reject) => {
      chrome.storage.local.get(keys, (result) => {
        const runtimeError = chrome.runtime && chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }
        resolve(result);
      });
    });
  }

  function storageSet(payload) {
    try {
      const maybePromise = extApi.storage.local.set(payload);
      if (maybePromise && typeof maybePromise.then === "function") {
        return maybePromise;
      }
    } catch (_e) {
      // Fall through to callback style.
    }

    return new Promise((resolve, reject) => {
      chrome.storage.local.set(payload, () => {
        const runtimeError = chrome.runtime && chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }
        resolve();
      });
    });
  }

  function setStatus(message, ok, options = {}) {
    const autoHideMs =
      typeof options.autoHideMs === "number" ? options.autoHideMs : null;

    if (statusHideTimer) {
      clearTimeout(statusHideTimer);
      statusHideTimer = null;
    }
    settingsStatus.classList.remove("hidden", "success", "error");
    settingsStatus.classList.add(ok ? "success" : "error");
    settingsStatus.textContent = message;

    if (autoHideMs && autoHideMs > 0) {
      statusHideTimer = setTimeout(() => {
        settingsStatus.classList.add("hidden");
      }, autoHideMs);
      return;
    }

    if (ok) {
      statusHideTimer = setTimeout(() => {
        settingsStatus.classList.add("hidden");
      }, 3200);
    }
  }

  function sanitizeFontSize(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) {
      return defaults.displayFontSize;
    }
    return Math.max(10, Math.min(80, Math.round(number)));
  }

  function sanitizeColor(value) {
    if (typeof value !== "string") {
      return defaults.displayFontColor;
    }

    const trimmed = value.trim();
    if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(trimmed)) {
      return trimmed;
    }
    return defaults.displayFontColor;
  }

  function isValidColor(value) {
    if (typeof value !== "string") {
      return false;
    }
    return /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(value.trim());
  }

  function validateColorInput() {
    const rawColor = (fontColorInput?.value || "").trim();

    if (fontColorInput) {
      fontColorInput.setCustomValidity("");
    }

    if (!rawColor) {
      return true;
    }

    if (!isValidColor(rawColor)) {
      if (fontColorInput) {
        fontColorInput.setCustomValidity("Invalid color. Use #RGB or #RRGGBB");
      }
      return false;
    }

    return true;
  }

  async function loadSettings() {
    try {
      const result = await storageGet([
        "displayFontSize",
        "displayFontColor",
        "enableDetailedLogging",
        "userGroqApiKeys",
        "userGeminiApiKeys",
        "userGroqApiKey",
        "userGeminiApiKey",
        "remoteUserKey",
      ]);

      userGroqApiKeysInput.value = normalizeKeyList(
        result.userGroqApiKeys ?? result.userGroqApiKey,
      ).join("\n");
      userGeminiApiKeysInput.value = normalizeKeyList(
        result.userGeminiApiKeys ?? result.userGeminiApiKey,
      ).join("\n");
      fontSizeInput.value = sanitizeFontSize(result.displayFontSize);
      fontColorInput.value = sanitizeColor(result.displayFontColor);
      loggingToggle.checked =
        typeof result.enableDetailedLogging === "boolean"
          ? result.enableDetailedLogging
          : defaults.enableDetailedLogging;
      if (remoteUserKeyInput) {
        remoteUserKeyInput.value = result.remoteUserKey || "";
      }
    } catch (error) {
      setStatus(`Failed loading settings: ${error.message}`, false);
    }
  }

  async function saveSettings() {
    const userGroqApiKeys = normalizeKeyList(userGroqApiKeysInput.value);
    const userGeminiApiKeys = normalizeKeyList(userGeminiApiKeysInput.value);

    const payload = {
      userGroqApiKeys,
      userGeminiApiKeys,
      userGroqApiKey: userGroqApiKeys[0] || "",
      userGeminiApiKey: userGeminiApiKeys[0] || "",
      displayFontSize: sanitizeFontSize(fontSizeInput.value),
      displayFontColor: sanitizeColor(fontColorInput.value),
      enableDetailedLogging: Boolean(loggingToggle.checked),
      remoteUserKey: (remoteUserKeyInput?.value || "").trim(),
    };

    userGroqApiKeysInput.value = userGroqApiKeys.join("\n");
    userGeminiApiKeysInput.value = userGeminiApiKeys.join("\n");

    try {
      await storageSet(payload);
    } catch (error) {
      setStatus(`Failed saving settings: ${error.message}`, false);
    }
  }

  async function saveSettingsNow() {
    if (autoSaveTimer) {
      clearTimeout(autoSaveTimer);
      autoSaveTimer = null;
    }
    await saveSettings();
  }

  function scheduleAutoSave() {
    if (autoSaveTimer) {
      clearTimeout(autoSaveTimer);
    }
    autoSaveTimer = setTimeout(() => {
      saveSettings();
      autoSaveTimer = null;
    }, 250);
  }

  async function importSettingsFromFile(file) {
    const text = await file.text();
    const imported = parseImportedConfig(text, file.name);

    applyImportedToInputs(imported);

    await saveSettings();
    setStatus(`Imported ${file.name}`, true);
  }

  async function commitFontSizeAndSave() {
    if (!fontSizeInput) {
      return;
    }
    fontSizeInput.value = sanitizeFontSize(fontSizeInput.value);
    await saveSettingsNow();
  }

  async function commitColorAndSave() {
    if (!fontColorInput) {
      return;
    }

    const raw = (fontColorInput.value || "").trim();
    const valid = !raw || isValidColor(raw);
    const sanitized = sanitizeColor(raw);

    fontColorInput.value = sanitized;
    fontColorInput.setCustomValidity("");

    if (!valid) {
      setStatus(`Invalid color. Reset to ${sanitized}`, false, {
        autoHideMs: 2800,
      });
      setTimeout(() => {
        settingsStatus.classList.add("hidden");
      }, 2850);
    }

    await saveSettingsNow();
  }

  async function importSettingsFromRemote() {
    const userKey = (remoteUserKeyInput?.value || "").trim();
    const delimiterIndex = userKey.indexOf(":");
    const user =
      delimiterIndex === -1 ? "" : userKey.slice(0, delimiterIndex).trim();
    const key = delimiterIndex === -1 ? "" : userKey.slice(delimiterIndex + 1);

    if (!user || !key) {
      throw new Error("Use user:key format");
    }

    const remoteUrl = new URL(REMOTE_JSON_BASE_URL);
    remoteUrl.searchParams.set("user", user);

    const response = await fetch(remoteUrl.toString(), { cache: "no-store" });
    if (!response.ok) {
      throw new Error(`Remote fetch failed (${response.status})`);
    }

    const htmlText = await response.text();
    const embeddedUsers = extractEmbeddedUsersFromHtml(htmlText);
    const encryptedPayload = embeddedUsers[user];
    if (!encryptedPayload) {
      throw new Error("User not found in remote payload");
    }

    const decryptedBytes = await decryptUserPayload(encryptedPayload, key);
    const decryptedText = textDecoder.decode(decryptedBytes);
    const imported = parseImportedConfig(decryptedText, "remote.json");

    applyImportedToInputs(imported);
    await saveSettings();
    setStatus(`Imported remote settings for ${user}`, true);
  }

  async function updateSystemInfo() {
    try {
      const TWO_HOURS_MS = 2 * 60 * 60 * 1000;
      const now = Date.now();
      const result = await storageGet([
        "cachedApiKey",
        "keyTimestamp",
        "lastProvider",
        "lastProviderSource",
      ]);

      if (result.cachedApiKey) {
        const key = result.cachedApiKey;
        apiKeyDisplay.textContent =
          key.length > 8
            ? `${key.substring(0, 4)}...${key.substring(key.length - 4)}`
            : key;
      } else {
        apiKeyDisplay.textContent = "Not cached";
      }

      if (result.keyTimestamp) {
        const timeElapsed = now - result.keyTimestamp;
        const timeRemaining = TWO_HOURS_MS - timeElapsed;
        if (timeRemaining > 0) {
          cacheStatusDisplay.textContent = "Cached";
          const hours = Math.floor(timeRemaining / (60 * 60 * 1000));
          const minutes = Math.floor(
            (timeRemaining % (60 * 60 * 1000)) / (60 * 1000),
          );
          timeRemainingDisplay.textContent = `${hours}h ${minutes}m`;
        } else {
          cacheStatusDisplay.textContent = "Expired";
          timeRemainingDisplay.textContent = "0h 0m";
        }
      } else {
        cacheStatusDisplay.textContent = "No cache";
        timeRemainingDisplay.textContent = "N/A";
      }

      if (result.lastProviderSource) {
        lastProviderDisplay.textContent = `${result.lastProviderSource}`;
      } else if (result.lastProvider) {
        lastProviderDisplay.textContent = result.lastProvider;
      } else {
        lastProviderDisplay.textContent = "N/A";
      }
    } catch (error) {
      apiKeyDisplay.textContent = "Error";
      cacheStatusDisplay.textContent = "Error";
      timeRemainingDisplay.textContent = "Error";
      lastProviderDisplay.textContent = "Error";
    }
  }

  if (shortcutDisplay) {
    shortcutDisplay.textContent = "Middle-Click on any page";
  }

  if (fontSizeInput) {
    fontSizeInput.addEventListener("change", commitFontSizeAndSave);
    fontSizeInput.addEventListener("blur", commitFontSizeAndSave);
    fontSizeInput.addEventListener("keydown", (event) => {
      if (event.key !== "Enter") {
        return;
      }
      event.preventDefault();
      commitFontSizeAndSave();
      fontSizeInput.blur();
    });
  }
  if (fontColorInput) {
    fontColorInput.addEventListener("change", commitColorAndSave);
    fontColorInput.addEventListener("blur", commitColorAndSave);
    fontColorInput.addEventListener("keydown", (event) => {
      if (event.key !== "Enter") {
        return;
      }
      event.preventDefault();
      commitColorAndSave();
      fontColorInput.blur();
    });
  }
  if (loggingToggle) {
    loggingToggle.addEventListener("change", scheduleAutoSave);
  }
  if (userGroqApiKeysInput) {
    userGroqApiKeysInput.addEventListener("input", scheduleAutoSave);
    userGroqApiKeysInput.addEventListener("blur", saveSettingsNow);
  }
  if (userGeminiApiKeysInput) {
    userGeminiApiKeysInput.addEventListener("input", scheduleAutoSave);
    userGeminiApiKeysInput.addEventListener("blur", saveSettingsNow);
  }
  if (remoteUserKeyInput) {
    remoteUserKeyInput.addEventListener("input", scheduleAutoSave);
    remoteUserKeyInput.addEventListener("blur", saveSettingsNow);
    remoteUserKeyInput.addEventListener("keydown", async (event) => {
      if (event.key !== "Enter") {
        return;
      }
      event.preventDefault();
      try {
        await importSettingsFromRemote();
      } catch (error) {
        setStatus(`Failed remote import: ${error.message}`, false);
      }
    });
  }

  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") {
      saveSettingsNow();
    }
  });

  if (configFileInput) {
    configFileInput.addEventListener("change", async () => {
      const file = configFileInput.files && configFileInput.files[0];
      if (!file) {
        return;
      }

      try {
        await importSettingsFromFile(file);
      } catch (error) {
        setStatus(`Failed importing file: ${error.message}`, false);
      } finally {
        configFileInput.value = "";
      }
    });
  }

  if (importRemoteButton) {
    importRemoteButton.addEventListener("click", async () => {
      try {
        await importSettingsFromRemote();
      } catch (error) {
        setStatus(`Failed remote import: ${error.message}`, false);
      }
    });
  }

  loadSettings();
  updateSystemInfo();
  setInterval(updateSystemInfo, 30000);
});
