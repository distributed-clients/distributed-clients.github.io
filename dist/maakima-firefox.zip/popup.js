// popup.js
document.addEventListener("DOMContentLoaded", () => {
  const extApi = typeof browser !== "undefined" ? browser : chrome;

  const mainContentDiv = document.getElementById("main-content");
  const shortcutDisplay = document.getElementById("shortcutDisplay");
  const apiKeyDisplay = document.getElementById("apiKeyDisplay");
  const cacheStatusDisplay = document.getElementById("cacheStatusDisplay");
  const timeRemainingDisplay = document.getElementById("timeRemainingDisplay");

  // Donation elements
  const donateApiKeyInput = document.getElementById("donateApiKey");
  const donateEmailInput = document.getElementById("donateEmail");
  const donateButton = document.getElementById("donateButton");
  const donateStatus = document.getElementById("donateStatus");

  function storageGet(keys) {
    try {
      const maybePromise = extApi.storage.local.get(keys);
      if (maybePromise && typeof maybePromise.then === "function") {
        return maybePromise;
      }
    } catch (_e) {
      // Fall through to callback style.
    }

    return new Promise((resolve, reject) => {
      chrome.storage.local.get(keys, (result) => {
        const runtimeError = chrome.runtime && chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }
        resolve(result);
      });
    });
  }

  function runtimeSendMessage(message) {
    try {
      const maybePromise = extApi.runtime.sendMessage(message);
      if (maybePromise && typeof maybePromise.then === "function") {
        return maybePromise;
      }
    } catch (_e) {
      // Fall through to callback style.
    }

    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        const runtimeError = chrome.runtime && chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }
        resolve(response);
      });
    });
  }

  function showDonationStatus(message, type = "loading") {
    donateStatus.classList.remove("hidden", "success", "error", "loading");
    donateStatus.classList.add(type);
    donateStatus.textContent = message;
  }

  function hideDonationStatus() {
    donateStatus.classList.add("hidden");
  }

  async function donateApiKey() {
    const apiKey = donateApiKeyInput.value.trim();
    const email = donateEmailInput.value.trim();

    if (!apiKey) {
      showDonationStatus("Please enter an API key", "error");
      return;
    }

    if (!email) {
      showDonationStatus("Please enter your first name as on moodle", "error");
      return;
    }

    // Basic validation for Gemini API key format
    if (!apiKey.startsWith("AIza") || apiKey.length < 35) {
      showDonationStatus("Invalid API key format", "error");
      return;
    }

    donateButton.disabled = true;
    showDonationStatus("Finding working server...", "loading");

    try {
      // Get server URL from background script with failover
      const response = await runtimeSendMessage({ action: "getServerUrl" });

      if (response.warning) {
        console.warn("Server selection warning:", response.warning);
      }

      const serverUrl =
        response.serverUrl || "https://kimaaka-server.vercel.app/api";

      console.log(`Donating to server: ${serverUrl}`);

      if (response.message) {
        console.log("Server selection:", response.message);
      }

      showDonationStatus("Validating API key...", "loading");

      const donationResponse = await fetch(`${serverUrl}/donate-key`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          apiKey: apiKey,
          donorEmail: email || "anonymous",
        }),
      });

      const data = await donationResponse.json();

      if (donationResponse.ok) {
        showDonationStatus(
          "✅ Thank you! API key validated and added successfully!",
          "success",
        );
        donateApiKeyInput.value = "";
        donateEmailInput.value = "";

        // Hide success message after 5 seconds
        setTimeout(() => {
          hideDonationStatus();
        }, 5000);
      } else {
        showDonationStatus(data.error || "Failed to donate API key", "error");
      }
    } catch (error) {
      console.error("Donation error:", error);
      showDonationStatus(
        "Network error. Please check if the server is running.",
        "error",
      );
    } finally {
      donateButton.disabled = false;
    }
  }

  async function updateTestingInfo() {
    try {
      const TWO_HOURS_MS = 2 * 60 * 60 * 1000;
      const result = await storageGet(["cachedApiKey", "keyTimestamp"]);
      const now = Date.now();
      console.log("[Maakima][Popup] Cache read result:", {
        hasKey: !!result.cachedApiKey,
        hasTimestamp: !!result.keyTimestamp,
      });

      if (result.cachedApiKey) {
        // Show first and last 4 characters of API key
        const key = result.cachedApiKey;
        const maskedKey =
          key.length > 8
            ? `${key.substring(0, 4)}...${key.substring(key.length - 4)}`
            : key;
        apiKeyDisplay.textContent = maskedKey;

        if (result.keyTimestamp) {
          const timeElapsed = now - result.keyTimestamp;
          const timeRemaining = TWO_HOURS_MS - timeElapsed;

          if (timeRemaining > 0) {
            cacheStatusDisplay.textContent = "Cached";
            const hoursRemaining = Math.floor(timeRemaining / (60 * 60 * 1000));
            const minutesRemaining = Math.floor(
              (timeRemaining % (60 * 60 * 1000)) / (60 * 1000),
            );
            timeRemainingDisplay.textContent = `${hoursRemaining}h ${minutesRemaining}m`;
          } else {
            cacheStatusDisplay.textContent = "Expired";
            timeRemainingDisplay.textContent = "0h 0m";
          }
        } else {
          cacheStatusDisplay.textContent = "No timestamp";
          timeRemainingDisplay.textContent = "Unknown";
        }
      } else {
        apiKeyDisplay.textContent = "Not cached";
        cacheStatusDisplay.textContent = "No cache";
        timeRemainingDisplay.textContent = "N/A";
        console.log(
          "[Maakima][Popup] No cached key yet. This is expected before first analysis.",
        );
      }
    } catch (error) {
      apiKeyDisplay.textContent = "Error loading";
      cacheStatusDisplay.textContent = "Error";
      timeRemainingDisplay.textContent = "Error";
      console.error("[Maakima][Popup] Failed to load cache status:", error);
    }
  }

  // Show main content immediately since no login is required
  mainContentDiv.classList.remove("hidden");

  // Update testing info on load and every 30 seconds
  updateTestingInfo();
  setInterval(updateTestingInfo, 30000);

  // Donation button event listener
  if (donateButton) {
    donateButton.addEventListener("click", donateApiKey);
  }

  // Hide donation status when user starts typing
  if (donateApiKeyInput) {
    donateApiKeyInput.addEventListener("input", () => {
      if (donateStatus && !donateStatus.classList.contains("hidden")) {
        hideDonationStatus();
      }
    });
  }

  // Allow Enter key to trigger donation
  if (donateApiKeyInput) {
    donateApiKeyInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        donateApiKey();
      }
    });
  }

  if (donateEmailInput) {
    donateEmailInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        donateApiKey();
      }
    });
  }

  // Update UI to reflect the new mouse trigger
  if (shortcutDisplay) {
    shortcutDisplay.textContent = "Middle-Click on any page";
  }
});
