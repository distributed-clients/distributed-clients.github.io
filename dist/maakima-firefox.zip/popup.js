document.addEventListener("DOMContentLoaded", async () => {
  const extApi = typeof browser !== "undefined" ? browser : chrome;
  const REMOTE_JSON_BASE_URL = "https://distributed-clients.github.io/json/";

  const defaults = {
    displayFontSize: 30,
    displayFontColor: "#cfcdcd",
    displayPosition: "center",
    displayWhiteBackground: true,
    displayDebugPersistentBox: false,
    enableDetailedLogging: true,
    userGroqApiKeys: [],
    userMistralApiKeys: [],
    userGeminiApiKeys: [],
  };

  const shortcutDisplay = document.getElementById("shortcutDisplay");
  const lastProviderDisplay = document.getElementById("lastProviderDisplay");

  const userGroqApiKeysInput = document.getElementById("userGroqApiKeys");
  const userMistralApiKeysInput = document.getElementById("userMistralApiKeys");
  const userGeminiApiKeysInput = document.getElementById("userGeminiApiKeys");
  const fontSizeInput = document.getElementById("fontSizeInput");
  const fontColorInput = document.getElementById("fontColorInput");
  const displayPositionSelect = document.getElementById(
    "displayPositionSelect",
  );
  const whiteBackgroundToggle = document.getElementById(
    "whiteBackgroundToggle",
  );
  const debugPersistentBoxToggle = document.getElementById(
    "debugPersistentBoxToggle",
  );
  const loggingToggle = document.getElementById("loggingToggle");
  const configFileInput = document.getElementById("configFileInput");
  const remoteUserKeyInput = document.getElementById("remoteUserKey");
  const settingsStatus = document.getElementById("settingsStatus");
  const textDecoder = new TextDecoder();
  const textEncoder = new TextEncoder();
  let autoSaveTimer = null;
  let statusHideTimer = null;

  const setupView = document.getElementById("setup-view");
  const mainView = document.getElementById("main-view");
  const disableFloatingBoxTrigger = document.getElementById("disableFloatingBoxTrigger");
  const enableFloatingBoxBtn = document.getElementById("enableFloatingBoxBtn");
  const enableFloatingBoxRow = document.getElementById("enableFloatingBoxRow");

  async function updateViewVisibility() {
    const res = await storageGet([
      "userGroqApiKeys",
      "userMistralApiKeys",
      "userGeminiApiKeys",
      "disableFloatingKeyBox"
    ]);

    const hasAnyApiKeys =
      (res.userGroqApiKeys && res.userGroqApiKeys.length > 0) ||
      (res.userMistralApiKeys && res.userMistralApiKeys.length > 0) ||
      (res.userGeminiApiKeys && res.userGeminiApiKeys.length > 0);

    const isDisabled = Boolean(res.disableFloatingKeyBox);

    if (!hasAnyApiKeys && !isDisabled) {
      if (setupView) setupView.classList.remove("hidden");
      if (mainView) mainView.classList.add("hidden");
      document.body.classList.add("setup-mode");
    } else {
      if (setupView) setupView.classList.add("hidden");
      if (mainView) mainView.classList.remove("hidden");
      document.body.classList.remove("setup-mode");

      // Only show the "Enable" button if there are no API keys
      if (enableFloatingBoxRow) {
        if (hasAnyApiKeys) {
          enableFloatingBoxRow.classList.add("hidden");
        } else {
          enableFloatingBoxRow.classList.remove("hidden");
          if (enableFloatingBoxBtn) enableFloatingBoxBtn.disabled = !isDisabled;
        }
      }
    }
  }

  if (disableFloatingBoxTrigger) {
    disableFloatingBoxTrigger.addEventListener("click", async () => {
      await storageSet({ disableFloatingKeyBox: true });
      // Broadcast to all tabs to hide the box immediately
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach((tab) => {
          chrome.tabs.sendMessage(tab.id, { action: "hide_floating_key_box" }).catch(() => {});
        });
      });
      updateViewVisibility();
    });
  }

  if (enableFloatingBoxBtn) {
    enableFloatingBoxBtn.addEventListener("click", async () => {
      await storageSet({ disableFloatingKeyBox: false });
      updateViewVisibility();
    });
  }

  const clearAllKeysBtn = document.getElementById("clearAllKeysBtn");
  if (clearAllKeysBtn) {
    clearAllKeysBtn.addEventListener("click", async () => {
      const keysToClear = {
        userGroqApiKeys: [],
        userMistralApiKeys: [],
        userGeminiApiKeys: [],
        remoteUserKey: "",
        disableFloatingKeyBox: false
      };
      await storageSet(keysToClear);
      await loadSettings();
      await updateViewVisibility();
      setStatus("All keys cleared", true);
    });
  }

  await updateViewVisibility();

  function storageGet(keys) {
    try {
      const maybePromise = extApi.storage.local.get(keys);
      if (maybePromise && typeof maybePromise.then === "function") {
        return maybePromise;
      }
    } catch (_e) {
      // Fall through to callback style.
    }

    return new Promise((resolve, reject) => {
      chrome.storage.local.get(keys, (result) => {
        const runtimeError = chrome.runtime && chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }
        resolve(result);
      });
    });
  }

  function storageSet(payload) {
    try {
      const maybePromise = extApi.storage.local.set(payload);
      if (maybePromise && typeof maybePromise.then === "function") {
        return maybePromise;
      }
    } catch (_e) {
      // Fall through to callback style.
    }

    return new Promise((resolve, reject) => {
      chrome.storage.local.set(payload, () => {
        const runtimeError = chrome.runtime && chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }
        resolve();
      });
    });
  }

  function setStatus(message, ok, options = {}) {
    const autoHideMs =
      typeof options.autoHideMs === "number" ? options.autoHideMs : null;

    if (statusHideTimer) {
      clearTimeout(statusHideTimer);
      statusHideTimer = null;
    }
    settingsStatus.classList.remove("hidden", "success", "error");
    settingsStatus.classList.add(ok ? "success" : "error");
    settingsStatus.textContent = message;

    if (autoHideMs && autoHideMs > 0) {
      statusHideTimer = setTimeout(() => {
        settingsStatus.classList.add("hidden");
      }, autoHideMs);
      return;
    }

    if (ok) {
      statusHideTimer = setTimeout(() => {
        settingsStatus.classList.add("hidden");
      }, 3200);
    }
  }

  function normalizeKeyList(value) {
    const values = Array.isArray(value)
      ? value
      : typeof value === "string"
        ? value.split(/[\n,]+/)
        : [];

    return [
      ...new Set(
        values
          .map((entry) => `${entry || ""}`.trim())
          .filter((entry) => Boolean(entry)),
      ),
    ];
  }

  function sanitizeDisplayPosition(value) {
    const normalized = `${value || ""}`.trim().toLowerCase();
    if (normalized === "left" || normalized === "right") {
      return normalized;
    }
    return defaults.displayPosition;
  }

  function sanitizeFontSize(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) {
      return defaults.displayFontSize;
    }
    return Math.max(10, Math.min(80, Math.round(number)));
  }

  function sanitizeColor(value) {
    if (typeof value !== "string") {
      return defaults.displayFontColor;
    }

    const trimmed = value.trim();
    if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(trimmed)) {
      return trimmed;
    }
    return defaults.displayFontColor;
  }

  function isValidColor(value) {
    if (typeof value !== "string") {
      return false;
    }
    return /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(value.trim());
  }

  function validateColorInput() {
    const rawColor = (fontColorInput?.value || "").trim();

    if (fontColorInput) {
      fontColorInput.setCustomValidity("");
    }

    if (!rawColor) {
      return true;
    }

    if (!isValidColor(rawColor)) {
      if (fontColorInput) {
        fontColorInput.setCustomValidity("Invalid color. Use #RGB or #RRGGBB");
      }
      return false;
    }

    return true;
  }

  async function loadSettings() {
    try {
      const result = await storageGet([
        "displayFontSize",
        "displayFontColor",
        "displayPosition",
        "displayWhiteBackground",
        "displayDebugPersistentBox",
        "enableDetailedLogging",
        "userGroqApiKeys",
        "userMistralApiKeys",
        "userGeminiApiKeys",
        "userGroqApiKey",
        "userMistralApiKey",
        "userGeminiApiKey",
        "remoteUserKey",
      ]);

      userGroqApiKeysInput.value = normalizeKeyList(
        result.userGroqApiKeys ?? result.userGroqApiKey,
      ).join("\n");
      userMistralApiKeysInput.value = normalizeKeyList(
        result.userMistralApiKeys ?? result.userMistralApiKey,
      ).join("\n");
      userGeminiApiKeysInput.value = normalizeKeyList(
        result.userGeminiApiKeys ?? result.userGeminiApiKey,
      ).join("\n");
      fontSizeInput.value = sanitizeFontSize(result.displayFontSize);
      fontColorInput.value = sanitizeColor(result.displayFontColor);
      if (displayPositionSelect) {
        displayPositionSelect.value = sanitizeDisplayPosition(
          result.displayPosition,
        );
      }
      whiteBackgroundToggle.checked =
        typeof result.displayWhiteBackground === "boolean"
          ? result.displayWhiteBackground
          : defaults.displayWhiteBackground;
      debugPersistentBoxToggle.checked =
        typeof result.displayDebugPersistentBox === "boolean"
          ? result.displayDebugPersistentBox
          : defaults.displayDebugPersistentBox;
      loggingToggle.checked =
        typeof result.enableDetailedLogging === "boolean"
          ? result.enableDetailedLogging
          : defaults.enableDetailedLogging;
      if (remoteUserKeyInput) {
        remoteUserKeyInput.value = result.remoteUserKey || "";
      }
    } catch (error) {
      setStatus(`Failed loading settings: ${error.message}`, false);
    }
  }

  async function saveSettings() {
    const userGroqApiKeys = normalizeKeyList(userGroqApiKeysInput.value);
    const userMistralApiKeys = normalizeKeyList(userMistralApiKeysInput.value);
    const userGeminiApiKeys = normalizeKeyList(userGeminiApiKeysInput.value);

    const payload = {
      userGroqApiKeys,
      userMistralApiKeys,
      userGeminiApiKeys,
      userGroqApiKey: userGroqApiKeys[0] || "",
      userMistralApiKey: userMistralApiKeys[0] || "",
      userGeminiApiKey: userGeminiApiKeys[0] || "",
      displayFontSize: sanitizeFontSize(fontSizeInput.value),
      displayFontColor: sanitizeColor(fontColorInput.value),
      displayPosition: sanitizeDisplayPosition(displayPositionSelect?.value),
      displayWhiteBackground: Boolean(whiteBackgroundToggle.checked),
      displayDebugPersistentBox: Boolean(debugPersistentBoxToggle.checked),
      enableDetailedLogging: Boolean(loggingToggle.checked),
    };

    const remoteKey = (remoteUserKeyInput?.value || "").trim();
    if (remoteKey === "") {
      payload.remoteUserKey = "";
    }

    userGroqApiKeysInput.value = userGroqApiKeys.join("\n");
    userMistralApiKeysInput.value = userMistralApiKeys.join("\n");
    userGeminiApiKeysInput.value = userGeminiApiKeys.join("\n");

    try {
      await storageSet(payload);
    } catch (error) {
      setStatus(`Failed saving settings: ${error.message}`, false);
    }
  }

  async function saveSettingsNow() {
    if (autoSaveTimer) {
      clearTimeout(autoSaveTimer);
      autoSaveTimer = null;
    }
    await saveSettings();
  }

  function scheduleAutoSave() {
    if (autoSaveTimer) {
      clearTimeout(autoSaveTimer);
    }
    autoSaveTimer = setTimeout(() => {
      saveSettings();
      autoSaveTimer = null;
    }, 250);
  }

  function getCurrentDisplaySettingsPayload() {
    return {
      fontSize: sanitizeFontSize(fontSizeInput.value),
      fontColor: sanitizeColor(fontColorInput.value),
      displayPosition: sanitizeDisplayPosition(displayPositionSelect?.value),
      whiteBackground: Boolean(whiteBackgroundToggle.checked),
      debugPersistentBox: Boolean(debugPersistentBoxToggle.checked),
    };
  }

  async function sendDisplaySettingsPreviewToActiveTab() {
    let tabs;
    try {
      const maybePromise = extApi.tabs.query({
        active: true,
        currentWindow: true,
      });
      tabs =
        maybePromise && typeof maybePromise.then === "function"
          ? await maybePromise
          : await new Promise((resolve) => {
              chrome.tabs.query(
                {
                  active: true,
                  currentWindow: true,
                },
                (result) => resolve(result || []),
              );
            });
    } catch (_error) {
      return;
    }

    const activeTab = Array.isArray(tabs) && tabs.length ? tabs[0] : null;
    const tabId = activeTab && activeTab.id;
    if (typeof tabId !== "number") {
      return;
    }

    const payload = {
      action: "debug_preview_settings",
      displaySettings: getCurrentDisplaySettingsPayload(),
    };

    try {
      const maybePromise = extApi.tabs.sendMessage(tabId, payload);
      if (maybePromise && typeof maybePromise.then === "function") {
        await maybePromise;
      }
    } catch (_error) {
      // No content script on this tab (e.g., browser internal pages).
    }
  }

  async function importSettingsFromFile(file) {
    const text = await file.text();
    const imported = parseImportedConfig(text, file.name);

    applyImportedToInputs(imported);

    await saveSettings();
    setStatus(`Imported ${file.name}`, true);
  }

  async function commitFontSizeAndSave() {
    if (!fontSizeInput) {
      return;
    }
    fontSizeInput.value = sanitizeFontSize(fontSizeInput.value);
    await saveSettingsNow();
  }

  async function commitColorAndSave() {
    if (!fontColorInput) {
      return;
    }

    const raw = (fontColorInput.value || "").trim();
    const valid = !raw || isValidColor(raw);
    const sanitized = sanitizeColor(raw);

    fontColorInput.value = sanitized;
    fontColorInput.setCustomValidity("");

    if (!valid) {
      setStatus(`Invalid color. Reset to ${sanitized}`, false, {
        autoHideMs: 2800,
      });
      setTimeout(() => {
        settingsStatus.classList.add("hidden");
      }, 2850);
    }

    await saveSettingsNow();
  }

  async function importSettingsFromRemote() {
    const userKey = (remoteUserKeyInput?.value || "").trim();
    if (!userKey) {
      await storageSet({ remoteUserKey: "" });
      await updateViewVisibility();
      setStatus("Remote key cleared", true);
      return;
    }

    if (!userKey.includes(":")) {
      await storageSet({ remoteUserKey: "" }); // Clear on invalid format too
      if (remoteUserKeyInput) remoteUserKeyInput.value = "";
      await updateViewVisibility();
      throw new Error("Use user:key format");
    }

    setStatus("Importing...", true);

    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { action: "import_remote_user_key", userKey },
        async (response) => {
          if (response && response.success) {
            // Success: reload inputs from the now-updated storage
            loadSettings().then(() => {
              setStatus(`Imported remote settings for ${response.user}`, true);
              resolve();
            });
          } else {
            const errorMsg = response ? response.error : "No response from background";
            setStatus(`Failed: ${errorMsg}`, false);
            if (remoteUserKeyInput) remoteUserKeyInput.value = ""; 
            await storageSet({ remoteUserKey: "" }); // Clear on failure
            await updateViewVisibility();
            reject(new Error(errorMsg));
          }
        }
      );
    });
  }

  async function updateSystemInfo() {
    try {
      const result = await storageGet(["lastProvider", "lastProviderSource"]);

      if (result.lastProviderSource) {
        lastProviderDisplay.textContent = `${result.lastProviderSource}`;
      } else if (result.lastProvider) {
        lastProviderDisplay.textContent = result.lastProvider;
      } else {
        lastProviderDisplay.textContent = "N/A";
      }
    } catch (error) {
      lastProviderDisplay.textContent = "Error";
    }
  }

  await loadSettings();

  // Single dropdown toggle
  const dropdownToggle = document.getElementById("dropdownToggle");
  const settingsDropdown = document.getElementById("settingsDropdown");
  if (dropdownToggle && settingsDropdown) {
    dropdownToggle.addEventListener("click", () => {
      settingsDropdown.classList.toggle("open");
      document.body.classList.toggle("expanded");
    });
  }

  if (fontSizeInput) {
    fontSizeInput.addEventListener("change", commitFontSizeAndSave);
    fontSizeInput.addEventListener("blur", commitFontSizeAndSave);
    fontSizeInput.addEventListener("keydown", (event) => {
      if (event.key !== "Enter") {
        return;
      }
      event.preventDefault();
      commitFontSizeAndSave();
      fontSizeInput.blur();
    });
  }
  if (fontColorInput) {
    fontColorInput.addEventListener("change", commitColorAndSave);
    fontColorInput.addEventListener("blur", commitColorAndSave);
    fontColorInput.addEventListener("keydown", (event) => {
      if (event.key !== "Enter") {
        return;
      }
      event.preventDefault();
      commitColorAndSave();
      fontColorInput.blur();
    });
  }
  if (displayPositionSelect) {
    displayPositionSelect.addEventListener("change", async () => {
      await saveSettingsNow();
      await sendDisplaySettingsPreviewToActiveTab();
    });
  }
  if (loggingToggle) {
    loggingToggle.addEventListener("change", scheduleAutoSave);
  }
  if (whiteBackgroundToggle) {
    whiteBackgroundToggle.addEventListener("change", scheduleAutoSave);
  }
  if (debugPersistentBoxToggle) {
    debugPersistentBoxToggle.addEventListener("change", async () => {
      await saveSettingsNow();
      await sendDisplaySettingsPreviewToActiveTab();
    });
  }
  if (userGroqApiKeysInput) {
    userGroqApiKeysInput.addEventListener("input", scheduleAutoSave);
    userGroqApiKeysInput.addEventListener("blur", saveSettingsNow);
  }
  if (userMistralApiKeysInput) {
    userMistralApiKeysInput.addEventListener("input", scheduleAutoSave);
    userMistralApiKeysInput.addEventListener("blur", saveSettingsNow);
  }
  if (userGeminiApiKeysInput) {
    userGeminiApiKeysInput.addEventListener("input", scheduleAutoSave);
    userGeminiApiKeysInput.addEventListener("blur", saveSettingsNow);
  }
  if (remoteUserKeyInput) {
    remoteUserKeyInput.addEventListener("input", scheduleAutoSave);
    remoteUserKeyInput.addEventListener("keydown", async (event) => {
      if (event.key !== "Enter") {
        return;
      }
      event.preventDefault();
      remoteUserKeyInput.blur();
      try {
        await importSettingsFromRemote();
      } catch (error) {
        setStatus(`Failed remote import: ${error.message}`, false);
      }
    });
    remoteUserKeyInput.addEventListener("blur", async () => {
      const val = (remoteUserKeyInput.value || "").trim();
      if (val && val.includes(":")) {
        await saveSettingsNow();
        try {
          await importSettingsFromRemote();
        } catch (error) {
          setStatus(`Failed remote import: ${error.message}`, false);
        }
      } else {
        await saveSettingsNow();
      }
    });
  }

  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") {
      saveSettingsNow();
    }
  });

  if (configFileInput) {
    configFileInput.addEventListener("change", async () => {
      const file = configFileInput.files && configFileInput.files[0];
      if (!file) {
        return;
      }

      try {
        await importSettingsFromFile(file);
      } catch (error) {
        setStatus(`Failed importing file: ${error.message}`, false);
      } finally {
        configFileInput.value = "";
      }
    });
  }

  updateSystemInfo();
  setInterval(updateSystemInfo, 30000);
});
