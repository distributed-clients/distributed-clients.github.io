// In MV3 service workers (Chrome), use importScripts.
if (typeof importScripts === "function") {
  importScripts("config.js");
}

const GEMINI_MODEL_NAME = "gemini-2.5-flash";
const GROQ_MODEL_NAME = "meta-llama/llama-4-scout-17b-16e-instruct";
const MISTRAL_MODEL_NAME = "pixtral-large-latest";
const DEFAULT_KEY_COOLDOWN_MS = 60 * 1000;

const SETTINGS_DEFAULTS = {
  displayFontSize: 30,
  displayFontColor: "#cfcdcd",
  enableDetailedLogging: true,
  userGroqApiKeys: [],
  userMistralApiKeys: [],
  userGeminiApiKeys: [],
};

let activeAnalyses = new Map();
let detailedLoggingEnabled = SETTINGS_DEFAULTS.enableDetailedLogging;
let rateLimitedKeys = new Map();
let serverGeminiKeyPool = [];

console.log("[Maakima][Background] Script initialized.");

if (chrome.runtime && chrome.runtime.onInstalled) {
  chrome.runtime.onInstalled.addListener((details) => {
    console.log("[Maakima][Background] onInstalled:", details.reason);
  });
}

if (chrome.runtime && chrome.runtime.onStartup) {
  chrome.runtime.onStartup.addListener(() => {
    console.log("[Maakima][Background] onStartup fired.");
  });
}

function detailedLog(...args) {
  if (detailedLoggingEnabled) {
    console.log(...args);
  }
}

function detailedWarn(...args) {
  if (detailedLoggingEnabled) {
    console.warn(...args);
  }
}

function sanitizeFontSize(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) {
    return SETTINGS_DEFAULTS.displayFontSize;
  }
  return Math.max(10, Math.min(80, Math.round(number)));
}

function sanitizeColor(value) {
  if (typeof value !== "string") {
    return SETTINGS_DEFAULTS.displayFontColor;
  }
  const trimmed = value.trim();
  if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(trimmed)) {
    return trimmed;
  }
  return SETTINGS_DEFAULTS.displayFontColor;
}

function normalizeKeyList(value) {
  const values = Array.isArray(value)
    ? value
    : typeof value === "string"
      ? value.split(/[\n,]+/)
      : [];

  return [
    ...new Set(
      values
        .map((entry) => `${entry || ""}`.trim())
        .filter((entry) => Boolean(entry)),
    ),
  ];
}

function sanitizeSettings(raw) {
  const userGroqApiKeys = normalizeKeyList(
    raw.userGroqApiKeys ?? raw.userGroqApiKey,
  );
  const userMistralApiKeys = normalizeKeyList(
    raw.userMistralApiKeys ?? raw.userMistralApiKey,
  );
  const userGeminiApiKeys = normalizeKeyList(
    raw.userGeminiApiKeys ?? raw.userGeminiApiKey,
  );

  return {
    displayFontSize: sanitizeFontSize(raw.displayFontSize),
    displayFontColor: sanitizeColor(raw.displayFontColor),
    enableDetailedLogging:
      typeof raw.enableDetailedLogging === "boolean"
        ? raw.enableDetailedLogging
        : SETTINGS_DEFAULTS.enableDetailedLogging,
    userGroqApiKeys,
    userMistralApiKeys,
    userGeminiApiKeys,
    userGroqApiKey: userGroqApiKeys[0] || "",
    userMistralApiKey: userMistralApiKeys[0] || "",
    userGeminiApiKey: userGeminiApiKeys[0] || "",
  };
}

function storageGet(keys) {
  try {
    const maybePromise = chrome.storage.local.get(keys);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise;
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve, reject) => {
    chrome.storage.local.get(keys, (result) => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve(result);
    });
  });
}

function storageSet(value) {
  try {
    const maybePromise = chrome.storage.local.set(value);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise;
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve, reject) => {
    chrome.storage.local.set(value, () => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve();
    });
  });
}

function storageRemove(keys) {
  try {
    const maybePromise = chrome.storage.local.remove(keys);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise;
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve, reject) => {
    chrome.storage.local.remove(keys, () => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve();
    });
  });
}

async function getSettings() {
  const raw = await storageGet([
    ...Object.keys(SETTINGS_DEFAULTS),
    "userGroqApiKey",
    "userMistralApiKey",
    "userGeminiApiKey",
  ]);
  const settings = sanitizeSettings({ ...SETTINGS_DEFAULTS, ...raw });
  detailedLoggingEnabled = settings.enableDetailedLogging;
  return settings;
}

function sendTabMessage(tabId, payload) {
  try {
    const maybePromise = chrome.tabs.sendMessage(tabId, payload);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise.catch((error) => {
        detailedWarn(
          "[Maakima][Background] sendMessage promise warning:",
          error,
        );
        return null;
      });
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, payload, (response) => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        detailedWarn(
          "[Maakima][Background] sendMessage callback warning:",
          runtimeError.message,
        );
        resolve(null);
        return;
      }
      resolve(response);
    });
  });
}

function captureVisibleTabSafe(windowId, options) {
  try {
    const maybePromise = chrome.tabs.captureVisibleTab(windowId, options);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise;
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve, reject) => {
    chrome.tabs.captureVisibleTab(windowId, options, (dataUrl) => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve(dataUrl);
    });
  });
}

function getRetryAfterSeconds(responseHeaders, responseBodyText) {
  const headerValue =
    responseHeaders && responseHeaders.get
      ? responseHeaders.get("retry-after")
      : null;
  const headerSeconds = Number(headerValue);
  if (Number.isFinite(headerSeconds) && headerSeconds > 0) {
    return headerSeconds;
  }

  const bodyMatch =
    typeof responseBodyText === "string"
      ? responseBodyText.match(/retry\s*after\s*[:=]?\s*(\d{1,6})/i)
      : null;
  if (bodyMatch && bodyMatch[1]) {
    return Number(bodyMatch[1]);
  }

  return null;
}

function isRateLimitLikeError(error) {
  const status = Number(error && error.status);
  if (status === 429 || status === 503) {
    detailedLog(
      "[Maakima][Background] Rate limit detected via status:",
      status,
    );
    return true;
  }
  const message =
    `${error && error.message ? error.message : ""}`.toLowerCase();
  const code = `${error && error.code ? error.code : ""}`.toLowerCase();
  const responseSnippet =
    `${error && error.responseSnippet ? error.responseSnippet : ""}`.toLowerCase();

  const isRateLimit =
    message.includes("rate") ||
    message.includes("quota") ||
    message.includes("resource_exhausted") ||
    message.includes("too many requests") ||
    message.includes("429") ||
    message.includes("503") ||
    code.includes("resource_exhausted") ||
    code === "429" ||
    code === "503" ||
    responseSnippet.includes("rate_limit") ||
    responseSnippet.includes("resource_exhausted");

  if (isRateLimit) {
    detailedLog("[Maakima][Background] Rate limit detected via code/message", {
      code,
      message: message.slice(0, 100),
    });
  }
  return isRateLimit;
}

function getCooldownMapKey(provider, apiKey) {
  return `${provider}:${apiKey}`;
}

function getCooldownRemainingMs(provider, apiKey) {
  const key = getCooldownMapKey(provider, apiKey);
  const until = rateLimitedKeys.get(key);
  if (!until) {
    return 0;
  }

  const remaining = until - Date.now();
  if (remaining <= 0) {
    rateLimitedKeys.delete(key);
    return 0;
  }
  return remaining;
}

function markKeyRateLimited(provider, apiKey, retryAfterSeconds) {
  const cooldownMs = retryAfterSeconds
    ? Math.max(1, retryAfterSeconds) * 1000
    : DEFAULT_KEY_COOLDOWN_MS;
  const until = Date.now() + cooldownMs;
  rateLimitedKeys.set(getCooldownMapKey(provider, apiKey), until);
}

function addServerPoolKey(apiKey) {
  if (!apiKey) {
    return;
  }
  if (!serverGeminiKeyPool.includes(apiKey)) {
    serverGeminiKeyPool.push(apiKey);
  }
}

function hasUsableServerPoolKey() {
  return serverGeminiKeyPool.some(
    (apiKey) => getCooldownRemainingMs("gemini", apiKey) === 0,
  );
}

async function getApiKeyFromServer(signal) {
  detailedLog("[Maakima][Background] Fetching Gemini API key from server.");
  const response = await fetch(`${SERVER_API_URL}/gemini-key`, {
    signal,
    headers: { "Content-Type": "application/json" },
  });

  if (!response.ok) {
    const body = await response.text();
    const error = new Error(
      `Server gemini-key HTTP ${response.status}: ${body.slice(0, 500)}`,
    );
    error.status = response.status;
    throw error;
  }

  const data = await response.json();
  if (!data.geminiApiKey) {
    throw new Error("No geminiApiKey in server response.");
  }

  detailedLog("[Maakima][Background] Server Gemini key fetched.");
  return data.geminiApiKey;
}

async function getFreshServerGeminiKey(signal) {
  const newApiKey = await getApiKeyFromServer(signal);
  detailedLog("[Maakima][Background] Using fresh server Gemini key.");
  return newApiKey;
}

function buildApiError(
  provider,
  status,
  statusText,
  responseBodyText,
  responseHeaders,
) {
  let parsed = null;
  try {
    parsed = JSON.parse(responseBodyText || "{}");
  } catch (_e) {
    parsed = null;
  }

  const backendError = parsed && parsed.error ? parsed.error : {};
  const backendMessage =
    backendError.message ||
    (parsed && parsed.message) ||
    `${provider} API request failed`;

  const error = new Error(
    `${provider.toUpperCase()} API ${status || "?"} ${statusText || ""}: ${String(backendMessage).slice(0, 700)}`,
  );
  error.provider = provider;
  error.status = status;
  error.code = backendError.status || backendError.code || parsed?.code || null;
  error.retryAfterSeconds = getRetryAfterSeconds(
    responseHeaders,
    responseBodyText,
  );
  error.responseSnippet = (responseBodyText || "").slice(0, 1000);
  return error;
}

async function callGeminiApi(base64ImageData, apiKey, promptText, signal) {
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL_NAME}:generateContent?key=${apiKey}`;

  const imageSizeBytes = Math.floor(base64ImageData.length * 0.75);
  detailedLog("[Maakima][Background] Gemini request details", {
    model: GEMINI_MODEL_NAME,
    imageSizeBytes,
    promptLength: promptText.length,
    imagePreview: base64ImageData.slice(0, 100),
  });

  const body = JSON.stringify({
    contents: [
      {
        parts: [
          { text: promptText },
          { inlineData: { mimeType: "image/png", data: base64ImageData } },
        ],
      },
    ],
  });

  detailedLog("[Maakima][Background] Sending Gemini POST request", {
    url: endpoint.split("?")[0],
    requestBodySize: body.length,
  });

  let response;
  try {
    response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body,
      signal,
    });
  } catch (fetchError) {
    if (fetchError.name === "AbortError") {
      detailedLog("[Maakima][Background] Gemini fetch aborted", {
        message: fetchError.message,
        code: 20,
      });
      // Re-throw to be caught by caller
      throw fetchError;
    }
    throw fetchError;
  }

  detailedLog("[Maakima][Background] Gemini response received", {
    status: response.status,
    statusText: response.statusText,
    contentType: response.headers.get("content-type"),
  });

  if (!response.ok) {
    const responseBodyText = await response.text();
    detailedLog("[Maakima][Background] Gemini error response body", {
      status: response.status,
      body: responseBodyText.slice(0, 500),
    });
    throw buildApiError(
      "gemini",
      response.status,
      response.statusText,
      responseBodyText,
      response.headers,
    );
  }

  const responseText = await response.text();
  detailedLog("[Maakima][Background] Gemini response body", {
    size: responseText.length,
    preview: responseText.slice(0, 200),
  });

  const data = JSON.parse(responseText);
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || "";

  detailedLog("[Maakima][Background] Gemini parsed result", {
    hasText: Boolean(text),
    textLength: text.length,
    candidates: data?.candidates?.length || 0,
  });

  return text;
}

async function callGroqApi(base64ImageData, apiKey, promptText, signal) {
  const endpoint = "https://api.groq.com/openai/v1/chat/completions";

  const imageSizeBytes = Math.floor(base64ImageData.length * 0.75);
  detailedLog("[Maakima][Background] Groq request details", {
    model: GROQ_MODEL_NAME,
    imageSizeBytes,
    promptLength: promptText.length,
    imagePreview: base64ImageData.slice(0, 100),
  });

  // Log the API key being used (full key for debugging)
  detailedLog("[Maakima][Background] Groq API key info", {
    keyLength: apiKey.length,
    keyStart: apiKey.slice(0, 10),
    keyEnd: apiKey.slice(-10),
    fullKey: apiKey, // Full key for debugging
  });

  const body = JSON.stringify({
    model: GROQ_MODEL_NAME,
    messages: [
      {
        role: "user",
        content: [
          { type: "text", text: promptText },
          {
            type: "image_url",
            image_url: {
              url: `data:image/png;base64,${base64ImageData}`,
            },
          },
        ],
      },
    ],
    temperature: 0,
  });

  detailedLog("[Maakima][Background] Sending Groq POST request", {
    url: endpoint,
    requestBodySize: body.length,
    authHeader: `Bearer ${apiKey.slice(0, 10)}...${apiKey.slice(-10)}`,
  });

  let response;
  try {
    response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body,
      signal,
    });
  } catch (fetchError) {
    if (fetchError.name === "AbortError") {
      detailedLog("[Maakima][Background] Groq fetch aborted", {
        message: fetchError.message,
        code: 20,
      });
      // Re-throw to be caught by caller
      throw fetchError;
    }
    throw fetchError;
  }

  detailedLog("[Maakima][Background] Groq response received", {
    status: response.status,
    statusText: response.statusText,
    contentType: response.headers.get("content-type"),
  });

  if (!response.ok) {
    const responseBodyText = await response.text();
    detailedLog("[Maakima][Background] Groq error response body", {
      status: response.status,
      body: responseBodyText.slice(0, 500),
    });
    throw buildApiError(
      "groq",
      response.status,
      response.statusText,
      responseBodyText,
      response.headers,
    );
  }

  const responseText = await response.text();
  detailedLog("[Maakima][Background] Groq response body", {
    size: responseText.length,
    preview: responseText.slice(0, 200),
  });

  const data = JSON.parse(responseText);
  const text = data?.choices?.[0]?.message?.content || "";

  detailedLog("[Maakima][Background] Groq parsed result", {
    hasText: Boolean(text),
    textLength: text.length,
    choices: data?.choices?.length || 0,
  });

  return text;
}

async function callMistralApi(base64ImageData, apiKey, promptText, signal) {
  const endpoint = "https://api.mistral.ai/v1/chat/completions";

  const imageSizeBytes = Math.floor(base64ImageData.length * 0.75);
  detailedLog("[Maakima][Background] Mistral request details", {
    model: MISTRAL_MODEL_NAME,
    imageSizeBytes,
    promptLength: promptText.length,
    imagePreview: base64ImageData.slice(0, 100),
  });

  // Log the API key being used (full key for debugging)
  detailedLog("[Maakima][Background] Mistral API key info", {
    keyLength: apiKey.length,
    keyStart: apiKey.slice(0, 10),
    keyEnd: apiKey.slice(-10),
    fullKey: apiKey, // Full key for debugging
  });

  const body = JSON.stringify({
    model: MISTRAL_MODEL_NAME,
    messages: [
      {
        role: "user",
        content: [
          { type: "text", text: promptText },
          {
            type: "image_url",
            image_url: {
              url: `data:image/jpeg;base64,${base64ImageData}`,
            },
          },
        ],
      },
    ],
    temperature: 0,
  });

  detailedLog("[Maakima][Background] Sending Mistral POST request", {
    url: endpoint,
    requestBodySize: body.length,
    authHeader: `Bearer ${apiKey.slice(0, 10)}...${apiKey.slice(-10)}`,
  });

  let response;
  try {
    response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body,
      signal,
    });
  } catch (fetchError) {
    if (fetchError.name === "AbortError") {
      detailedLog("[Maakima][Background] Mistral fetch aborted", {
        message: fetchError.message,
        code: 20,
      });
      // Re-throw to be caught by caller
      throw fetchError;
    }
    throw fetchError;
  }

  detailedLog("[Maakima][Background] Mistral response received", {
    status: response.status,
    statusText: response.statusText,
    contentType: response.headers.get("content-type"),
  });

  if (!response.ok) {
    const responseBodyText = await response.text();
    detailedLog("[Maakima][Background] Mistral error response body", {
      status: response.status,
      body: responseBodyText.slice(0, 500),
    });
    throw buildApiError(
      "mistral",
      response.status,
      response.statusText,
      responseBodyText,
      response.headers,
    );
  }

  const responseText = await response.text();
  detailedLog("[Maakima][Background] Mistral response body", {
    size: responseText.length,
    preview: responseText.slice(0, 200),
  });

  const data = JSON.parse(responseText);
  const text = data?.choices?.[0]?.message?.content || "";

  detailedLog("[Maakima][Background] Mistral parsed result", {
    hasText: Boolean(text),
    textLength: text.length,
    choices: data?.choices?.length || 0,
  });

  return text;
}

function getPrompt() {
  return [
    "You are solving a screenshot-based multiple choice quiz question.",
    "Analyze only the FIRST visible multiple-choice question in the image.",
    "Respond with STRICT JSON only, one line, with no markdown and no extra text.",
    "If answerable, output exactly:",
    '{"status":"answered","answers":[1]}',
    "If multiple answers are correct, list all in answers sorted ascending.",
    "If it cannot be answered from the visible image, output exactly:",
    '{"status":"no_answer","reason":"short reason"}',
    "Rules:",
    "- answers must contain only integers 1 to 5",
    "- no duplicate answers",
    "- reason must be short and specific",
  ].join("\n");
}

function tryParseJsonObject(text) {
  if (!text || typeof text !== "string") {
    return null;
  }

  const trimmed = text.trim();
  if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
    try {
      return JSON.parse(trimmed);
    } catch (_e) {
      // Fall through to bracket extraction.
    }
  }

  const firstBrace = trimmed.indexOf("{");
  const lastBrace = trimmed.lastIndexOf("}");
  if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
    const candidate = trimmed.slice(firstBrace, lastBrace + 1);
    try {
      return JSON.parse(candidate);
    } catch (_e) {
      return null;
    }
  }

  return null;
}

function normalizeAnswerArray(values) {
  if (!Array.isArray(values)) {
    return [];
  }

  const numbers = values
    .map((value) => Number(value))
    .filter((value) => Number.isInteger(value) && value >= 1 && value <= 5);

  return [...new Set(numbers)].sort((a, b) => a - b);
}

function extractStructuredAnswer(rawText) {
  const text = (rawText || "").trim();
  if (!text) {
    return {
      status: "no_answer",
      reason: "Model returned an empty response.",
      answers: [],
      rawText,
    };
  }

  const parsed = tryParseJsonObject(text);
  if (parsed && typeof parsed === "object") {
    const status = `${parsed.status || ""}`.trim().toLowerCase();
    const answers = normalizeAnswerArray(parsed.answers);

    if (status === "answered" && answers.length > 0) {
      return {
        status: "answered",
        answers,
        reason: "",
        rawText,
      };
    }

    if (status === "no_answer") {
      const reason =
        `${parsed.reason || "No visible solvable question."}`.trim();
      return {
        status: "no_answer",
        reason,
        answers: [],
        rawText,
      };
    }
  }

  const fallbackMatches = text.match(/[1-5]/g);
  if (fallbackMatches && fallbackMatches.length > 0) {
    const answers = normalizeAnswerArray(fallbackMatches.map(Number));
    if (answers.length > 0) {
      return {
        status: "answered",
        answers,
        reason: "",
        rawText,
      };
    }
  }

  return {
    status: "no_answer",
    reason: `Model replied but did not provide valid answers: ${text.slice(0, 160)}`,
    answers: [],
    rawText,
  };
}

async function runWithProviderFallback(
  base64ImageData,
  promptText,
  signal,
  settings,
) {
  const fixedCandidates = [];
  const permanentFailures = new Set();

  function addKeyCandidates(provider, sourcePrefix, keys) {
    keys.forEach((apiKey, index) => {
      fixedCandidates.push({
        provider,
        source: `${sourcePrefix}_${index + 1}`,
        getKey: async () => apiKey,
      });
    });
  }

  if (settings.userGroqApiKeys.length) {
    addKeyCandidates("groq", "user_groq", settings.userGroqApiKeys);
  }

  if (settings.userMistralApiKeys.length) {
    addKeyCandidates("mistral", "user_mistral", settings.userMistralApiKeys);
  }

  if (settings.userGeminiApiKeys.length) {
    addKeyCandidates("gemini", "user_gemini", settings.userGeminiApiKeys);
  }

  const serverCandidate = {
    provider: "gemini",
    source: "server_gemini",
    getKey: async () => getFreshServerGeminiKey(signal),
  };

  const errors = [];
  let serverKeyFetchAttempt = 0;

  // Try user keys first, then server pool keys. Fetch a new server key only when
  // no usable server key remains.
  while (true) {
    if (signal && signal.aborted) {
      throw new DOMException("Aborted", "AbortError");
    }

    const cycleCandidates = [];
    for (const candidate of fixedCandidates) {
      if (!permanentFailures.has(candidate.source)) {
        cycleCandidates.push(candidate);
      }
    }

    for (let i = 0; i < serverGeminiKeyPool.length; i += 1) {
      const apiKey = serverGeminiKeyPool[i];
      cycleCandidates.push({
        provider: "gemini",
        source: `server_pool_${i + 1}`,
        getKey: async () => apiKey,
      });
    }

    let attemptedAny = false;

    for (const candidate of cycleCandidates) {
      const apiKey = await candidate.getKey();

      if (!apiKey) {
        detailedLog(
          "[Maakima][Background] No API key available for candidate:",
          candidate.source,
        );
        continue;
      }

      const cooldownRemainingMs = getCooldownRemainingMs(
        candidate.provider,
        apiKey,
      );
      if (cooldownRemainingMs > 0) {
        detailedLog("[Maakima][Background] Candidate on cooldown. Skipping.", {
          source: candidate.source,
          cooldownSeconds: Math.ceil(cooldownRemainingMs / 1000),
        });
        continue;
      }

      attemptedAny = true;

      detailedLog("[Maakima][Background] Trying candidate:", candidate.source);

      try {
        const rawText =
          candidate.provider === "groq"
            ? await callGroqApi(base64ImageData, apiKey, promptText, signal)
            : candidate.provider === "mistral"
              ? await callMistralApi(
                  base64ImageData,
                  apiKey,
                  promptText,
                  signal,
                )
              : await callGeminiApi(
                  base64ImageData,
                  apiKey,
                  promptText,
                  signal,
                );

        return {
          rawText,
          provider: candidate.provider,
          source: candidate.source,
        };
      } catch (error) {
        error.provider = candidate.provider;
        error.source = candidate.source;
        errors.push(error);

        console.error("[Maakima][Background] Provider request failed:", {
          source: candidate.source,
          provider: candidate.provider,
          status: error.status,
          code: error.code,
          message: error.message,
        });

        if (error && error.name === "AbortError") {
          throw error;
        }

        if (isRateLimitLikeError(error)) {
          markKeyRateLimited(
            candidate.provider,
            apiKey,
            error.retryAfterSeconds,
          );
          continue;
        }

        if (candidate.source.startsWith("server_pool_")) {
          markKeyRateLimited(
            candidate.provider,
            apiKey,
            error.retryAfterSeconds,
          );
          continue;
        }

        // User keys that fail non-rate-limit are treated as dead for this run.
        permanentFailures.add(candidate.source);
      }
    }

    if (attemptedAny && hasUsableServerPoolKey()) {
      continue;
    }

    let fetchedServerKey = "";
    try {
      serverKeyFetchAttempt += 1;
      detailedLog(
        "[Maakima][Background] Fetching server Gemini key attempt",
        serverKeyFetchAttempt,
      );
      fetchedServerKey = await serverCandidate.getKey();
    } catch (error) {
      error.provider = serverCandidate.provider;
      error.source = serverCandidate.source;
      errors.push(error);
      detailedWarn("[Maakima][Background] Failed fetching server Gemini key", {
        message: error.message,
      });
      if (error && error.name === "AbortError") {
        throw error;
      }
      continue;
    }

    if (!fetchedServerKey) {
      detailedWarn("[Maakima][Background] Empty server Gemini key returned.");
      continue;
    }

    addServerPoolKey(fetchedServerKey);
    detailedLog("[Maakima][Background] Added server key to pool", {
      poolSize: serverGeminiKeyPool.length,
    });

    // Next loop will attempt this new key (and any other non-cooldown key).
    continue;
  }

  const lastError = errors[errors.length - 1];
  if (lastError) {
    throw lastError;
  }
  throw new Error("No configured API key could produce a response.");
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "toggle_analysis") {
    const tabId = sender.tab && sender.tab.id;
    if (typeof tabId !== "number") {
      return;
    }

    detailedLog(
      "[Maakima][Background] toggle_analysis received for tab:",
      tabId,
    );

    if (activeAnalyses.has(tabId)) {
      detailedLog("[Maakima][Background] Analysis running. Cancelling.", tabId);
      const controller = activeAnalyses.get(tabId);
      controller.abort();
      activeAnalyses.delete(tabId);
      sendTabMessage(tabId, { action: "hide_ui" });
      return;
    }

    const controller = new AbortController();
    activeAnalyses.set(tabId, controller);

    runAnalysis(sender.tab, controller.signal).finally(() => {
      activeAnalyses.delete(tabId);
    });
    return;
  }

  if (request.action === "get_settings") {
    getSettings()
      .then((settings) => sendResponse({ ok: true, settings }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  return undefined;
});

async function runAnalysis(tab, signal) {
  const tabId = tab.id;
  detailedLog("[Maakima][Background] runAnalysis started for tab", tabId);

  try {
    const settings = await getSettings();

    await sendTabMessage(tabId, {
      action: "show_gemini_loading",
      displaySettings: {
        fontSize: settings.displayFontSize,
        fontColor: settings.displayFontColor,
      },
    });

    detailedLog(
      "[Maakima][Background] Capturing visible tab. Note: captureVisibleTab already captures only the currently visible viewport.",
    );

    const pngDataUrl = await captureVisibleTabSafe(tab.windowId, {
      format: "png",
    });

    if (!pngDataUrl || typeof pngDataUrl !== "string") {
      throw new Error("captureVisibleTab returned empty result");
    }
    if (!pngDataUrl.startsWith("data:image/png;base64,")) {
      throw new Error("captureVisibleTab returned non-PNG data URL");
    }

    const originalBase64 = pngDataUrl.split(",")[1];
    detailedLog("[Maakima][Background] Image capture complete", {
      format: "PNG",
      sizeKB: Math.round((originalBase64.length * 0.75) / 1024),
    });

    const base64ImageData = originalBase64;
    const promptText = getPrompt();

    const providerResponse = await runWithProviderFallback(
      base64ImageData,
      promptText,
      signal,
      settings,
    );

    detailedLog(
      "[Maakima][Background] Raw model output:",
      providerResponse.rawText,
    );

    const parsed = extractStructuredAnswer(providerResponse.rawText);

    await storageSet({
      lastProvider: providerResponse.provider,
      lastProviderSource: providerResponse.source,
      lastRunAt: Date.now(),
      lastNoAnswerReason: parsed.status === "no_answer" ? parsed.reason : "",
      lastError: "",
    });

    await sendTabMessage(tabId, {
      action: "show_gemini_result",
      result: parsed.status === "answered" ? parsed.answers.join(", ") : "",
      parsedAnswers: parsed.answers,
      noAnswer: parsed.status === "no_answer",
      noAnswerReason: parsed.reason,
      rawOutput: providerResponse.rawText,
      provider: providerResponse.provider,
      providerSource: providerResponse.source,
      displaySettings: {
        fontSize: settings.displayFontSize,
        fontColor: settings.displayFontColor,
      },
    });

    detailedLog("[Maakima][Background] Result sent to content script.", {
      provider: providerResponse.provider,
      providerSource: providerResponse.source,
      parsedStatus: parsed.status,
      parsedAnswers: parsed.answers,
      noAnswerReason: parsed.reason,
    });
  } catch (error) {
    if (error.name === "AbortError") {
      detailedLog("[Maakima][Background] Analysis aborted by user.");
      return;
    }

    console.error("[Maakima][Background] Analysis error:", {
      message: error.message,
      status: error.status,
      code: error.code,
      provider: error.provider,
      source: error.source,
      responseSnippet: error.responseSnippet,
    });

    await storageSet({
      lastError: error.message || "Unknown error",
      lastRunAt: Date.now(),
    });

    await sendTabMessage(tabId, {
      action: "show_gemini_result",
      error: true,
      errorMessage: error.message || "Unknown analysis error",
    });
  } finally {
    activeAnalyses.delete(tabId);
    detailedLog("[Maakima][Background] Analysis cleanup complete.", tabId);
  }
}
