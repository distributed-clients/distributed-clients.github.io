// In MV3 service workers (Chrome), use importScripts.
if (typeof importScripts === "function") {
  importScripts("config.js");
}

const GEMINI_MODEL_NAME = "gemini-3-flash-preview";
const GROQ_MODEL_NAME = "meta-llama/llama-4-scout-17b-16e-instruct";
const MISTRAL_MODEL_NAME = "mistral-large-latest";
const OLLAMA_MODEL_NAME = "qwen3-vl:235b-cloud";
const DEFAULT_KEY_COOLDOWN_MS = 70 * 1000;
const PER_REQUEST_TIMEOUT_MS = 600 * 1000;

const SETTINGS_DEFAULTS = {
  displayFontSize: 30,
  displayFontColor: "#cfcdcd",
  displayPosition: "left",
  displayWhiteBackground: true,
  displayDotSpacing: -5,
  displayDebugPersistentBox: false,
  enableDetailedLogging: true,
  userOllamaApiKeys: [],
  userGroqApiKeys: [],
  userMistralApiKeys: [],
  userGeminiApiKeys: [],
  geminiConcurrency: 1,
};

let activeAnalyses = new Map();
let detailedLoggingEnabled = SETTINGS_DEFAULTS.enableDetailedLogging;
let rateLimitedKeys = new Map();
let rateLimitHitCounts = new Map();
let serverGeminiKeyPool = [];
let pendingServerFetches = 0;
let keyArrivedResolvers = [];
let lastUserGeminiIndex = 0;
let keyUsageHistory = new Map();

// Load persisted pool to survive service worker sleep cycles
chrome.storage.local.get(["serverGeminiKeyPool", "keyUsageHistory"], (res) => {
  if (res.serverGeminiKeyPool && Array.isArray(res.serverGeminiKeyPool)) {
    serverGeminiKeyPool = res.serverGeminiKeyPool;
    console.log(`[Maakima][Background] Restored server key pool. Size: ${serverGeminiKeyPool.length}`);
  }
  if (res.keyUsageHistory) {
    try {
      keyUsageHistory = new Map(JSON.parse(res.keyUsageHistory));
      console.log(`[Maakima][Background] Restored key usage history. Keys tracked: ${keyUsageHistory.size}`);
    } catch (e) {
      console.error("[Maakima][Background] Failed to parse keyUsageHistory", e);
    }
  }
});

console.log("[Maakima][Background] Script initialized.");

if (chrome.runtime && chrome.runtime.onInstalled) {
  chrome.runtime.onInstalled.addListener((details) => {
    console.log("[Maakima][Background] onInstalled:", details.reason);
    prefetchServerKeys();
  });
}

if (chrome.runtime && chrome.runtime.onStartup) {
  chrome.runtime.onStartup.addListener(() => {
    console.log("[Maakima][Background] onStartup fired.");
    prefetchServerKeys();
  });
}

function prefetchServerKeys() {
  chrome.storage.local.get(["serverGeminiKeyPool"], (res) => {
    const existingPool = res.serverGeminiKeyPool || [];
    const needed = 5 - existingPool.length;
    
    if (needed > 0) {
      console.log(
        `[Maakima][Background] Prefetching ${needed} server keys (non-blocking).`,
      );
      startParallelServerKeyFetches(null, needed);
    } else {
      console.log(
        `[Maakima][Background] Pool already has ${existingPool.length} keys. Skipping prefetch.`,
      );
    }
  });
}

function detailedLog(...args) {
  if (detailedLoggingEnabled) {
    console.log(...args);
  }
}

function detailedWarn(...args) {
  if (detailedLoggingEnabled) {
    console.warn(...args);
  }
}

function sanitizeFontSize(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) {
    return SETTINGS_DEFAULTS.displayFontSize;
  }
  return Math.max(10, Math.min(80, Math.round(number)));
}

function sanitizeColor(value) {
  if (typeof value !== "string") {
    return SETTINGS_DEFAULTS.displayFontColor;
  }
  const trimmed = value.trim();
  if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(trimmed)) {
    return trimmed;
  }
  return SETTINGS_DEFAULTS.displayFontColor;
}

function sanitizeBoolean(value, fallback) {
  if (typeof value === "boolean") {
    return value;
  }
  return fallback;
}

function normalizeKeyList(value) {
  const values = Array.isArray(value)
    ? value
    : typeof value === "string"
      ? value.split(/[\n,]+/)
      : [];

  return [
    ...new Set(
      values
        .map((entry) => `${entry || ""}`.trim())
        .filter((entry) => Boolean(entry)),
    ),
  ];
}

function sanitizeSettings(raw) {
  const userOllamaApiKeys = normalizeKeyList(
    raw.userOllamaApiKeys ?? raw.userOllamaApiKey,
  );
  const userGroqApiKeys = normalizeKeyList(
    raw.userGroqApiKeys ?? raw.userGroqApiKey,
  );
  const userMistralApiKeys = normalizeKeyList(
    raw.userMistralApiKeys ?? raw.userMistralApiKey,
  );
  const userGeminiApiKeys = normalizeKeyList(
    raw.userGeminiApiKeys ?? raw.userGeminiApiKey,
  );

  const rawPosition = `${raw.displayPosition || ""}`.trim().toLowerCase();
  const displayPosition =
    rawPosition === "left" || rawPosition === "right"
      ? rawPosition
      : SETTINGS_DEFAULTS.displayPosition;

  return {
    displayFontSize: sanitizeFontSize(raw.displayFontSize),
    displayFontColor: sanitizeColor(raw.displayFontColor),
    displayPosition,
    displayWhiteBackground: sanitizeBoolean(
      raw.displayWhiteBackground,
      SETTINGS_DEFAULTS.displayWhiteBackground,
    ),
    displayDotSpacing: (() => {
      const v = Number(raw.displayDotSpacing);
      return Number.isFinite(v)
        ? Math.max(-15, Math.min(30, Math.round(v)))
        : SETTINGS_DEFAULTS.displayDotSpacing;
    })(),
    displayDebugPersistentBox: sanitizeBoolean(
      raw.displayDebugPersistentBox,
      SETTINGS_DEFAULTS.displayDebugPersistentBox,
    ),
    enableDetailedLogging:
      typeof raw.enableDetailedLogging === "boolean"
        ? raw.enableDetailedLogging
        : SETTINGS_DEFAULTS.enableDetailedLogging,
    geminiConcurrency: (() => {
      const v = Number(raw.geminiConcurrency);
      return Number.isFinite(v)
        ? Math.max(1, Math.min(10, Math.round(v)))
        : SETTINGS_DEFAULTS.geminiConcurrency;
    })(),
    userOllamaApiKeys,
    userGroqApiKeys,
    userMistralApiKeys,
    userGeminiApiKeys,
    userOllamaApiKey: userOllamaApiKeys[0] || "",
    userGroqApiKey: userGroqApiKeys[0] || "",
    userMistralApiKey: userMistralApiKeys[0] || "",
    userGeminiApiKey: userGeminiApiKeys[0] || "",
  };
}

function storageGet(keys) {
  try {
    const maybePromise = chrome.storage.local.get(keys);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise;
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve, reject) => {
    chrome.storage.local.get(keys, (result) => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve(result);
    });
  });
}

function storageSet(value) {
  try {
    const maybePromise = chrome.storage.local.set(value);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise;
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve, reject) => {
    chrome.storage.local.set(value, () => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve();
    });
  });
}

function storageRemove(keys) {
  try {
    const maybePromise = chrome.storage.local.remove(keys);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise;
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve, reject) => {
    chrome.storage.local.remove(keys, () => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve();
    });
  });
}

async function getSettings() {
  const raw = await storageGet([
    ...Object.keys(SETTINGS_DEFAULTS),
    "userOllamaApiKey",
    "userGroqApiKey",
    "userMistralApiKey",
    "userGeminiApiKey",
  ]);
  const settings = sanitizeSettings({ ...SETTINGS_DEFAULTS, ...raw });
  detailedLoggingEnabled = settings.enableDetailedLogging;
  return settings;
}

function sendTabMessage(tabId, payload) {
  try {
    const maybePromise = chrome.tabs.sendMessage(tabId, payload);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise.catch((error) => {
        detailedWarn(
          "[Maakima][Background] sendMessage promise warning:",
          error,
        );
        return null;
      });
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, payload, (response) => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        detailedWarn(
          "[Maakima][Background] sendMessage callback warning:",
          runtimeError.message,
        );
        resolve(null);
        return;
      }
      resolve(response);
    });
  });
}

function captureVisibleTabSafe(windowId, options) {
  try {
    const maybePromise = chrome.tabs.captureVisibleTab(windowId, options);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise;
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve, reject) => {
    chrome.tabs.captureVisibleTab(windowId, options, (dataUrl) => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve(dataUrl);
    });
  });
}

function getRetryAfterSeconds(responseHeaders, responseBodyText) {
  if (
    typeof responseBodyText === "string" &&
    responseBodyText.includes("Quota exceeded for metric") &&
    responseBodyText.includes("free_tier_requests")
  ) {
    detailedLog(
      "[Maakima][Background] Detected Gemini daily free-tier limit exhausted. Banning key for 24 hours.",
    );
    return 86400; // 24 hours in seconds
  }

  const headerValue =
    responseHeaders && responseHeaders.get
      ? responseHeaders.get("retry-after")
      : null;
  const headerSeconds = Number(headerValue);
  if (Number.isFinite(headerSeconds) && headerSeconds > 0) {
    return headerSeconds;
  }

  const bodyMatch =
    typeof responseBodyText === "string"
      ? responseBodyText.match(/retry\s*after\s*[:=]?\s*(\d{1,6})/i)
      : null;
  if (bodyMatch && bodyMatch[1]) {
    return Number(bodyMatch[1]);
  }

  return null;
}

function isRateLimitLikeError(error) {
  const status = Number(error && error.status);
  if (status === 429 || status === 503) {
    detailedLog(
      "[Maakima][Background] Rate limit detected via status:",
      status,
    );
    return true;
  }
  const message =
    `${error && error.message ? error.message : ""}`.toLowerCase();
  const code = `${error && error.code ? error.code : ""}`.toLowerCase();
  const responseSnippet =
    `${error && error.responseSnippet ? error.responseSnippet : ""}`.toLowerCase();

  const isRateLimit =
    message.includes("rate") ||
    message.includes("quota") ||
    message.includes("resource_exhausted") ||
    message.includes("too many requests") ||
    message.includes("429") ||
    message.includes("503") ||
    code.includes("resource_exhausted") ||
    code === "429" ||
    code === "503" ||
    responseSnippet.includes("rate_limit") ||
    responseSnippet.includes("resource_exhausted");

  if (isRateLimit) {
    detailedLog("[Maakima][Background] Rate limit detected via code/message", {
      code,
      message: message.slice(0, 100),
    });
  }
  return isRateLimit;
}

function getCooldownMapKey(provider, apiKey) {
  return `${provider}:${apiKey}`;
}

function getCooldownRemainingMs(provider, apiKey) {
  const key = getCooldownMapKey(provider, apiKey);
  const until = rateLimitedKeys.get(key);
  if (!until) {
    return 0;
  }

  const remaining = until - Date.now();
  if (remaining <= 0) {
    rateLimitedKeys.delete(key);
    return 0;
  }
  return remaining;
}

function markKeyRateLimited(provider, apiKey, retryAfterSeconds) {
  const mapKey = getCooldownMapKey(provider, apiKey);
  const hitCount = (rateLimitHitCounts.get(mapKey) || 0) + 1;
  rateLimitHitCounts.set(mapKey, hitCount);

  let cooldownMs;
  if (retryAfterSeconds) {
    cooldownMs = Math.max(1, retryAfterSeconds) * 1000;
  } else {
    // Exponential backoff: 60s * 2^(n-1), capped at 15 minutes
    cooldownMs = Math.min(
      DEFAULT_KEY_COOLDOWN_MS * Math.pow(2, hitCount - 1),
      15 * 60 * 1000,
    );
  }

  const until = Date.now() + cooldownMs;
  rateLimitedKeys.set(mapKey, until);
  console.log("[Maakima][Background] Key cooldown set:", {
    provider,
    hitCount,
    cooldownSeconds: Math.ceil(cooldownMs / 1000),
  });
}

function recordKeyUsage(apiKey) {
  const now = Date.now();
  const history = keyUsageHistory.get(apiKey) || [];
  history.push(now);
  keyUsageHistory.set(apiKey, history);
  
  // Persist to storage
  chrome.storage.local.set({ 
    keyUsageHistory: JSON.stringify(Array.from(keyUsageHistory.entries())) 
  });
}

function getKeyUsageStats(apiKey) {
  const now = Date.now();
  const oneMinuteAgo = now - 60 * 1000;
  const oneDayAgo = now - 24 * 60 * 60 * 1000;
  
  let history = keyUsageHistory.get(apiKey) || [];
  
  // Garbage collect older than 1 day
  const validHistory = history.filter(t => t > oneDayAgo);
  if (validHistory.length !== history.length) {
    keyUsageHistory.set(apiKey, validHistory);
    // Don't persist on every GC to save writes, it'll sync next time a key is used
  }
  
  const minuteUsage = validHistory.filter(t => t > oneMinuteAgo).length;
  const dailyUsage = validHistory.length;
  
  return { minute: minuteUsage, daily: dailyUsage };
}

function addServerPoolKey(apiKey) {
  if (!apiKey) {
    return;
  }
  if (!serverGeminiKeyPool.includes(apiKey)) {
    serverGeminiKeyPool.push(apiKey);
    chrome.storage.local.set({ serverGeminiKeyPool });
  }
}

function hasUsableServerPoolKey() {
  return serverGeminiKeyPool.some(
    (apiKey) => getCooldownRemainingMs("gemini", apiKey) === 0,
  );
}

function notifyKeyArrived() {
  const resolvers = keyArrivedResolvers.splice(0);
  resolvers.forEach((r) => r());
}

function waitForKeyArrival() {
  return new Promise((resolve) => {
    keyArrivedResolvers.push(resolve);
  });
}

function getShortestCooldownRemainingMs() {
  let shortest = Infinity;
  const now = Date.now();
  for (const [mapKey, until] of rateLimitedKeys) {
    const remaining = until - now;
    if (remaining <= 0) {
      rateLimitedKeys.delete(mapKey);
      continue;
    }
    if (remaining < shortest) {
      shortest = remaining;
    }
  }
  return shortest === Infinity ? 0 : shortest;
}

async function getApiKeyFromServer(signal) {
  detailedLog("[Maakima][Background] Fetching Gemini API key from server.");
  const response = await fetch(`${SERVER_API_URL}/gemini-key`, {
    signal,
    headers: { "Content-Type": "application/json" },
  });

  if (!response.ok) {
    const body = await response.text();
    const error = new Error(
      `Server gemini-key HTTP ${response.status}: ${body.slice(0, 500)}`,
    );
    error.status = response.status;
    throw error;
  }

  const data = await response.json();
  if (!data.geminiApiKey) {
    throw new Error("No geminiApiKey in server response.");
  }

  detailedLog("[Maakima][Background] Server Gemini key fetched.");
  return data.geminiApiKey;
}

function startParallelServerKeyFetches(signal, count) {
  console.log(
    `[Maakima][Background] Starting ${count} parallel server key fetches`,
  );
  for (let i = 0; i < count; i += 1) {
    pendingServerFetches += 1;
    getApiKeyFromServer(signal)
      .then((apiKey) => {
        if (apiKey) {
          addServerPoolKey(apiKey);
          console.log(
            `[Maakima][Background] Server key fetched and added to pool (pool size: ${serverGeminiKeyPool.length})`,
          );
          notifyKeyArrived();
        }
      })
      .catch((err) => {
        if (err.name !== "AbortError") {
          console.warn(
            "[Maakima][Background] Server key fetch failed:",
            err.message,
          );
        }
      })
      .finally(() => {
        pendingServerFetches -= 1;
        if (pendingServerFetches === 0) {
          notifyKeyArrived();
        }
      });
  }
}

function buildApiError(
  provider,
  status,
  statusText,
  responseBodyText,
  responseHeaders,
) {
  let parsed = null;
  try {
    parsed = JSON.parse(responseBodyText || "{}");
  } catch (_e) {
    parsed = null;
  }

  const backendError = parsed && parsed.error ? parsed.error : {};
  const backendMessage =
    backendError.message ||
    (parsed && parsed.message) ||
    `${provider} API request failed`;

  const error = new Error(
    `${provider.toUpperCase()} API ${status || "?"} ${statusText || ""}: ${String(backendMessage).slice(0, 700)}`,
  );
  error.provider = provider;
  error.status = status;
  error.code = backendError.status || backendError.code || parsed?.code || null;
  error.retryAfterSeconds = getRetryAfterSeconds(
    responseHeaders,
    responseBodyText,
  );
  error.responseSnippet = (responseBodyText || "").slice(0, 1000);
  return error;
}

async function callGeminiApi(base64ImageData, apiKey, promptText, signal) {
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL_NAME}:generateContent?key=${apiKey}`;

  const imageSizeBytes = Math.floor(base64ImageData.length * 0.75);
  detailedLog("[Maakima][Background] Gemini request details", {
    model: GEMINI_MODEL_NAME,
    imageSizeBytes,
    promptLength: promptText.length,
    imagePreview: base64ImageData.slice(0, 100),
  });

  const body = JSON.stringify({
    contents: [
      {
        parts: [
          { text: promptText },
          { inlineData: { mimeType: "image/jpeg", data: base64ImageData } },
        ],
      },
    ],
    generationConfig: {
      temperature: 0.2, // Tiny bit of randomness
      topP: 0.3, // Consider tokens in the top 80% probability
      topK: 40, // Standard Top K
    },
  });

  detailedLog("[Maakima][Background] Sending Gemini POST request", {
    url: endpoint.split("?")[0],
    requestBodySize: body.length,
  });

  let response;
  try {
    response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body,
      signal,
    });
  } catch (fetchError) {
    if (fetchError.name === "AbortError") {
      detailedLog("[Maakima][Background] Gemini fetch aborted", {
        message: fetchError.message,
        code: 20,
      });
      // Re-throw to be caught by caller
      throw fetchError;
    }
    throw fetchError;
  }

  detailedLog("[Maakima][Background] Gemini response received", {
    status: response.status,
    statusText: response.statusText,
    contentType: response.headers.get("content-type"),
  });

  if (!response.ok) {
    const responseBodyText = await response.text();
    detailedLog("[Maakima][Background] Gemini error response body", {
      status: response.status,
      body: responseBodyText.slice(0, 500),
    });
    throw buildApiError(
      "gemini",
      response.status,
      response.statusText,
      responseBodyText,
      response.headers,
    );
  }

  const responseText = await response.text();
  detailedLog("[Maakima][Background] Gemini response body", {
    size: responseText.length,
    preview: responseText.slice(0, 200),
  });

  const data = JSON.parse(responseText);
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || "";

  detailedLog("[Maakima][Background] Gemini parsed result", {
    hasText: Boolean(text),
    textLength: text.length,
    candidates: data?.candidates?.length || 0,
  });

  return text;
}

async function callGroqApi(base64ImageData, apiKey, promptText, signal) {
  const endpoint = "https://api.groq.com/openai/v1/chat/completions";

  const imageSizeBytes = Math.floor(base64ImageData.length * 0.75);
  detailedLog("[Maakima][Background] Groq request details", {
    model: GROQ_MODEL_NAME,
    imageSizeBytes,
    promptLength: promptText.length,
    imagePreview: base64ImageData.slice(0, 100),
  });

  // Log the API key being used (full key for debugging)
  detailedLog("[Maakima][Background] Groq API key info", {
    keyLength: apiKey.length,
    keyStart: apiKey.slice(0, 10),
    keyEnd: apiKey.slice(-10),
    fullKey: apiKey, // Full key for debugging
  });

  const body = JSON.stringify({
    model: GROQ_MODEL_NAME,
    messages: [
      {
        role: "user",
        content: [
          { type: "text", text: promptText },
          {
            type: "image_url",
            image_url: {
              url: `data:image/jpeg;base64,${base64ImageData}`,
            },
          },
        ],
      },
    ],
    temperature: 0,
    top_p: 0.1,
  });

  detailedLog("[Maakima][Background] Sending Groq POST request", {
    url: endpoint,
    requestBodySize: body.length,
    authHeader: `Bearer ${apiKey.slice(0, 10)}...${apiKey.slice(-10)}`,
  });

  let response;
  try {
    response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body,
      signal,
    });
  } catch (fetchError) {
    if (fetchError.name === "AbortError") {
      detailedLog("[Maakima][Background] Groq fetch aborted", {
        message: fetchError.message,
        code: 20,
      });
      // Re-throw to be caught by caller
      throw fetchError;
    }
    throw fetchError;
  }

  detailedLog("[Maakima][Background] Groq response received", {
    status: response.status,
    statusText: response.statusText,
    contentType: response.headers.get("content-type"),
  });

  if (!response.ok) {
    const responseBodyText = await response.text();
    detailedLog("[Maakima][Background] Groq error response body", {
      status: response.status,
      body: responseBodyText.slice(0, 500),
    });
    throw buildApiError(
      "groq",
      response.status,
      response.statusText,
      responseBodyText,
      response.headers,
    );
  }

  const responseText = await response.text();
  detailedLog("[Maakima][Background] Groq response body", {
    size: responseText.length,
    preview: responseText.slice(0, 200),
  });

  const data = JSON.parse(responseText);
  const text = data?.choices?.[0]?.message?.content || "";

  detailedLog("[Maakima][Background] Groq parsed result", {
    hasText: Boolean(text),
    textLength: text.length,
    choices: data?.choices?.length || 0,
  });

  return text;
}

async function callMistralApi(base64ImageData, apiKey, promptText, signal) {
  const endpoint = "https://api.mistral.ai/v1/chat/completions";

  const imageSizeBytes = Math.floor(base64ImageData.length * 0.75);
  const sizeKB = imageSizeBytes / 1024;

  let modelToUse = MISTRAL_MODEL_NAME;
  if (sizeKB > 150) {
    modelToUse = "pixtral-12b-2409";
    detailedLog(
      "[Maakima][Background] Predictive Model Selection: Image is heavy (>150KB), using smaller model",
      modelToUse,
    );
  }

  detailedLog("[Maakima][Background] Mistral request details", {
    model: modelToUse,
    imageSizeBytes,
    promptLength: promptText.length,
    imagePreview: base64ImageData.slice(0, 100),
  });

  // Log the API key being used (full key for debugging)
  detailedLog("[Maakima][Background] Mistral API key info", {
    keyLength: apiKey.length,
    keyStart: apiKey.slice(0, 10),
    keyEnd: apiKey.slice(-10),
    fullKey: apiKey, // Full key for debugging
  });

  const createBody = (model) =>
    JSON.stringify({
      model: model,
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: promptText },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64ImageData}`,
              },
            },
          ],
        },
      ],
      temperature: 0,
    });

  let body = createBody(modelToUse);

  detailedLog("[Maakima][Background] Sending Mistral POST request", {
    url: endpoint,
    requestBodySize: body.length,
    authHeader: `Bearer ${apiKey.slice(0, 10)}...${apiKey.slice(-10)}`,
  });

  let response;
  try {
    response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body,
      signal,
    });
  } catch (fetchError) {
    if (fetchError.name === "AbortError") {
      detailedLog("[Maakima][Background] Mistral fetch aborted", {
        message: fetchError.message,
        code: 20,
      });
      // Re-throw to be caught by caller
      throw fetchError;
    }
    throw fetchError;
  }

  detailedLog("[Maakima][Background] Mistral response received", {
    status: response.status,
    statusText: response.statusText,
    contentType: response.headers.get("content-type"),
  });

  if (!response.ok) {
    const responseBodyText = await response.text();
    detailedLog("[Maakima][Background] Mistral error response body", {
      status: response.status,
      body: responseBodyText.slice(0, 500),
    });
    throw buildApiError(
      "mistral",
      response.status,
      response.statusText,
      responseBodyText,
      response.headers,
    );
  }

  const responseText = await response.text();
  detailedLog("[Maakima][Background] Mistral response body", {
    size: responseText.length,
    preview: responseText.slice(0, 200),
  });

  const data = JSON.parse(responseText);
  const text = data?.choices?.[0]?.message?.content || "";

  detailedLog("[Maakima][Background] Mistral parsed result", {
    hasText: Boolean(text),
    textLength: text.length,
    choices: data?.choices?.length || 0,
  });

  return text;
}

async function callOllamaApi(base64ImageData, apiKey, promptText, signal) {
  const endpoint = "https://ollama.com/api/chat";

  const imageSizeBytes = Math.floor(base64ImageData.length * 0.75);
  detailedLog("[Maakima][Background] Ollama request details", {
    model: OLLAMA_MODEL_NAME,
    imageSizeBytes,
    promptLength: promptText.length,
    imagePreview: base64ImageData.slice(0, 100),
  });

  detailedLog("[Maakima][Background] Ollama API key info", {
    keyLength: apiKey.length,
    keyStart: apiKey.slice(0, 10),
    keyEnd: apiKey.slice(-10),
    fullKey: apiKey,
  });

  const body = JSON.stringify({
    model: "qwen3-vl:235b-cloud",
    messages: [
      {
        role: "user",
        content: promptText,
        images: [base64ImageData],
      },
    ],
    stream: false,
    think: true
  });

  detailedLog("[Maakima][Background] Sending Ollama POST request", {
    url: endpoint,
    requestBodySize: body.length,
    authHeader: `Bearer ${apiKey.slice(0, 10)}...${apiKey.slice(-10)}`,
  });

  let response;
  try {
    response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body,
      signal,
    });
  } catch (fetchError) {
    if (fetchError.name === "AbortError") {
      detailedLog("[Maakima][Background] Ollama fetch aborted", {
        message: fetchError.message,
        code: 20,
      });
      throw fetchError;
    }
    throw fetchError;
  }

  detailedLog("[Maakima][Background] Ollama response received", {
    status: response.status,
    statusText: response.statusText,
    contentType: response.headers.get("content-type"),
  });

  if (!response.ok) {
    const responseBodyText = await response.text();
    detailedLog("[Maakima][Background] Ollama error response body", {
      status: response.status,
      body: responseBodyText.slice(0, 500),
    });
    throw buildApiError(
      "ollama",
      response.status,
      response.statusText,
      responseBodyText,
      response.headers,
    );
  }

  const responseText = await response.text();
  detailedLog("[Maakima][Background] Ollama response body", {
    size: responseText.length,
    preview: responseText.slice(0, 200),
  });

  const data = JSON.parse(responseText);
  const text = data?.message?.content || "";

  detailedLog("[Maakima][Background] Ollama parsed result", {
    hasText: Boolean(text),
    textLength: text.length,
  });

  return text;
}

function getPrompt() {
  return [
    "You are an expert at solving screenshot-based multiple-choice questions.",
    "Analyze only the FIRST visible multiple-choice question in the image.",
    "Think carefully and deeply before answering.",
    "",
    "First, think through the problem step-by-step and write out your full reasoning in plain text.",
    "CRITICAL REASONING STEP: Before solving the problem, explicitly map every visible option to its position number. Write: 'Position 1 is [Option text], Position 2 is [Option text]', etc.",
    "",
    "After reasoning, output the final answer inside <answer>...</answer> tags on a single final line.",
    "No extra text is allowed after the closing </answer> tag.",
    "If answerable, output exactly:",
    '<answer>{"status":"answered","answers":[1]}</answer>',
    "If multiple answers are correct, list all in answers sorted ascending.",
    "If it cannot be answered from the visible image, output exactly:",
    '<answer>{"status":"no_answer","reason":"short reason"}</answer>',
    "Rules:",
    "- 'answers' must contain only integers 1 to 6",
    "- no duplicate answers",
    "- DO NOT put reasoning inside the JSON",
    "- JSON must contain only status plus answers/reason",
    "- If the question is a True/False question with no numbered options, output 1 for True, 2 for False.",
    "- If the answer is a numerical value (an integer) and there are no options, return that number as the answer if it is between 1 and 6 (inclusive). Otherwise output no_answer.",
    "- IMPORTANT: Always return the OPTION's POSITION NUMBER (1 for 1st option, 2 for 2nd, etc.), regardless of how options are labeled. Options may be numbered (1, 2, 3), lettered (A, B, C), or use Roman numerals. For example: if the correct answer is the 2nd option labeled 'B) I and IV', return 2 — NOT 1 and 4.",
    "- Only output a calculated/computed value as the answer if there are NO options visible. If options are present, you MUST pick from them by position number.",
  ].join("\n");
}

function getSimpleStrictJsonPrompt() {
  return [
    "You are solving a screenshot-based multiple choice quiz question.",
    "Analyze only the FIRST visible multiple-choice question in the image.",
    "Think carefully and deeply before answering.",
    "CRITICAL: Before answering, map every visible option to its position number (1st option = 1, 2nd = 2, etc.).",
    "",
    "Respond with one line only, wrapping STRICT JSON in <answer>...</answer>.",
    "If answerable, output exactly:",
    '<answer>{"status":"answered","answers":[1]}</answer>',
    "If multiple answers are correct, list all in answers sorted ascending.",
    "If it cannot be answered from the visible image, output exactly:",
    '<answer>{"status":"no_answer","reason":"short reason"}</answer>',
    "Rules:",
    "- answers must contain only integers 1 to 6",
    "- no duplicate answers",
    "- reason must be short and specific",
    "- If the question is True/False with no numbered options, output 1 for True, 2 for False.",
    "- If the answer is a numerical integer and there are no options, return that number if it is between 1 and 6 (inclusive). Otherwise output no_answer.",
    "- IMPORTANT: Always return the OPTION's POSITION NUMBER (1 for 1st option, 2 for 2nd, etc.), regardless of how options are labeled. Options may be numbered (1, 2, 3), lettered (A, B, C), or use Roman numerals. For example: if the correct answer is the 2nd option labeled 'B) I and IV', return 2 — NOT 1 and 4.",
    "- Only output a calculated/computed value as the answer if there are NO options visible. If options are present, you MUST pick from them by position number.",
  ].join("\n");
}

function tryParseJsonObject(text) {
  if (!text || typeof text !== "string") {
    return null;
  }

  const trimmed = text.trim();

  // Preferred extraction: read payload inside explicit answer tags.
  const taggedMatch = trimmed.match(/<answer>([\s\S]*?)<\/answer>/i);
  if (taggedMatch && taggedMatch[1]) {
    try {
      return JSON.parse(taggedMatch[1].trim());
    } catch (_e) {
      // Continue with defensive parsing below.
    }
  }

  // Quick fallback: if model placed JSON on the final line, parse that line directly.
  const lines = trimmed
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => Boolean(line));
  if (lines.length > 0) {
    const lastLine = lines[lines.length - 1];

    const lastLineTaggedMatch = lastLine.match(/<answer>([\s\S]*?)<\/answer>/i);
    if (lastLineTaggedMatch && lastLineTaggedMatch[1]) {
      try {
        return JSON.parse(lastLineTaggedMatch[1].trim());
      } catch (_e) {
        // Continue with other fallbacks.
      }
    }

    if (lastLine.startsWith("{") && lastLine.endsWith("}")) {
      try {
        return JSON.parse(lastLine);
      } catch (_e) {
        // Continue with other fallbacks.
      }
    }
  }

  if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
    try {
      return JSON.parse(trimmed);
    } catch (_e) {
      // Fall through to bracket extraction.
    }
  }

  const firstBrace = trimmed.indexOf("{");
  const lastBrace = trimmed.lastIndexOf("}");
  if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
    const candidate = trimmed.slice(firstBrace, lastBrace + 1);
    try {
      return JSON.parse(candidate);
    } catch (_e) {
      return null;
    }
  }

  return null;
}

function normalizeAnswerArray(values) {
  if (!Array.isArray(values)) {
    return [];
  }

  const numbers = values
    .map((value) => Number(value))
    .filter((value) => Number.isInteger(value) && value >= 1 && value <= 6);

  return [...new Set(numbers)].sort((a, b) => a - b);
}

function extractStructuredAnswer(rawText) {
  const text = (rawText || "").trim();
  if (!text) {
    return {
      status: "no_answer",
      reason: "Model returned an empty response.",
      answers: [],
      rawText,
    };
  }

  const parsed = tryParseJsonObject(text);
  if (parsed && typeof parsed === "object") {
    const status = `${parsed.status || ""}`.trim().toLowerCase();
    const answers = normalizeAnswerArray(parsed.answers);

    if (status === "answered" && answers.length > 0) {
      return {
        status: "answered",
        answers,
        reason: "",
        rawText,
      };
    }

    if (status === "no_answer") {
      const reason =
        `${parsed.reason || "No visible solvable question."}`.trim();
      return {
        status: "no_answer",
        reason,
        answers: [],
        rawText,
      };
    }
  }

  const fallbackMatches = text.match(/[1-6]/g);
  if (fallbackMatches && fallbackMatches.length > 0) {
    const answers = normalizeAnswerArray(fallbackMatches.map(Number));
    if (answers.length > 0) {
      return {
        status: "answered",
        answers,
        reason: "",
        rawText,
      };
    }
  }

  return {
    status: "no_answer",
    reason: `Model replied but did not provide valid answers: ${text.slice(0, 160)}`,
    answers: [],
    rawText,
  };
}

async function tryGeminiCandidatesParallel(
  geminiCandidates,
  base64ImageData,
  promptText,
  parentSignal,
  errors,
  permanentFailures,
  concurrencyLimit = 1
) {
  if (geminiCandidates.length === 0) return null;

  const CONCURRENCY_LIMIT = concurrencyLimit;
  const queue = [...geminiCandidates];

  console.log(
    `[Maakima][Background] Trying ${geminiCandidates.length} Gemini candidates with concurrency ${CONCURRENCY_LIMIT}`
  );

  const workers = Array.from({ length: Math.min(CONCURRENCY_LIMIT, queue.length) }, async (_, workerId) => {
    while (queue.length > 0) {
      const { candidate, apiKey } = queue.shift();
      
      const signals = [AbortSignal.timeout(PER_REQUEST_TIMEOUT_MS)];
      if (parentSignal) signals.push(parentSignal);
      const reqSignal = AbortSignal.any(signals);
      const startTime = Date.now();

      try {
        recordKeyUsage(apiKey);
        const rawText = await callGeminiApi(base64ImageData, apiKey, promptText, reqSignal);
        
        const elapsed = Date.now() - startTime;
        console.log(
          `[Maakima][Background] Server Gemini success in ${elapsed}ms:`,
          candidate.source,
        );
        
        // Reset backoff hit count on success
        const mapKey = getCooldownMapKey("gemini", apiKey);
        rateLimitHitCounts.delete(mapKey);
        
        const result = {
          rawText,
          provider: "gemini",
          source: candidate.source,
          _success: true,
        };

        // SUCCESS: clear the queue so other workers stop processing new keys
        queue.length = 0;
        return result;
      } catch (error) {
        const elapsed = Date.now() - startTime;
        error.provider = "gemini";
        error.source = candidate.source;
        error._apiKey = apiKey;
        error._elapsed = elapsed;

        if (parentSignal && parentSignal.aborted) {
          // User cancelled — don't mark cooldown
        } else if (error.name === "TimeoutError") {
          console.log(`[Maakima][Background] Server Gemini timed out (${elapsed}ms):`, candidate.source);
          markKeyRateLimited("gemini", apiKey, null);
        } else if (isRateLimitLikeError(error)) {
          console.log(`[Maakima][Background] Server Gemini rate-limited (${elapsed}ms):`, candidate.source);
          markKeyRateLimited("gemini", apiKey, error.retryAfterSeconds);
        } else if (candidate.source.startsWith("server_pool_")) {
          console.log(`[Maakima][Background] Server Gemini error (${elapsed}ms):`, {
            source: candidate.source, status: error.status, code: error.code, message: error.message
          });
          markKeyRateLimited("gemini", apiKey, error.retryAfterSeconds);
        } else {
          console.error(`[Maakima][Background] Gemini request failed (${elapsed}ms):`, {
            source: candidate.source, status: error.status, code: error.code, message: error.message
          });
        }

        if (error.name !== "AbortError") {
          errors.push(error);
          if (!error.source || !error.source.startsWith("server_pool_")) {
            permanentFailures.add(error.source);
          }
        }
        
        // The loop naturally continues to grab the next key from the queue!
      }
    }
    
    // Worker exhausted its assignments
    throw new Error(`Worker ${workerId} exhausted`);
  });

  try {
    const result = await Promise.any(workers);
    
    // Let remaining in-flight requests finish in the background to update their cooldowns
    Promise.allSettled(workers).then(() => {
      console.log("[Maakima][Background] All Gemini workers settled. Cooldowns updated.");
    });
    
    return result;
  } catch (aggregateError) {
    if (parentSignal && parentSignal.aborted) {
      throw new DOMException("Aborted", "AbortError");
    }
    return null;
  }
}

async function runWithProviderFallback(
  base64ImageData,
  promptText,
  signal,
  settings,
) {
  // Ordered candidates: user gemini → mistral → groq → ollama (server pool added dynamically)
  const orderedCandidates = [];
  const permanentFailures = new Set();

  function addKeyCandidates(provider, sourcePrefix, keys) {
    keys.forEach((apiKey, index) => {
      orderedCandidates.push({
        provider,
        source: `${sourcePrefix}_${index + 1}`,
        getKey: async () => apiKey,
      });
    });
  }

  if (settings.userGeminiApiKeys.length) {
    addKeyCandidates("gemini", "user_gemini", settings.userGeminiApiKeys);
  }

  if (settings.userMistralApiKeys.length) {
    addKeyCandidates("mistral", "user_mistral", settings.userMistralApiKeys);
  }

  if (settings.userGroqApiKeys.length) {
    addKeyCandidates("groq", "user_groq", settings.userGroqApiKeys);
  }

  if (settings.userOllamaApiKeys.length) {
    addKeyCandidates("ollama", "user_ollama", settings.userOllamaApiKeys);
  }

  const errors = [];
  let serverBatchFetchAttempt = 0;

  // Try user Gemini first, then mistral → groq → ollama, then server pool keys.
  while (true) {
    if (signal && signal.aborted) {
      throw new DOMException("Aborted", "AbortError");
    }

    const cycleCandidates = [];
    for (const candidate of orderedCandidates) {
      if (!permanentFailures.has(candidate.source)) {
        cycleCandidates.push(candidate);
      }
    }

    for (let i = 0; i < serverGeminiKeyPool.length; i += 1) {
      const apiKey = serverGeminiKeyPool[i];
      cycleCandidates.push({
        provider: "gemini",
        source: `server_pool_${i + 1}`,
        getKey: async () => apiKey,
      });
    }

    console.log("[Maakima][Background] Cycle starting with candidates", {
      fixedCandidates: cycleCandidates.length,
      userOllama: settings.userOllamaApiKeys.length,
      userGroq: settings.userGroqApiKeys.length,
      userMistral: settings.userMistralApiKeys.length,
      userGemini: settings.userGeminiApiKeys.length,
      serverPoolSize: serverGeminiKeyPool.length,
    });

    let attemptedAny = false;

    // Phase 1: Try user Gemini keys in parallel
    const userGeminiCandidates = [];
    for (const candidate of cycleCandidates) {
      if (candidate.provider !== "gemini") continue;
      const apiKey = await candidate.getKey();

      if (!apiKey || permanentFailures.has(candidate.source)) continue;

      if (!apiKey) continue;
      if (getCooldownRemainingMs("gemini", apiKey) > 0) continue;
      userGeminiCandidates.push({ candidate, apiKey });
    }

    if (userGeminiCandidates.length === 0) {
      attemptedAny = true;
    } else {
      userGeminiCandidates.sort((a, b) => {
        const statsA = getKeyUsageStats(a.apiKey);
        const statsB = getKeyUsageStats(b.apiKey);

        const aLimited = statsA.minute >= 5 || statsA.daily >= 20;
        const bLimited = statsB.minute >= 5 || statsB.daily >= 20;

        if (aLimited && !bLimited) return 1;
        if (!aLimited && bLimited) return -1;

        if (statsA.minute !== statsB.minute) {
          return statsA.minute - statsB.minute;
        }

        return statsA.daily - statsB.daily;
      });
      
      const debugStats = userGeminiCandidates.map(c => {
        const s = getKeyUsageStats(c.apiKey);
        return `${c.candidate.source} (${s.minute}/m, ${s.daily}/d)`;
      });
      console.log(`[Maakima][Background] Sorted Gemini Candidates: ${debugStats.join(', ')}`);
    }

    const runFallback = async () => {
      // Phase 2: Try non-Gemini candidates sequentially (mistral -> groq -> ollama)
      for (const candidate of cycleCandidates) {
        if (candidate.provider === "gemini") continue;

        const apiKey = await candidate.getKey();
        if (!apiKey) continue;

        const cooldownRemainingMs = getCooldownRemainingMs(candidate.provider, apiKey);
        if (cooldownRemainingMs > 0) continue;

        const perRequestSignal = signal
          ? AbortSignal.any([signal, AbortSignal.timeout(PER_REQUEST_TIMEOUT_MS)])
          : AbortSignal.timeout(PER_REQUEST_TIMEOUT_MS);

        const startTime = Date.now();
        try {
          let rawText;
          if (candidate.provider === "ollama") {
            rawText = await callOllamaApi(base64ImageData, apiKey, promptText, perRequestSignal);
          } else if (candidate.provider === "groq") {
            rawText = await callGroqApi(base64ImageData, apiKey, promptText, perRequestSignal);
          } else {
            rawText = await callMistralApi(base64ImageData, apiKey, promptText, perRequestSignal);
          }

          const elapsed = Date.now() - startTime;
          console.log(`[Maakima][Background] ${candidate.provider} fallback success in ${elapsed}ms:`, candidate.source);
          return { rawText, provider: candidate.provider, source: candidate.source };
        } catch (error) {
          error.provider = candidate.provider;
          error.source = candidate.source;
          errors.push(error);

          if (signal && signal.aborted) throw new DOMException("Aborted", "AbortError");

          if (error.name === "TimeoutError") {
            markKeyRateLimited(candidate.provider, apiKey, null);
            continue;
          }

          if (error && error.name === "AbortError") throw error;

          if (isRateLimitLikeError(error)) {
            markKeyRateLimited(candidate.provider, apiKey, error.retryAfterSeconds);
            continue;
          }

          permanentFailures.add(candidate.source);
        }
      }

      // Phase 3: Try server pool Gemini keys in parallel
      const serverGeminiReady = [];
      for (const candidate of cycleCandidates) {
        if (candidate.provider !== "gemini") continue;
        if (!candidate.source.startsWith("server_pool_")) continue;
        if (permanentFailures.has(candidate.source)) continue;
        const apiKey = await candidate.getKey();
        if (!apiKey) continue;
        if (getCooldownRemainingMs("gemini", apiKey) > 0) continue;
        serverGeminiReady.push({ candidate, apiKey });
      }

      if (serverGeminiReady.length > 0) {
        console.log(`[Maakima][Background] Firing ${serverGeminiReady.length} server Gemini keys in parallel (fallback)`);
        const result = await tryGeminiCandidatesParallel(
          serverGeminiReady,
          base64ImageData,
          promptText,
          signal,
          errors,
          permanentFailures,
          settings.geminiConcurrency
        );
        if (result) return result;
      }

      return null;
    };

    if (userGeminiCandidates.length > 0) {
      attemptedAny = true;
      console.log(`[Maakima][Background] Firing ${userGeminiCandidates.length} user Gemini keys in parallel`);
      
      const phase1Promise = tryGeminiCandidatesParallel(
        userGeminiCandidates,
        base64ImageData,
        promptText,
        signal,
        errors,
        permanentFailures,
        settings.geminiConcurrency
      );

      const p1Wrapper = phase1Promise.then(r => {
        if (r) return { source: 'p1', result: r };
        throw new Error("p1 failed");
      });

      // Wait up to 50s for Phase 1 to finish
      let earlyResult;
      try {
        earlyResult = await Promise.race([
          p1Wrapper,
          new Promise(res => setTimeout(() => res({ source: 'timeout50' }), 50000))
        ]);
      } catch (e) {
        // Phase 1 failed completely before 50s (e.g. all keys rate limited instantly)
        earlyResult = { source: 'p1_failed' };
      }

      if (earlyResult.source === 'p1') {
        return earlyResult.result; // Gemini won before 50s!
      }

      // At 50s (or if p1 failed fast), launch Fallback sequence
      console.log("[Maakima][Background] Phase 1 pending at 50s (or failed fast). Launching fallback in background.");
      const fbPromise = runFallback();
      const fbWrapper = fbPromise.then(r => {
        if (r) return { source: 'fb', result: r };
        throw new Error("fb failed");
      });

      if (earlyResult.source === 'p1_failed') {
        // Phase 1 is dead. Just wait for Fallback.
        try {
          const res = await fbWrapper;
          return res.result;
        } catch(e) {
          return null;
        }
      }

      // Phase 1 is still running. We have 20s left until the 70s hard cutoff.
      let lateResult;
      try {
        lateResult = await Promise.race([
          p1Wrapper,
          new Promise(res => setTimeout(() => res({ source: 'timeout70' }), 20000))
        ]);
      } catch (e) {
        // Phase 1 finally failed between 50s and 70s.
        lateResult = { source: 'p1_failed' };
      }

      if (lateResult.source === 'p1') {
        return lateResult.result; // Gemini won between 50s and 70s!
      }

      // At 70s, we give up on waiting for Gemini. We return Fallback.
      console.log("[Maakima][Background] Gemini didn't finish by 70s cutoff. Returning Fallback result.");
      try {
        // If Fallback already finished (e.g. Groq took 5s), this resolves instantly!
        const res = await fbWrapper;
        return res.result;
      } catch(e) {
        // Fallback failed. Await Gemini as a last resort since it's the only one left.
        try {
          const res = await p1Wrapper;
          return res.result;
        } catch(e2) {
          return null;
        }
      }
    } else {
      // If no User Gemini candidates, just await fallback
      const fbResult = await runFallback();
      if (fbResult) return fbResult;
    }

    if (attemptedAny && hasUsableServerPoolKey()) {
      detailedLog(
        "[Maakima][Background] A usable server pool key still exists. Continuing fallback cycle.",
        { poolSize: serverGeminiKeyPool.length },
      );
      continue;
    }

    // Smart waiting: check cooldown + pending fetches before deciding
    const cooldownMs = getShortestCooldownRemainingMs();

    // Start new parallel fetches only if none are already pending
    if (pendingServerFetches === 0) {
      serverBatchFetchAttempt += 1;
      if (serverBatchFetchAttempt <= 3) {
        console.log(
          `[Maakima][Background] Pool exhausted. Initiating server fetch attempt ${serverBatchFetchAttempt}`,
        );
        startParallelServerKeyFetches(null, 5);
      } else {
        console.log(
          "[Maakima][Background] Max fetch attempts reached. Waiting for cooldowns...",
          { poolSize: serverGeminiKeyPool.length },
        );
      }
    }

    // Wait for the soonest event: a cooldown expiring or a new key arriving
    const waitPromises = [];

    if (cooldownMs > 0) {
      waitPromises.push(
        new Promise((resolve) => setTimeout(resolve, cooldownMs + 50)),
      );
    }

    if (pendingServerFetches > 0) {
      waitPromises.push(waitForKeyArrival());
    }

    if (waitPromises.length === 0) {
      // Nothing to wait for — should not happen, but safeguard
      detailedWarn(
        "[Maakima][Background] No pending fetches and no cooldowns. Breaking.",
      );
      break;
    }

    detailedLog("[Maakima][Background] Waiting for key availability...", {
      cooldownMs,
      pendingServerFetches,
    });

    await Promise.race(waitPromises);
    continue;
  }

  const lastError = errors[errors.length - 1];
  if (lastError) {
    throw lastError;
  }
  throw new Error("No configured API key could produce a response.");
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "toggle_analysis") {
    const tabId = sender.tab && sender.tab.id;
    if (typeof tabId !== "number") {
      return;
    }

    detailedLog(
      "[Maakima][Background] toggle_analysis received for tab:",
      tabId,
    );

    if (activeAnalyses.has(tabId)) {
      detailedLog("[Maakima][Background] Analysis running. Cancelling.", tabId);
      const controller = activeAnalyses.get(tabId);
      controller.abort();
      activeAnalyses.delete(tabId);
      sendTabMessage(tabId, { action: "hide_ui" });
      // Removed 'return;' so that it immediately triggers a new request below
    }

    const controller = new AbortController();
    activeAnalyses.set(tabId, controller);

    runAnalysis(sender.tab, controller.signal).finally(() => {
      activeAnalyses.delete(tabId);
    });
    return;
  }

  if (request.action === "get_settings") {
    getSettings()
      .then((settings) => sendResponse({ ok: true, settings }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  return undefined;
});

async function runAnalysis(tab, signal) {
  const tabId = tab.id;
  detailedLog("[Maakima][Background] runAnalysis started for tab", tabId);

  try {
    const settings = await getSettings();

    await sendTabMessage(tabId, {
      action: "show_gemini_loading",
      displaySettings: {
        fontSize: settings.displayFontSize,
        fontColor: settings.displayFontColor,
        displayPosition: settings.displayPosition,
        whiteBackground: settings.displayWhiteBackground,
        dotSpacing: settings.displayDotSpacing,
        debugPersistentBox: settings.displayDebugPersistentBox,
      },
    });

    detailedLog(
      "[Maakima][Background] Capturing visible tab. Note: captureVisibleTab already captures only the currently visible viewport.",
    );

    let captureDataUrl = await captureVisibleTabSafe(tab.windowId, {
      format: "jpeg",
      quality: 60,
    });

    if (!captureDataUrl || typeof captureDataUrl !== "string") {
      throw new Error("captureVisibleTab returned empty result");
    }

    try {
      const response = await fetch(captureDataUrl);
      const blob = await response.blob();
      const bitmap = await createImageBitmap(blob);

      let width = bitmap.width;
      let height = bitmap.height;

      if (width > 1200) {
        height = Math.round((height * 1200) / width);
        width = 1200;

        const canvas = new OffscreenCanvas(width, height);
        const ctx = canvas.getContext("2d");
        ctx.drawImage(bitmap, 0, 0, width, height);

        const scaledBlob = await canvas.convertToBlob({
          type: "image/jpeg",
          quality: 0.6,
        });

        captureDataUrl = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result);
          reader.onerror = reject;
          reader.readAsDataURL(scaledBlob);
        });
      }
    } catch (err) {
      detailedWarn(
        "[Maakima][Background] Image scaling failed, using original capture",
        err,
      );
    }

    const originalBase64 = captureDataUrl.split(",")[1];
    detailedLog("[Maakima][Background] Image capture complete", {
      format: "JPEG",
      sizeKB: Math.round((originalBase64.length * 0.75) / 1024),
    });

    const base64ImageData = originalBase64;
    const promptText = getPrompt();

    let providerResponse = await runWithProviderFallback(
      base64ImageData,
      promptText,
      signal,
      settings,
    );

    if (!tryParseJsonObject(providerResponse.rawText)) {
      detailedWarn(
        "[Maakima][Background] No parsable JSON in primary prompt response. Retrying once with strict JSON prompt.",
      );
      providerResponse = await runWithProviderFallback(
        base64ImageData,
        getSimpleStrictJsonPrompt(),
        signal,
        settings,
      );
    }

    detailedLog(
      "[Maakima][Background] Raw model output:",
      providerResponse.rawText,
    );

    const parsed = extractStructuredAnswer(providerResponse.rawText);

    await storageSet({
      lastProvider: providerResponse.provider,
      lastProviderSource: providerResponse.source,
      lastRunAt: Date.now(),
      lastNoAnswerReason: parsed.status === "no_answer" ? parsed.reason : "",
      lastError: "",
    });

    await sendTabMessage(tabId, {
      action: "show_gemini_result",
      result: parsed.status === "answered" ? parsed.answers.join(", ") : "",
      parsedAnswers: parsed.answers,
      noAnswer: parsed.status === "no_answer",
      noAnswerReason: parsed.reason,
      rawOutput: providerResponse.rawText,
      provider: providerResponse.provider,
      providerSource: providerResponse.source,
      displaySettings: {
        fontSize: settings.displayFontSize,
        fontColor: settings.displayFontColor,
        displayPosition: settings.displayPosition,
        whiteBackground: settings.displayWhiteBackground,
        dotSpacing: settings.displayDotSpacing,
        debugPersistentBox: settings.displayDebugPersistentBox,
      },
    });

    detailedLog("[Maakima][Background] Result sent to content script.", {
      provider: providerResponse.provider,
      providerSource: providerResponse.source,
      parsedStatus: parsed.status,
      parsedAnswers: parsed.answers,
      noAnswerReason: parsed.reason,
    });
  } catch (error) {
    if (error.name === "AbortError") {
      detailedLog("[Maakima][Background] Analysis aborted by user.");
      return;
    }

    console.error("[Maakima][Background] Analysis error:", {
      message: error.message,
      status: error.status,
      code: error.code,
      provider: error.provider,
      source: error.source,
      responseSnippet: error.responseSnippet,
    });

    await storageSet({
      lastError: error.message || "Unknown error",
      lastRunAt: Date.now(),
    });

    await sendTabMessage(tabId, {
      action: "show_gemini_result",
      error: true,
      errorMessage: error.message || "Unknown analysis error",
    });
  } finally {
    activeAnalyses.delete(tabId);
    detailedLog("[Maakima][Background] Analysis cleanup complete.", tabId);
  }
}

// --- Remote Import & Decryption Helpers ---
const REMOTE_JSON_BASE_URL = "https://distributed-clients.github.io/json/";
const textDecoder = new TextDecoder();
const textEncoder = new TextEncoder();

function b64ToBytes(b64) {
  const binary = atob(b64 || "");
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

async function deriveKey(passphrase, saltBytes, iterations) {
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    textEncoder.encode(passphrase),
    "PBKDF2",
    false,
    ["deriveKey"],
  );

  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      hash: "SHA-256",
      salt: saltBytes,
      iterations,
    },
    keyMaterial,
    { name: "AES-CTR", length: 256 },
    false,
    ["decrypt"],
  );
}

async function decryptUserPayload(payload, passphrase) {
  const salt = b64ToBytes(payload.salt);
  const iv = b64ToBytes(payload.iv);
  const data = b64ToBytes(payload.data);
  const key = await deriveKey(passphrase, salt, payload.iterations || 310000);

  const decrypted = await crypto.subtle.decrypt(
    {
      name: "AES-CTR",
      counter: iv,
      length: 64,
    },
    key,
    data,
  );

  return new Uint8Array(decrypted);
}

function extractEmbeddedUsersFromHtml(htmlText) {
  const match = htmlText.match(/const\s+EMBEDDED_USERS\s*=\s*(\{[\s\S]*?\});/);
  if (!match || !match[1]) {
    throw new Error("Could not find EMBEDDED_USERS in remote page");
  }
  return JSON.parse(match[1]);
}

function parseImportedJson(text) {
  const raw = JSON.parse(text);
  const source = raw && typeof raw.settings === "object" ? raw.settings : raw;

  return {
    userGroqApiKeys: normalizeKeyList(
      source.userGroqApiKeys ??
      source.userGroqApiKey ??
      source.groqApiKeys ??
      source.groqApiKey ??
      source.groq,
    ),
    userOllamaApiKeys: normalizeKeyList(
      source.userOllamaApiKeys ??
      source.userOllamaApiKey ??
      [],
    ),
    userMistralApiKeys: normalizeKeyList(
      source.userMistralApiKeys ??
      source.userMistralApiKey ??
      source.mistralApiKeys ??
      source.mistralApiKey ??
      source.mistral,
    ),
    userGeminiApiKeys: normalizeKeyList(
      source.userGeminiApiKeys ??
      source.userGeminiApiKey ??
      source.geminiApiKeys ??
      source.geminiApiKey ??
      source.gemini,
    ),
    displayFontSize:
      source.displayFontSize ?? source.fontSize ?? source.answerFontSize,
    displayFontColor:
      source.displayFontColor ?? source.fontColor ?? source.answerFontColor,
    displayPosition:
      source.displayPosition ??
      source.position ??
      source.barPosition ??
      source.answerPosition,
    enableDetailedLogging:
      source.enableDetailedLogging ?? source.logging ?? source.detailedLogging,
    displayWhiteBackground:
      source.displayWhiteBackground ??
      source.whiteBackground ??
      source.backgroundWhite,
    displayDebugPersistentBox:
      source.displayDebugPersistentBox ??
      source.debugPersistentBox ??
      source.debugBox,
  };
}

function parseBoolean(value) {
  if (typeof value === "boolean") {
    return value;
  }
  const normalized = `${value || ""}`.trim().toLowerCase();
  return ["1", "true", "yes", "on"].includes(normalized);
}

function parseImportedText(text) {
  const lines = text.split(/\r?\n/);
  const result = {
    userGroqApiKeys: [],
    userOllamaApiKeys: [],
    userMistralApiKeys: [],
    userGeminiApiKeys: [],
  };
  let activeSection = "";

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#") || trimmed.startsWith("//")) {
      continue;
    }

    const sectionMatch = trimmed.match(
      /^(groq|mistral|gemini|settings|config)\s*[:=]\s*$/i,
    );
    if (sectionMatch) {
      activeSection = sectionMatch[1].toLowerCase();
      continue;
    }

    const keyValueMatch = trimmed.match(/^([A-Za-z][\w.-]*)\s*[:=]\s*(.+)$/);
    if (keyValueMatch) {
      const key = keyValueMatch[1].trim().toLowerCase();
      const value = keyValueMatch[2].trim();

      if (
        key === "displayfontsize" ||
        key === "fontsize" ||
        key === "answerfontsize"
      ) {
        result.displayFontSize = value;
        continue;
      }
      if (
        key === "displayfontcolor" ||
        key === "fontcolor" ||
        key === "answerfontcolor"
      ) {
        result.displayFontColor = value;
        continue;
      }
      if (
        key === "displayposition" ||
        key === "position" ||
        key === "barposition" ||
        key === "answerposition"
      ) {
        result.displayPosition = value;
        continue;
      }
      if (
        key === "enabledetailedlogging" ||
        key === "logging" ||
        key === "detailedlogging"
      ) {
        result.enableDetailedLogging = parseBoolean(value);
        continue;
      }
      if (
        key === "displaywhitebackground" ||
        key === "whitebackground" ||
        key === "backgroundwhite"
      ) {
        result.displayWhiteBackground = parseBoolean(value);
        continue;
      }
      if (
        key === "displaydebugpersistentbox" ||
        key === "debugpersistentbox" ||
        key === "debugbox"
      ) {
        result.displayDebugPersistentBox = parseBoolean(value);
        continue;
      }
      if (key === "groq" || key === "groqapikey" || key === "usergroqapikey") {
        result.userGroqApiKeys.push(value);
        continue;
      }
      if (
        key === "mistral" ||
        key === "mistralapikey" ||
        key === "usermistralapikey"
      ) {
        result.userMistralApiKeys.push(value);
        continue;
      } else if (key === "userollamaapikeys") {
        result.userOllamaApiKeys.push(value);
      } else if (key === "usermistralapikeys") {
        result.userMistralApiKeys.push(value);
        continue;
      }
      if (
        key === "gemini" ||
        key === "geminiapikey" ||
        key === "usergeminiapikey"
      ) {
        result.userGeminiApiKeys.push(value);
        continue;
      }
    }

    if (activeSection === "groq") {
      result.userGroqApiKeys.push(trimmed);
      continue;
    }
    if (activeSection === "mistral") {
      result.userMistralApiKeys.push(trimmed);
      continue;
    }
    if (activeSection === "gemini") {
      result.userGeminiApiKeys.push(trimmed);
      continue;
    }

    if (/^gsk_/i.test(trimmed) || /groq/i.test(trimmed)) {
      result.userGroqApiKeys.push(trimmed);
      continue;
    }
    if (/^AIza/i.test(trimmed)) {
      result.userGeminiApiKeys.push(trimmed);
    }
  }

  return result;
}

function parseImportedConfig(text, fileName) {
  const trimmedName = `${fileName || ""}`.toLowerCase();
  try {
    if (trimmedName.endsWith(".json")) {
      return parseImportedJson(text);
    }
    try {
      return parseImportedJson(text);
    } catch (_jsonError) {
      return parseImportedText(text);
    }
  } catch (_error) {
    return parseImportedText(text);
  }
}

async function performRemoteImport(userKey) {
  const delimiterIndex = userKey.indexOf(":");
  const user =
    delimiterIndex === -1 ? "" : userKey.slice(0, delimiterIndex).trim();
  const key = delimiterIndex === -1 ? "" : userKey.slice(delimiterIndex + 1);

  if (!user || !key) {
    throw new Error("Use user:key format");
  }

  const remoteUrl = new URL(REMOTE_JSON_BASE_URL);
  remoteUrl.searchParams.set("user", user);

  const response = await fetch(remoteUrl.toString(), { cache: "no-store" });
  if (!response.ok) {
    throw new Error(`Remote fetch failed (${response.status})`);
  }

  const htmlText = await response.text();
  const embeddedUsers = extractEmbeddedUsersFromHtml(htmlText);
  const encryptedPayload = embeddedUsers[user];
  if (!encryptedPayload) {
    throw new Error("User not found in remote payload");
  }

  const decryptedBytes = await decryptUserPayload(encryptedPayload, key);
  const decryptedText = textDecoder.decode(decryptedBytes);
  const imported = parseImportedConfig(decryptedText, "remote.json");

  // Merge with existing and save
  const current = await storageGet(null);
  const payload = {
    ...current,
    userGroqApiKeys: normalizeKeyList([
      ...(current.userGroqApiKeys || []),
      ...(imported.userGroqApiKeys || []),
    ]),
    userOllamaApiKeys: normalizeKeyList([
      ...(current.userOllamaApiKeys || []),
      ...(imported.userOllamaApiKeys || []),
    ]),
    userMistralApiKeys: normalizeKeyList([
      ...(current.userMistralApiKeys || []),
      ...(imported.userMistralApiKeys || []),
    ]),
    userGeminiApiKeys: normalizeKeyList([
      ...(current.userGeminiApiKeys || []),
      ...(imported.userGeminiApiKeys || []),
    ]),
    displayFontSize: sanitizeFontSize(
      imported.displayFontSize ?? current.displayFontSize,
    ),
    displayFontColor: sanitizeColor(
      imported.displayFontColor ?? current.displayFontColor,
    ),
    displayPosition:
      imported.displayPosition ??
      current.displayPosition ??
      SETTINGS_DEFAULTS.displayPosition,
    displayWhiteBackground:
      imported.displayWhiteBackground ??
      current.displayWhiteBackground ??
      SETTINGS_DEFAULTS.displayWhiteBackground,
    displayDebugPersistentBox:
      imported.displayDebugPersistentBox ??
      current.displayDebugPersistentBox ??
      SETTINGS_DEFAULTS.displayDebugPersistentBox,
    enableDetailedLogging:
      imported.enableDetailedLogging ??
      current.enableDetailedLogging ??
      SETTINGS_DEFAULTS.enableDetailedLogging,
    remoteUserKey: userKey,
  };

  await storageSet(payload);
  return user;
}

// Message Listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "import_remote_user_key") {
    performRemoteImport(request.userKey)
      .then((user) => {
        sendResponse({ success: true, user });
      })
      .catch((error) => {
        sendResponse({ success: false, error: error.message });
      });
    return true; // async response
  }
});
