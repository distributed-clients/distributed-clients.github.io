// In MV3 service workers (Chrome), use importScripts.
if (typeof importScripts === "function") {
  importScripts("config.js");
}

const GEMINI_MODEL_NAME = "gemini-2.5-flash";
let activeAnalyses = new Map(); // Track status per tab

console.log("[Maakima][Background] Script initialized.");

if (chrome.runtime && chrome.runtime.onInstalled) {
  chrome.runtime.onInstalled.addListener((details) => {
    console.log("[Maakima][Background] onInstalled:", details.reason);
  });
}

if (chrome.runtime && chrome.runtime.onStartup) {
  chrome.runtime.onStartup.addListener(() => {
    console.log("[Maakima][Background] onStartup fired.");
  });
}

if (chrome.runtime && chrome.runtime.onSuspend) {
  chrome.runtime.onSuspend.addListener(() => {
    console.log(
      "[Maakima][Background] onSuspend fired (event page idle/sleep).",
    );
  });
}

if (chrome.runtime && chrome.runtime.onSuspendCanceled) {
  chrome.runtime.onSuspendCanceled.addListener(() => {
    console.log(
      "[Maakima][Background] onSuspendCanceled fired (activity resumed).",
    );
  });
}

function storageGet(keys) {
  try {
    const maybePromise = chrome.storage.local.get(keys);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise;
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve, reject) => {
    chrome.storage.local.get(keys, (result) => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve(result);
    });
  });
}

function storageSet(value) {
  try {
    const maybePromise = chrome.storage.local.set(value);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise;
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve, reject) => {
    chrome.storage.local.set(value, () => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve();
    });
  });
}

function storageRemove(keys) {
  try {
    const maybePromise = chrome.storage.local.remove(keys);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise;
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve, reject) => {
    chrome.storage.local.remove(keys, () => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve();
    });
  });
}

function sendTabMessage(tabId, payload) {
  try {
    const maybePromise = chrome.tabs.sendMessage(tabId, payload);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise.catch((error) => {
        console.warn("[Maakima][Background] sendMessage promise error:", error);
        return null;
      });
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, payload, (response) => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        console.warn(
          "[Maakima][Background] sendMessage callback warning:",
          runtimeError.message,
        );
        resolve(null);
        return;
      }
      resolve(response);
    });
  });
}

function captureVisibleTabSafe(windowId, options) {
  try {
    const maybePromise = chrome.tabs.captureVisibleTab(windowId, options);
    if (maybePromise && typeof maybePromise.then === "function") {
      return maybePromise;
    }
  } catch (_e) {
    // Fall back to callback style.
  }

  return new Promise((resolve, reject) => {
    chrome.tabs.captureVisibleTab(windowId, options, (dataUrl) => {
      const runtimeError = chrome.runtime && chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve(dataUrl);
    });
  });
}

// Helper to fetch API Key from Server
async function getApiKeyFromServer() {
  console.log("[Maakima][Background] Fetching API key from server.");
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 10000);

  try {
    const response = await fetch(`${SERVER_API_URL}/gemini-key`, {
      signal: controller.signal,
      headers: { "Content-Type": "application/json" },
    });
    console.log("[Maakima][Background] Key endpoint status:", response.status);
    clearTimeout(timeoutId);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    if (!data.geminiApiKey) throw new Error("No API key received");
    console.log("[Maakima][Background] API key fetched successfully.");
    return data.geminiApiKey;
  } catch (error) {
    clearTimeout(timeoutId);
    console.error("[Maakima][Background] API key fetch failed:", error);
    throw error;
  }
}

// Helper to get API Key (Cache or Server)
async function getCachedApiKey() {
  const result = await storageGet(["cachedApiKey", "keyTimestamp"]);
  const TWO_HOURS_MS = 2 * 60 * 60 * 1000;

  if (!result.cachedApiKey) {
    console.log("[Maakima][Background] No API key in cache.");
  }

  if (
    result.cachedApiKey &&
    result.keyTimestamp &&
    Date.now() - result.keyTimestamp < TWO_HOURS_MS
  ) {
    console.log("[Maakima][Background] Using cached API key.");
    return result.cachedApiKey;
  }

  if (result.cachedApiKey && result.keyTimestamp) {
    const ageMs = Date.now() - result.keyTimestamp;
    console.log("[Maakima][Background] Cached key expired. Age(ms):", ageMs);
  }

  console.log(
    "[Maakima][Background] Cached key missing/expired. Requesting new key.",
  );
  const newApiKey = await getApiKeyFromServer();
  await storageSet({
    cachedApiKey: newApiKey,
    keyTimestamp: Date.now(),
  });
  console.log("[Maakima][Background] New API key cached.");
  return newApiKey;
}

// AI Call Function with Abort Signal (for cancelling)
async function callGeminiApi(base64ImageData, apiKey, promptText, signal) {
  const API_ENDPOINT = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL_NAME}:generateContent?key=${apiKey}`;
  console.log("[Maakima][Background] Sending request to Gemini API.");
  const response = await fetch(API_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [
        {
          parts: [
            { text: promptText },
            { inlineData: { mimeType: "image/png", data: base64ImageData } },
          ],
        },
      ],
    }),
    signal: signal, // Connect the cancellation signal
  });

  if (!response.ok) {
    let responseBody = "";
    try {
      responseBody = await response.text();
    } catch (_readError) {
      responseBody = "<failed to read error body>";
    }

    const error = new Error(
      `Gemini API ${response.status} ${response.statusText}: ${responseBody.slice(0, 1000)}`,
    );
    error.status = response.status;
    throw error;
  }
  const data = await response.json();
  console.log("[Maakima][Background] Gemini API response received.");
  return data.candidates?.[0]?.content?.parts?.[0]?.text || "";
}

// Listen for Messages (Middle Click & Popup)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // 1. Respond to the Popup Donation UI
  if (request.action === "getServerUrl") {
    sendResponse({
      serverUrl: SERVER_API_URL,
      message: "Using server for donation",
    });
    return true;
  }

  // 2. Respond to Middle Click from Content Script
  if (request.action === "toggle_analysis") {
    const tabId = sender.tab.id;
    console.log(
      "[Maakima][Background] toggle_analysis received for tab:",
      tabId,
    );

    // CANCEL LOGIC: If clicked while already running, cancel it!
    if (activeAnalyses.has(tabId)) {
      console.log(
        "[Maakima][Background] Analysis already running. Cancelling.",
      );
      const controller = activeAnalyses.get(tabId);
      controller.abort();
      activeAnalyses.delete(tabId);
      sendTabMessage(tabId, { action: "hide_ui" });
      return;
    }

    // START LOGIC
    console.log("[Maakima][Background] Starting analysis.");
    const controller = new AbortController();
    activeAnalyses.set(tabId, controller);
    runAnalysis(sender.tab, controller.signal);
  }
});

// Main Analysis Runner
async function runAnalysis(tab, signal) {
  const tabId = tab.id;
  console.log("[Maakima][Background] runAnalysis entered for tab:", tabId);
  try {
    await sendTabMessage(tabId, {
      action: "show_gemini_loading",
      loadingText: "....",
    });
    console.log(
      "[Maakima][Background] Loading message sent to content script.",
    );

    const apiKey = await getCachedApiKey();
    console.log("[Maakima][Background] Capturing visible tab.");
    const dataUrl = await captureVisibleTabSafe(tab.windowId, {
      format: "png",
    });
    if (!dataUrl || typeof dataUrl !== "string") {
      throw new Error("captureVisibleTab returned empty result");
    }
    if (!dataUrl.startsWith("data:image/png;base64,")) {
      throw new Error("captureVisibleTab returned non-PNG data URL");
    }
    const base64ImageData = dataUrl.split(",")[1];
    console.log("[Maakima][Background] Screenshot captured.");
    const prompt =
      "Solve only the FIRST multiple choice question visible in the image. If it has a single correct answer, return only that option number (1, 2, 3, 4, or 5). If it has multiple correct answers, return all correct option numbers separated by commas or spaces (e.g., '1, 3' or '1 3'). Do not write any sentences, explanations, or warnings. If there is no question visible, return nothing.";

    let result;
    try {
      result = await callGeminiApi(base64ImageData, apiKey, prompt, signal);
    } catch (apiError) {
      if (
        (apiError.status === 401 || apiError.status === 403) &&
        !signal.aborted
      ) {
        console.warn(
          "[Maakima][Background] Auth error from Gemini. Clearing cached key and retrying once.",
        );
        await storageRemove(["cachedApiKey", "keyTimestamp"]);
        console.log(
          "[Maakima][Background] Cleared cached key after auth error.",
        );
        const freshApiKey = await getCachedApiKey();
        result = await callGeminiApi(
          base64ImageData,
          freshApiKey,
          prompt,
          signal,
        );
      } else {
        throw apiError;
      }
    }
    console.log("LLM output:", result);

    await sendTabMessage(tabId, {
      action: "show_gemini_result",
      result: result,
    });
    console.log("[Maakima][Background] Result message sent to content script.");
  } catch (error) {
    if (error.name === "AbortError") {
      // User cancelled it, do nothing else
      console.log("[Maakima][Background] Analysis aborted by user.");
      return;
    } else {
      console.error("LLM error:", error);
      await sendTabMessage(tabId, {
        action: "show_gemini_result",
        error: true,
      });
      console.log(
        "[Maakima][Background] Error message sent to content script.",
      );
    }
  } finally {
    console.log(
      "[Maakima][Background] Analysis finished. Cleaning up tab state:",
      tabId,
    );
    activeAnalyses.delete(tabId); // Cleanup when done
  }
}
