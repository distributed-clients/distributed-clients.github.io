// Prevent multiple listeners from attaching
if (!window.kimaakaLoaded) {
  window.maakimaLoaded = true;
  console.log("[Maakima][Content] Script loaded.");

  // 1. Listen for Middle Click
  window.addEventListener("auxclick", (e) => {
    if (e.button === 1) {
      // 1 is the middle mouse button
      e.preventDefault();
      console.log(
        "[Maakima][Content] Middle click detected. Requesting analysis toggle.",
      );
      try {
        chrome.runtime.sendMessage({ action: "toggle_analysis" });
      } catch (error) {
        if (error.message.includes("Extension context invalidated")) {
          alert("Maakima was updated! Please refresh this page.");
        } else {
          console.error("Maakima Error:", error);
        }
      }
    }
  });

  // 2. Handle Display Logic
  let displayEl = null;

  function getDisplay() {
    if (!displayEl) {
      displayEl = document.createElement("div");
      displayEl.id = "gemini-vision-onpage-result";

      // Ensure the box stays fixed on screen
      displayEl.style.position = "fixed";
      displayEl.style.bottom = "20px";
      displayEl.style.left = "20px";
      displayEl.style.zIndex = "999999";
      displayEl.style.transition = "opacity 0.3s";

      document.body.appendChild(displayEl);
      console.log("[Maakima][Content] Display element created.");
    }
    return displayEl;
  }

  function parseOptionNumbers(resultText) {
    if (!resultText) return null;

    // Normalize: trim whitespace, lowercase
    const normalized = resultText.trim().toLowerCase();
    if (!normalized) return null;

    // Extract all digits in range 1-5
    const matches = normalized.match(/[1-5]/g);
    if (!matches || matches.length === 0) return null;

    // Convert to numbers and remove duplicates
    const numbers = [...new Set(matches.map(Number))];
    return numbers.sort((a, b) => a - b);
  }

  async function showMultipleAnswers(el, answerArray) {
    for (let i = 0; i < answerArray.length; i++) {
      const answer = answerArray[i];
      const textToShow = ".".repeat(answer);

      // Wait 0.5s before showing next answer (except first)
      if (i > 0) {
        await new Promise((resolve) => setTimeout(resolve, 500));
      }

      el.textContent = textToShow;
      el.style.display = "block";
      el.style.opacity = "1";

      // Show for 1s
      await new Promise((resolve) => setTimeout(resolve, 1000));

      el.style.opacity = "0";
      await new Promise((resolve) => setTimeout(resolve, 120));
      el.style.display = "none";
    }
  }

  chrome.runtime.onMessage.addListener((request) => {
    const el = getDisplay();

    if (request.action === "show_gemini_loading") {
      console.log("[Maakima][Content] Loading state received. UI hidden.");
      el.style.display = "none";
      el.style.opacity = "0";
      el.textContent = "";
    } else if (request.action === "show_gemini_result") {
      const answerNumbers = parseOptionNumbers(request.result);

      console.log(
        "[Maakima][Content] Result received. Parsed answers:",
        answerNumbers,
      );

      if (answerNumbers && answerNumbers.length > 0) {
        showMultipleAnswers(el, answerNumbers);
      } else {
        // Failure: show underscore
        el.textContent = "_";
        el.style.display = "block";
        el.style.opacity = "1";
        setTimeout(() => {
          el.style.opacity = "0";
          setTimeout(() => {
            el.style.display = "none";
            el.textContent = "";
          }, 120);
        }, 1000);
      }
    } else if (request.action === "hide_ui") {
      console.log("[Maakima][Content] Hide UI received.");
      el.style.display = "none";
    }
  });
}
