if (!window.maakimaLoaded) {
  window.maakimaLoaded = true;

  const DEFAULT_SETTINGS = {
    displayFontSize: 30,
    displayFontColor: "#cfcdcd",
    enableDetailedLogging: true,
  };

  let displayEl = null;
  let currentSettings = { ...DEFAULT_SETTINGS };
  let animationToken = 0;

  function storageGet(keys) {
    return new Promise((resolve, reject) => {
      chrome.storage.local.get(keys, (result) => {
        if (chrome.runtime && chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(result);
      });
    });
  }

  function log(...args) {
    if (currentSettings.enableDetailedLogging) {
      console.log(...args);
    }
  }

  function parseColor(input) {
    if (typeof input !== "string") {
      return DEFAULT_SETTINGS.displayFontColor;
    }
    const value = input.trim();
    if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(value)) {
      return value;
    }
    return DEFAULT_SETTINGS.displayFontColor;
  }

  function parseSize(input) {
    const number = Number(input);
    if (!Number.isFinite(number)) {
      return DEFAULT_SETTINGS.displayFontSize;
    }
    return Math.max(10, Math.min(80, Math.round(number)));
  }

  function sanitizeSettings(raw) {
    return {
      displayFontSize: parseSize(raw.displayFontSize),
      displayFontColor: parseColor(raw.displayFontColor),
      enableDetailedLogging:
        typeof raw.enableDetailedLogging === "boolean"
          ? raw.enableDetailedLogging
          : DEFAULT_SETTINGS.enableDetailedLogging,
    };
  }

  function applyDisplaySettings(el) {
    el.style.fontSize = `${currentSettings.displayFontSize}px`;
    el.style.color = currentSettings.displayFontColor;
  }

  function getDisplay() {
    if (!displayEl) {
      displayEl = document.createElement("div");
      displayEl.id = "gemini-vision-onpage-result";
      document.body.appendChild(displayEl);
      applyDisplaySettings(displayEl);
      log("[Maakima][Content] Display element created.");
    }
    return displayEl;
  }

  async function loadSettingsFromStorage() {
    try {
      const raw = await storageGet([
        "displayFontSize",
        "displayFontColor",
        "enableDetailedLogging",
      ]);
      currentSettings = sanitizeSettings({ ...DEFAULT_SETTINGS, ...raw });
      if (displayEl) {
        applyDisplaySettings(displayEl);
      }
      log("[Maakima][Content] Settings loaded:", currentSettings);
    } catch (error) {
      console.error("[Maakima][Content] Failed to load settings:", error);
    }
  }

  function parseOptionNumbers(resultText) {
    if (!resultText) {
      return null;
    }

    const matches = resultText.match(/[1-5]/g);
    if (!matches || matches.length === 0) {
      return null;
    }

    return [...new Set(matches.map(Number))].sort((a, b) => a - b);
  }

  function wait(ms, token) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (token === animationToken) {
          resolve(true);
          return;
        }
        resolve(false);
      }, ms);
    });
  }

  async function showMultipleAnswers(el, answerArray) {
    animationToken += 1;
    const token = animationToken;
    applyDisplaySettings(el);

    for (let i = 0; i < answerArray.length; i += 1) {
      const answer = answerArray[i];
      el.style.letterSpacing = "6px";
      el.textContent = ".".repeat(answer);
      el.style.display = "block";
      el.style.opacity = "1";

      if (!(await wait(1000, token))) {
        return;
      }

      el.style.opacity = "0";
      if (!(await wait(150, token))) {
        return;
      }
      el.style.display = "none";

      if (i < answerArray.length - 1) {
        if (!(await wait(500, token))) {
          return;
        }
      }
    }
  }

  async function showTextMessage(el, text, durationMs) {
    animationToken += 1;
    const token = animationToken;

    el.style.letterSpacing = "0px";
    el.style.fontSize = `${Math.max(12, currentSettings.displayFontSize - 8)}px`;
    el.textContent = text;
    el.style.display = "block";
    el.style.opacity = "1";

    if (!(await wait(durationMs, token))) {
      return;
    }

    el.style.opacity = "0";
    if (!(await wait(160, token))) {
      return;
    }

    el.style.display = "none";
    el.textContent = "";
    applyDisplaySettings(el);
  }

  async function showUnderscore(el, durationMs = 1200) {
    animationToken += 1;
    const token = animationToken;

    applyDisplaySettings(el);
    el.style.letterSpacing = "6px";
    el.textContent = "_";
    el.style.display = "block";
    el.style.opacity = "1";

    if (!(await wait(durationMs, token))) {
      return;
    }

    el.style.opacity = "0";
    if (!(await wait(160, token))) {
      return;
    }

    el.style.display = "none";
    el.textContent = "";
  }

  window.addEventListener("auxclick", (e) => {
    if (e.button === 1) {
      e.preventDefault();
      log("[Maakima][Content] Middle click detected. Toggling analysis.");
      try {
        chrome.runtime.sendMessage({ action: "toggle_analysis" });
      } catch (error) {
        if (
          error.message &&
          error.message.includes("Extension context invalidated")
        ) {
          alert("Maakima was updated. Please refresh this page.");
        } else {
          console.error("[Maakima][Content] Runtime messaging error:", error);
        }
      }
    }
  });

  chrome.runtime.onMessage.addListener((request) => {
    const el = getDisplay();

    if (request.displaySettings) {
      currentSettings = sanitizeSettings({
        ...currentSettings,
        displayFontSize: request.displaySettings.fontSize,
        displayFontColor: request.displaySettings.fontColor,
      });
      applyDisplaySettings(el);
    }

    if (request.action === "show_gemini_loading") {
      console.group("[Maakima][Content] Request Started");
      console.log("Timestamp:", new Date().toISOString());
      console.log("Loading UI...");
      console.groupEnd();
      log("[Maakima][Content] Loading signal received.");
      animationToken += 1;
      el.style.display = "none";
      el.style.opacity = "0";
      el.textContent = "";
      return;
    }

    if (request.action === "show_gemini_result") {
      console.group("[Maakima][Content] Result Received");

      if (request.error) {
        console.error("Analysis Error:", request.errorMessage);
        console.log("Full Request Object:", request);
        console.groupEnd();
        showUnderscore(el, 1200);
        return;
      }

      console.log("Provider Source:", request.providerSource);
      console.log("Provider:", request.provider);
      console.log("Raw AI Output:", request.rawOutput);
      console.log("Parsed Answer Array:", request.parsedAnswers);
      console.log("No Answer Status:", request.noAnswer);
      console.log("No Answer Reason:", request.noAnswerReason);
      console.log("Full Request Object:", request);

      if (request.noAnswer) {
        const reason = request.noAnswerReason || "No visible solvable question";
        console.warn("Model replied but no solvable answer found:", reason);
        console.groupEnd();
        showUnderscore(el, 1200);
        return;
      }

      const answerNumbers =
        Array.isArray(request.parsedAnswers) && request.parsedAnswers.length > 0
          ? request.parsedAnswers
          : parseOptionNumbers(request.result);

      console.log("Final Answer Numbers:", answerNumbers);
      console.groupEnd();

      if (answerNumbers && answerNumbers.length > 0) {
        showMultipleAnswers(el, answerNumbers);
      } else {
        showUnderscore(el, 1200);
      }
      return;
    }

    if (request.action === "hide_ui") {
      animationToken += 1;
      el.style.display = "none";
      el.style.opacity = "0";
      el.textContent = "";
      log("[Maakima][Content] Hide UI signal received.");
    }
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") {
      return;
    }

    let shouldApply = false;

    if (changes.displayFontSize) {
      currentSettings.displayFontSize = parseSize(
        changes.displayFontSize.newValue,
      );
      shouldApply = true;
    }

    if (changes.displayFontColor) {
      currentSettings.displayFontColor = parseColor(
        changes.displayFontColor.newValue,
      );
      shouldApply = true;
    }

    if (changes.enableDetailedLogging) {
      currentSettings.enableDetailedLogging =
        typeof changes.enableDetailedLogging.newValue === "boolean"
          ? changes.enableDetailedLogging.newValue
          : DEFAULT_SETTINGS.enableDetailedLogging;
    }

    if (shouldApply && displayEl) {
      applyDisplaySettings(displayEl);
    }
  });

  loadSettingsFromStorage();
}
