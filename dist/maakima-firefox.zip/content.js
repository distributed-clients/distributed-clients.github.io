if (!window.maakimaLoaded) {
  window.maakimaLoaded = true;

  const DEFAULT_SETTINGS = {
    displayFontSize: 30,
    displayFontColor: "#cdcdcd",
    displayPosition: "left",
    displayWhiteBackground: false,
    displayDotSpacing: -5,
    displayDebugPersistentBox: false,
    enableDetailedLogging: false,
  };

  let displayEl = null;
  let displayTextEl = null;
  let currentSettings = { ...DEFAULT_SETTINGS };
  let animationToken = 0;
  let debugInterval = null;

  function storageGet(keys) {
    return new Promise((resolve, reject) => {
      chrome.storage.local.get(keys, (result) => {
        if (chrome.runtime && chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(result);
      });
    });
  }

  function log(...args) {
    if (currentSettings.enableDetailedLogging) {
      console.log(...args);
    }
  }

  function logError(...args) {
    if (currentSettings.enableDetailedLogging) {
      console.error(...args);
    }
  }

  function logWarn(...args) {
    if (currentSettings.enableDetailedLogging) {
      console.warn(...args);
    }
  }

  function logGroup(...args) {
    if (currentSettings.enableDetailedLogging) {
      console.group(...args);
    }
  }

  function logGroupEnd() {
    if (currentSettings.enableDetailedLogging) {
      console.groupEnd();
    }
  }

  function parseColor(input) {
    if (typeof input !== "string") {
      return DEFAULT_SETTINGS.displayFontColor;
    }
    const value = input.trim();
    if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(value)) {
      return value;
    }
    return DEFAULT_SETTINGS.displayFontColor;
  }

  function parseSize(input) {
    const number = Number(input);
    if (!Number.isFinite(number)) {
      return DEFAULT_SETTINGS.displayFontSize;
    }
    return Math.max(10, Math.min(80, Math.round(number)));
  }

  function parseBoolean(input, fallback) {
    if (typeof input === "boolean") {
      return input;
    }
    if (typeof fallback === "boolean") {
      return fallback;
    }
    return false;
  }

  function parsePosition(input) {
    const value = `${input || ""}`.trim().toLowerCase();
    if (value === "left" || value === "right") {
      return value;
    }
    return DEFAULT_SETTINGS.displayPosition;
  }

  function sanitizeSettings(raw) {
    const dotSpacing = Number(raw.displayDotSpacing);
    return {
      displayFontSize: parseSize(raw.displayFontSize),
      displayFontColor: parseColor(raw.displayFontColor),
      displayPosition: parsePosition(raw.displayPosition),
      displayWhiteBackground: parseBoolean(
        raw.displayWhiteBackground,
        DEFAULT_SETTINGS.displayWhiteBackground,
      ),
      displayDotSpacing: Number.isFinite(dotSpacing)
        ? Math.max(-15, Math.min(30, Math.round(dotSpacing)))
        : DEFAULT_SETTINGS.displayDotSpacing,
      displayDebugPersistentBox: parseBoolean(
        raw.displayDebugPersistentBox,
        DEFAULT_SETTINGS.displayDebugPersistentBox,
      ),
      enableDetailedLogging:
        typeof raw.enableDetailedLogging === "boolean"
          ? raw.enableDetailedLogging
          : DEFAULT_SETTINGS.enableDetailedLogging,
    };
  }

  function applyPositionSettings(el) {
    const position = parsePosition(currentSettings.displayPosition);
    el.style.setProperty("bottom", "10px", "important");
    if (position === "left") {
      el.style.setProperty("left", "10px", "important");
      el.style.setProperty("right", "auto", "important");
      el.style.setProperty("transform", "none", "important");
      return;
    }
    if (position === "right") {
      el.style.setProperty("left", "auto", "important");
      el.style.setProperty("right", "10px", "important");
      el.style.setProperty("transform", "none", "important");
      return;
    }
    el.style.setProperty("left", "50%", "important");
    el.style.setProperty("right", "auto", "important");
    el.style.setProperty("transform", "translateX(-50%)", "important");
  }

  function applyDisplaySettings(el) {
    applyPositionSettings(el);
    el.style.setProperty(
      "font-size",
      `${currentSettings.displayFontSize}px`,
      "important",
    );
    el.style.setProperty(
      "color",
      currentSettings.displayFontColor,
      "important",
    );
    if (currentSettings.displayWhiteBackground) {
      el.style.setProperty(
        "background-color",
        "rgba(255, 255, 255, 0.95)",
        "important",
      );
      el.style.setProperty("padding", "0 0.04em", "important");
      el.style.setProperty("border-radius", "0.08em", "important");
      el.style.setProperty("box-shadow", "none", "important");
    } else {
      el.style.setProperty("background-color", "transparent", "important");
      el.style.setProperty("padding", "0px", "important");
      el.style.setProperty("border-radius", "0px", "important");
      el.style.setProperty("box-shadow", "none", "important");
    }

    if (displayTextEl) {
      displayTextEl.style.setProperty(
        "font-size",
        `${currentSettings.displayFontSize}px`,
        "important",
      );
      displayTextEl.style.setProperty(
        "color",
        currentSettings.displayFontColor,
        "important",
      );
    }
  }

  function showDisplay(el) {
    el.style.setProperty("display", "inline-flex", "important");
    el.style.setProperty("opacity", "1", "important");
  }

  function hideDisplay(el) {
    el.style.setProperty("display", "none", "important");
    el.style.setProperty("opacity", "0", "important");
  }

  function applyDebugPreviewState() {
    if (!currentSettings.displayDebugPersistentBox) {
      if (debugInterval) {
        clearInterval(debugInterval);
        debugInterval = null;
      }
      if (displayEl) {
        hideDisplay(displayEl);
        if (displayTextEl) {
          displayTextEl.textContent = "";
        }
      }
      return;
    }

    const el = getDisplay();
    // Apply all user settings (position, background, etc.) for debug preview
    applyDisplaySettings(el);
    displayTextEl.style.setProperty("letter-spacing", `${currentSettings.displayDotSpacing}px`, "important");
    
    if (!debugInterval) {
      let debugCount = 1;
      displayTextEl.innerHTML = formatDots(debugCount);
      debugInterval = setInterval(() => {
        debugCount = (debugCount % 6) + 1;
        displayTextEl.innerHTML = formatDots(debugCount);
      }, 1200);
    } else {
      // Re-apply if settings change while interval is running
      displayTextEl.innerHTML = formatDots(displayTextEl.innerHTML.replace(/<[^>]*>/g, "").length || 4);
    }
    
    showDisplay(el);
  }

  function getDisplay() {
    if (!displayEl) {
      displayEl = document.createElement("div");
      displayEl.id = "gemini-vision-onpage-result";
      displayTextEl = document.createElement("div");
      displayTextEl.id = "gemini-vision-onpage-result-text";
      displayEl.appendChild(displayTextEl);
      document.body.appendChild(displayEl);
      applyDisplaySettings(displayEl);
      log("[Maakima][Content] Display element created.");
    }
    return displayEl;
  }

  async function loadSettingsFromStorage() {
    try {
      const raw = await storageGet([
        "displayFontSize",
        "displayFontColor",
        "displayPosition",
        "displayWhiteBackground",
        "displayDotSpacing",
        "displayDebugPersistentBox",
        "enableDetailedLogging",
      ]);
      currentSettings = sanitizeSettings({ ...DEFAULT_SETTINGS, ...raw });
      if (displayEl) {
        applyDisplaySettings(displayEl);
      }
      applyDebugPreviewState();
      log("[Maakima][Content] Settings loaded:", currentSettings);
    } catch (error) {
      logError("[Maakima][Content] Failed to load settings:", error);
    }
  }

  function parseOptionNumbers(resultText) {
    if (!resultText) {
      return null;
    }

    const matches = resultText.match(/[1-6]/g);
    if (!matches || matches.length === 0) {
      return null;
    }

    return [...new Set(matches.map(Number))].sort((a, b) => a - b);
  }

  function wait(ms, token) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (token === animationToken) {
          resolve(true);
          return;
        }
        resolve(false);
      }, ms);
    });
  }

  function formatDots(count) {
    const gap = `  `;
    if (count === 4) return `..${gap}..`;
    if (count === 5) return `...${gap}..`;
    if (count === 6) return `...${gap}...`;
    return ".".repeat(Math.max(1, count));
  }

  async function showMultipleAnswers(el, answerArray) {
    animationToken += 1;
    const token = animationToken;
    applyDisplaySettings(el);

    for (let i = 0; i < answerArray.length; i += 1) {
      const answer = answerArray[i];
      displayTextEl.style.setProperty("letter-spacing", `${currentSettings.displayDotSpacing}px`, "important");
      displayTextEl.innerHTML = formatDots(answer);
      showDisplay(el);

      if (!(await wait(1000, token))) {
        return;
      }

      el.style.setProperty("opacity", "0", "important");
      if (!(await wait(150, token))) {
        return;
      }
      hideDisplay(el);

      if (i < answerArray.length - 1) {
        if (!(await wait(500, token))) {
          return;
        }
      }
    }
  }

  async function showTextMessage(el, text, durationMs) {
    animationToken += 1;
    const token = animationToken;

    displayTextEl.style.setProperty("letter-spacing", "0px", "important");
    displayTextEl.style.setProperty(
      "font-size",
      `${Math.max(12, currentSettings.displayFontSize - 8)}px`,
      "important",
    );
    displayTextEl.textContent = text;
    showDisplay(el);

    if (!(await wait(durationMs, token))) {
      return;
    }

    el.style.setProperty("opacity", "0", "important");
    if (!(await wait(160, token))) {
      return;
    }

    hideDisplay(el);
    if (!currentSettings.displayDebugPersistentBox) {
      displayTextEl.textContent = "";
    }
    applyDisplaySettings(el);
  }

  async function showUnderscore(el, durationMs = 1200) {
    animationToken += 1;
    const token = animationToken;

    applyDisplaySettings(el);
    displayTextEl.style.setProperty("letter-spacing", `${currentSettings.displayDotSpacing}px`, "important");
    displayTextEl.textContent = "_";
    showDisplay(el);

    if (!(await wait(durationMs, token))) {
      return;
    }

    el.style.setProperty("opacity", "0", "important");
    if (!(await wait(160, token))) {
      return;
    }

    hideDisplay(el);
    if (!currentSettings.displayDebugPersistentBox) {
      displayTextEl.textContent = "";
    }
  }

  window.addEventListener("auxclick", (e) => {
    if (e.button === 1) {
      e.preventDefault();
      log("[Maakima][Content] Middle click detected. Toggling analysis.");
      try {
        chrome.runtime.sendMessage({ action: "toggle_analysis" });
      } catch (error) {
        if (
          error.message &&
          error.message.includes("Extension context invalidated")
        ) {
          alert("Maakima was updated. Please refresh this page.");
        } else {
          logError("[Maakima][Content] Runtime messaging error:", error);
        }
      }
    }
  });

  chrome.runtime.onMessage.addListener((request) => {
    const el = getDisplay();

    // Unified preview and actual: when popup sends preview, treat as real settings
    if (
      request.action === "debug_preview_settings" &&
      request.displaySettings
    ) {
      currentSettings = sanitizeSettings({
        ...currentSettings,
        displayFontSize: request.displaySettings.fontSize,
        displayFontColor: request.displaySettings.fontColor,
        displayPosition: request.displaySettings.displayPosition,
        displayWhiteBackground: request.displaySettings.whiteBackground,
        displayDotSpacing: request.displaySettings.dotSpacing,
        displayDebugPersistentBox: request.displaySettings.debugPersistentBox,
        enableDetailedLogging: request.displaySettings.enableDetailedLogging,
      });
      applyDisplaySettings(el);
      applyDebugPreviewState();
      return;
    }

    if (request.displaySettings) {
      currentSettings = sanitizeSettings({
        ...currentSettings,
        displayFontSize: request.displaySettings.fontSize,
        displayFontColor: request.displaySettings.fontColor,
        displayPosition: request.displaySettings.displayPosition,
        displayWhiteBackground: request.displaySettings.whiteBackground,
        displayDotSpacing: request.displaySettings.dotSpacing,
        displayDebugPersistentBox: request.displaySettings.debugPersistentBox,
        enableDetailedLogging: request.displaySettings.enableDetailedLogging,
      });
      applyDisplaySettings(el);
      applyDebugPreviewState();
    }

    if (
      currentSettings.displayDebugPersistentBox &&
      (request.action === "show_gemini_loading" ||
        request.action === "show_gemini_result" ||
        request.action === "hide_ui")
    ) {
      // In debug preview mode, keep a static dummy box for visual tuning.
      applyDebugPreviewState();
      return;
    }

    if (request.action === "show_gemini_loading") {
      logGroup("[Maakima][Content] Request Started");
      log("Timestamp:", new Date().toISOString());
      log("Loading UI...");
      logGroupEnd();
      log("[Maakima][Content] Loading signal received.");
      animationToken += 1;
      hideDisplay(el);
      displayTextEl.textContent = "";
      return;
    }

    if (request.action === "show_gemini_result") {
      logGroup("[Maakima][Content] Result Received");

      if (request.error) {
        logError("Analysis Error:", request.errorMessage);
        log("Full Request Object:", request);
        logGroupEnd();
        showUnderscore(el, 1200);
        return;
      }

      log("Provider Source:", request.providerSource);
      log("Provider:", request.provider);
      log("Raw AI Output:", request.rawOutput);
      log("Parsed Answer Array:", request.parsedAnswers);
      log("No Answer Status:", request.noAnswer);
      log("No Answer Reason:", request.noAnswerReason);
      log("Full Request Object:", request);

      if (request.noAnswer) {
        const reason = request.noAnswerReason || "No visible solvable question";
        logWarn("Model replied but no solvable answer found:", reason);
        logGroupEnd();
        showUnderscore(el, 1200);
        return;
      }

      const answerNumbers =
        Array.isArray(request.parsedAnswers) && request.parsedAnswers.length > 0
          ? request.parsedAnswers
          : parseOptionNumbers(request.result);

      log("Final Answer Numbers:", answerNumbers);
      logGroupEnd();

      if (answerNumbers && answerNumbers.length > 0) {
        showMultipleAnswers(el, answerNumbers);
      } else {
        showUnderscore(el, 1200);
      }
      return;
    }

    if (request.action === "hide_ui") {
      animationToken += 1;
      hideDisplay(el);
      displayTextEl.textContent = "";
      log("[Maakima][Content] Hide UI signal received.");
    }

    if (request.action === "hide_floating_key_box") {
      const box = document.getElementById("maakima-floating-key-box");
      if (box) box.remove();
    }
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") {
      return;
    }

    let shouldApply = false;

    if (changes.displayFontSize) {
      currentSettings.displayFontSize = parseSize(
        changes.displayFontSize.newValue,
      );
      shouldApply = true;
    }

    if (changes.displayFontColor) {
      currentSettings.displayFontColor = parseColor(
        changes.displayFontColor.newValue,
      );
      shouldApply = true;
    }

    if (changes.enableDetailedLogging) {
      currentSettings.enableDetailedLogging =
        typeof changes.enableDetailedLogging.newValue === "boolean"
          ? changes.enableDetailedLogging.newValue
          : DEFAULT_SETTINGS.enableDetailedLogging;
    }

    if (changes.displayWhiteBackground) {
      currentSettings.displayWhiteBackground = parseBoolean(
        changes.displayWhiteBackground.newValue,
        DEFAULT_SETTINGS.displayWhiteBackground,
      );
      shouldApply = true;
    }

    if (changes.displayPosition) {
      currentSettings.displayPosition = parsePosition(
        changes.displayPosition.newValue,
      );
      shouldApply = true;
    }

    if (changes.displayDebugPersistentBox) {
      currentSettings.displayDebugPersistentBox = parseBoolean(
        changes.displayDebugPersistentBox.newValue,
        DEFAULT_SETTINGS.displayDebugPersistentBox,
      );
      shouldApply = true;
    }

    if (changes.displayDotSpacing) {
      const spacing = Number(changes.displayDotSpacing.newValue);
      currentSettings.displayDotSpacing = Number.isFinite(spacing)
        ? Math.max(-15, Math.min(30, Math.round(spacing)))
        : DEFAULT_SETTINGS.displayDotSpacing;
      shouldApply = true;
    }

    if (
      typeof changes.disableFloatingKeyBox?.newValue !== "undefined" ||
      changes.userGroqApiKeys ||
      changes.userMistralApiKeys ||
      changes.userGeminiApiKeys ||
      changes.remoteUserKey
    ) {
      checkAndShowKeyImport();
    }

    if (shouldApply && displayEl) {
      applyDisplaySettings(displayEl);
    }

    if (changes.displayDebugPersistentBox) {
      applyDebugPreviewState();
    }
  });

  async function checkAndShowKeyImport() {
    const keys = await storageGet([
      "userGroqApiKeys",
      "userMistralApiKeys",
      "userGeminiApiKeys",
      "disableFloatingKeyBox",
    ]);

    const hasAnyApiKeys =
      (keys.userGroqApiKeys && keys.userGroqApiKeys.length > 0) ||
      (keys.userMistralApiKeys && keys.userMistralApiKeys.length > 0) ||
      (keys.userGeminiApiKeys && keys.userGeminiApiKeys.length > 0);

    const isDisabled = Boolean(keys.disableFloatingKeyBox);

    if (hasAnyApiKeys || isDisabled) {
      const box = document.getElementById("maakima-floating-key-box");
      if (box) box.remove();
      return;
    }

    if (document.getElementById("maakima-floating-key-box")) {
      return;
    }

    const box = document.createElement("div");
    box.id = "maakima-floating-key-box";
    box.style.cssText = `
      position: fixed !important;
      bottom: 0 !important;
      left: 0 !important;
      z-index: 2147483647 !important;
      background: transparent !important;
      border: none !important;
      padding: 0 !important;
      display: flex !important;
      align-items: center !important;
      font-family: 'Inter', sans-serif !important;
      opacity: 0 !important;
      transition: opacity 0.2s, background 0.2s !important;
    `;

    const input = document.createElement("input");
    input.type = "text";
    input.style.cssText = `
      border: none !important;
      outline: none !important;
      font-size: 7px !important;
      color: transparent !important;
      caret-color: transparent !important;
      background: transparent !important;
      width: 12px !important;
      padding: 0 !important;
      text-align: center !important;
      position: relative !important;
      z-index: 1 !important;
    `;

    box.onmouseenter = () => {
      box.style.opacity = "1";
      box.style.background = "#fff";
      box.style.border = "1px solid #ddd";
    };
    box.onmouseleave = () => {
      if (document.activeElement !== input) {
        box.style.opacity = "0";
        box.style.background = "transparent";
        box.style.border = "none";
      }
    };

    input.onfocus = () => {
      box.style.opacity = "1";
      box.style.background = "#fff";
      box.style.border = "1px solid #ddd";
    };
    input.onblur = () => {
      input.value = ""; // Clear on focus loss
      box.style.opacity = "0";
      box.style.background = "transparent";
      box.style.border = "none";
    };

    box.appendChild(input);
    document.body.appendChild(box);

    input.addEventListener("keydown", async (e) => {
      if (e.key === "Enter") {
        const userKey = input.value.trim();
        if (!userKey || !userKey.includes(":")) {
          input.value = "";
          return;
        }

        input.disabled = true;
        input.value = "Importing...";
        input.style.color = "#aaa";

        chrome.runtime.sendMessage(
          { action: "import_remote_user_key", userKey },
          (response) => {
            if (response && response.success) {
              box.remove();
              // Reload settings to ensure content script knows we have keys now
              loadSettingsFromStorage();
            } else {
              input.disabled = false;
              input.value = ""; // Clear on failure
              logError("[Maakima] Import failed:", response ? response.error : "No response");
            }
          }
        );
      }
    });
  }

  loadSettingsFromStorage().then(() => {
    checkAndShowKeyImport();
  });
}
